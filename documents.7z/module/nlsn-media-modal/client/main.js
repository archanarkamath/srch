// This file includes significant forked code from the Gutenberg core,
// so there's no realistic hope of it passing Airbnb/JSX-a11y eslint.
/* eslint-disable */
import ReactDOM from 'react-dom';
import ESMediaSearchPane from './components/esMediaPane';

const { wp } = window;
const { Component, Fragment } = wp.element;
const { addFilter, removeFilter } = wp.hooks;
const { __ } = wp.i18n;
const { parseWithAttributeSchema } = wp.blocks;

// NOTE: This is generally forked from https://github.com/WordPress/gutenberg/blob/master/packages/edit-post/src/hooks/components/media-upload/index.js, which it replaces via the filter at the bottom.
const esMediaFrame = () => wp.media.view.MediaFrame.Post.extend({

  /**
     * Create the default states.
     *
     * @return {void}
     */
  createStates: function createStates() {
    this.states.add([
      new wp.media.controller.Library({
        id: 'gallery',
        title: wp.media.view.l10n.createGalleryTitle,
        priority: 40,
        toolbar: 'main-gallery',
        filterable: 'uploaded',
        multiple: 'add',
        editable: false,

        library: wp.media.query(_.defaults({
          type: 'image',
        }, this.options.library)),
      }),

      new wp.media.controller.GalleryEdit({
        library: this.options.selection,
        editing: this.options.editing,
        menu: 'gallery',
        displaySettings: false,
        multiple: true,
      }),

      new wp.media.controller.GalleryAdd(),
    ]);
  },
});

class ESMediaUpload extends Component {
  constructor({
    allowedTypes,
    type: deprecatedType,
    multiple = false,
    gallery = false,
    title = __('Select or Upload Media'),
    modalClass,
    value,
  }) {
    super(...arguments);
    this.openModal = this.openModal.bind(this);
    this.onOpen = this.onOpen.bind(this);
    this.onSelect = this.onSelect.bind(this);
    this.onUpdate = this.onUpdate.bind(this);
    this.onClose = this.onClose.bind(this);
    this.onTab = this.onTab.bind(this);
    this.processMediaCaption = this.processMediaCaption.bind(this);

    // This is additional code to add a third tab to the media modal router.
    wp.media.view.MediaFrame.Select.prototype.browseRouter = function (routerView) {
      routerView.set({
        upload: {
          text: wp.media.view.l10n.uploadFilesTitle,
          priority: 20,
        },
        browse: {
          text: wp.media.view.l10n.mediaLibraryTitle,
          priority: 40,
        },
        tags: {
          text: __('Find by Tag'),
          priority: 60,
        },
      });
    };

    let allowedTypesToUse = allowedTypes;
    if (! allowedTypes && deprecatedType) {
      wp.deprecated('type property of wp.editor.MediaUpload', {
        version: '4.2',
        alternative: 'allowedTypes property containing an array with the allowedTypes or do not pass any property if all types are allowed',
      });
      if ('*' === deprecatedType) {
        allowedTypesToUse = undefined;
      } else {
        allowedTypesToUse = [deprecatedType];
      }
    }

    if (gallery) {
      const currentState = value ? 'gallery-edit' : 'gallery';
      const GalleryDetailsMediaFrame = esMediaFrame();
      const attachments = getAttachmentsCollection(value);
      const selection = new wp.media.model.Selection(attachments.models, {
        props: attachments.props.toJSON(),
        multiple,
      });
      this.frame = new GalleryDetailsMediaFrame({
        mimeType: allowedTypesToUse,
        state: currentState,
        multiple,
        selection,
        editing: !! (value),
      });
      wp.media.frame = this.frame;
    } else {
      const frameConfig = {
        title,
        button: {
          text: __('Select'),
        },
        multiple,
      };
      if (allowedTypesToUse) {
        frameConfig.library = { type: allowedTypesToUse };
      }

      this.frame = wp.media(frameConfig);
    }

    if (modalClass) {
      this.frame.$el.addClass(modalClass);
    }

    // These are events that call back to the core media modal Backbone event system.
    this.frame.on('select', this.onSelect);
    this.frame.on('update', this.onUpdate);
    this.frame.on('open', this.onOpen);
    this.frame.on('close', this.onClose);

    // This is an event to render our React app inside the media modal.
    this.frame.on('content:render:tags', this.onTab);
  }

  // All these methods except `onTab` are unchanged from core (and lacking docblocks as such)
  componentWillUnmount() {
    this.frame.remove();
  }

  onUpdate(selections) {
    const { onSelect, multiple = false } = this.props;
    const state = this.frame.state();
    const selectedImages = selections || state.get('selection');

    if (! selectedImages || ! selectedImages.models.length) {
      return;
    }

    if (multiple) {
      onSelect(selectedImages.models.map((model) => this.processMediaCaption(slimImageObject(model.toJSON()))));
    } else {
      onSelect(this.processMediaCaption(slimImageObject((selectedImages.models[0].toJSON()))));
    }
  }

  onSelect() {
    const { onSelect, multiple = false } = this.props;
    const attachment = this.frame.state().get('selection').toJSON();
    onSelect(
      multiple
        ? attachment.map(this.processMediaCaption)
        : this.processMediaCaption(attachment[0])
    );
  }

  onOpen() {
    if (! this.props.value) {
      return;
    }

    if (! this.props.gallery) {
      const selection = this.frame.state().get('selection');
      castArray(this.props.value).map((id) => {
        selection.add(wp.media.attachment(id));
      });
    }
    // load the images so they are available in the media modal.
    getAttachmentsCollection(castArray(this.props.value)).more();
  }

  onClose() {
    const { onClose } = this.props;

    if (onClose) {
      onClose();
    }
  }

  /**
   * Renders our React app root into the media modal tab we created.
   * Also creates and passes along some helper functions to deal with the global
   * media modal state.
   */
  onTab() {
    if (! this.tagPane) {
      this.tagPane = new wp.media.View({
        tagName: 'div',
        className: 'attachments-browser',
      });
    }

    this.frame.content.set(this.tagPane);

    // Yes, we have to use jQuery here because our React app doesn't control anything above
    // the element associated with our Backbone view. This is how Backbone wants you to do things.
    /** 
     * Sets the data-columns attribute on the media modal container so attachments render properly.
     */
    const setColumns = () => {
      const idealColumnWidth = 640 > window.innerWidth ? 135 : 200;
      const columns = Math.min(Math.round(window.innerWidth / idealColumnWidth), 12) || 1;
      this.tagPane.$el.closest('.media-frame-content').attr('data-columns', columns);
    };

    /**
     * Passes the selected image model back to the media modal global state.
     * This is what makes the "select" button work.
     */
    const setModalSelection = (post_id) => {
      const selection = this.frame.state().get('selection');
      const attachment = wp.media.attachment(post_id);
      attachment.sync('read').done((model) => {
        selection.add(model);
      });
    };

    const defaultFilters = ('undefined' !== typeof es_media_modal_default_filters)
      ? es_media_modal_default_filters : {};

    ReactDOM.render(
      <ESMediaSearchPane
        setColumns={setColumns}
        setModalSelection={setModalSelection}
        existing={this.props.value ? this.props.value : 0}
        defaultFilters={defaultFilters}
      />,
      this.tagPane.el
    );
  }

  openModal() {
    this.frame.open();
  }

  processMediaCaption(mediaObject) {
    return ! mediaObject.caption
      ? mediaObject
      : {
        ...mediaObject,
        caption: parseWithAttributeSchema(mediaObject.caption, {
          source: 'rich-text',
        }),
      };
  }

  render() {
    return this.props.render({ open: this.openModal });
  }
}

addFilter('editor.MediaUpload', 'es/media', () => ESMediaUpload, 20);

export default ESMediaUpload;
