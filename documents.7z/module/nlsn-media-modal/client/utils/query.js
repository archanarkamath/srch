/* global ajaxurl, esMediaModalOpts */

import querystring from 'querystring';

const queryMedia = (query, offset, terms) => fetch(ajaxurl, {
  method: 'POST',
  headers: {
    'Content-type': 'application/x-www-form-urlencoded',
  },
  body: querystring.stringify({
    action: 'es_media_search',
    query,
    offset,
    nonce: esMediaModalOpts.queryNonce,
    terms: JSON.stringify(terms),
  }),
})
  .then((response) => response.json());

export default queryMedia;
