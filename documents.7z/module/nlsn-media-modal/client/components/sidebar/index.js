const { wp } = window;
const { __ } = wp.i18n;

const Sidebar = ({ selection, model }) => (
  <div className="media-sidebar">
    {(0 !== selection && 'undefined' !== typeof model)
      && (
        <div data-id={selection} className="attachment-details save-read">
          <h2>{__('Attachment Details')}</h2>
          <div className="attachment-info">
            <div className="thumbnail thumbnail-image">
              <img
                src={model.medium}
                draggable="false"
                alt={model.alt}
              />
            </div>
            <div className="details">
              <div className="filename">{model.filename}</div>
              <div className="uploaded">{model.date}</div>
              <div className="file-size">{model.filesize}</div>
              <div className="file-type">{model.filetype}</div>
              {(0 < model.width && 0 < model.height)
                && (
                  <div className="dimensions">
                    {model.width}
                    {' '}
                    {__('x')}
                    {' '}
                    {model.height}
                  </div>
                )
              }
              {('0:00' !== model.length)
                && (
                  <div className="dimensions">
                    {model.length}
                  </div>
                )
              }
              { model.edit
                && (
                  <a
                    className="edit-attachment"
                    /* eslint-disable max-len */
                    href={`/wp-admin/post.php?post=${model.post_id}&action=edit&image-editor`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    {__('Edit Image')}
                  </a>
                )
              }
            </div>
          </div>
        </div>
      )
    }
  </div>
);

export default Sidebar;
