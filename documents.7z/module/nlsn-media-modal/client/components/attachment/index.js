import styles from './style.css';

const { wp } = window;
const { Component } = wp.element;
const { __ } = wp.i18n;

class Attachment extends Component {
  onKeyPress({ key }) {
    const { select } = this.props;
    if ('Enter' === key || ' ' === key) {
      select();
    }
  }

  render() {
    const {
      post_id,
      post_title,
      thumbnail,
      alt,
      visible = true,
      selected,
      select,
    } = this.props;

    const baseClasses = 'attachment save-ready';
    const classes = `${baseClasses} ${visible ? '' : styles.hidden} ${selected ? 'selected details' : ''}`;

    return (
      <li
        key={post_id}
        data-id={post_id}
        role="checkbox"
        aria-checked={selected}
        aria-label={post_title}
        className={classes}
        onClick={select}
        onKeyPress={(e) => this.onKeyPress(e)}
        tabIndex="0"
      >
        <div className="attachment-preview js--select-attachment type-image">
          <div className="thumbnail">
            <div className="centered">
              <img src={thumbnail} alt={alt} />
            </div>
          </div>
        </div>
        { selected && (
          <button type="button" className="check" tabIndex="0">
            <span className="media-modal-icon" />
            <span className="screen-reader-text">{__('Deselect')}</span>
          </button>
        ) }
      </li>
    );
  }
}

export default Attachment;
