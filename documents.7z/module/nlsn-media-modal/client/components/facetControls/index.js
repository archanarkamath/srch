import styles from './style.css';

const { wp } = window;
const { Component, Fragment } = wp.element;

class FacetControls extends Component {
  constructor() {
    super();
    this.isChecked = this.isChecked.bind(this);
  }

  onChange(e, facet) {
    const { filters, enableFilter, disableFilter } = this.props;

    if (- 1 === filters[facet].indexOf(e.target.value)) {
      enableFilter(facet, e.target.value);
    } else {
      disableFilter(facet, e.target.value);
    }
  }

  isChecked(facet, key) {
    const { filters } = this.props;
    if (! filters[facet]) {
      return false;
    }
    return (- 1 !== filters[facet].indexOf(key));
  }

  render() {
    const { facets } = this.props;

    return (
      <div className={styles.facets}>
        {facets.map(({ facet, label, buckets }) => (
          <Fragment>
            {0 < buckets.length && (
              <div className={styles.facet}>
                <p className={styles.facetLabel}>{label}</p>
                <ul className={styles.facetColumn}>
                  {buckets.map(({ count, key, name }) => (
                    <li className={styles.facetRow}>
                      <label htmlFor={key} className={styles.facetRowLabel}>
                        <input
                          type="checkbox"
                          value={key}
                          key={key}
                          id={key}
                          checked={this.isChecked(facet, key)}
                          onChange={(e) => this.onChange(e, facet)}
                        />
                        {name}
                        {' '}
                        <span className={styles.documentCount}>
                          (
                          {count}
                          )
                        </span>
                      </label>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </Fragment>
        ))}
      </div>
    );
  }
}

export default FacetControls;
