import { DelayInput } from 'react-delay-input';
import queryMedia from '../../utils/query';
import Attachment from '../attachment';
import FacetControls from '../facetControls';
import Sidebar from '../sidebar';
import styles from './style.css';

const { wp } = window;
const { Component, Fragment } = wp.element;
const { __ } = wp.i18n;

class ESMediaSearchPane extends Component {
  constructor(props) {
    super(props);
    const { defaultFilters } = props;
    this.state = {
      lastQuery: '',
      posts: [],
      offset: 0,
      facets: [],
      facetKeys: [],
      filters: defaultFilters,
      noFilters: true,
      selection: 0,
    };
    this.onChange = this.onChange.bind(this);
    this.onScroll = this.onScroll.bind(this);
  }

  componentDidMount() {
    const { existing } = this.props;
    const { filters } = this.state;
    if (0 !== existing) {
      this.setSelection(existing);
    }
    this.query('', 0, filters, true, false);
  }

  onChange(e) {
    this.query(e.target.value);
  }

  onScroll(e) {
    const { lastQuery, offset, filters } = this.state;
    const { scrollTop, scrollHeight, offsetHeight } = e.target;
    const isBottom = (scrollTop === (scrollHeight - offsetHeight));
    if (isBottom) {
      this.query(lastQuery, offset + 40, filters, false, false);
    }
  }

  setSelection(post_id) {
    const { selection } = this.state;
    const { setModalSelection } = this.props;

    if (post_id === selection) {
      this.setState((prevState) => ({ ...prevState, selection: 0 }));
      setModalSelection(0);
      return;
    }

    this.setState((prevState) => ({ ...prevState, selection: post_id }));
    setModalSelection(post_id);
  }

  query(search = '', offset = 0, terms = {}, resetPosts = true, resetFilters = true) {
    const { setColumns } = this.props;
    const { filters: existingFilters } = this.state;

    queryMedia(search, offset, terms)
      .then(({ posts, facets, facetKeys }) => {
        setColumns();
        const filters = {};
        facetKeys.forEach((key) => {
          filters[key] = (resetFilters || ! existingFilters[key])
            ? [] : existingFilters[key];
        });
        this.setState((prevState) => ({
          ...prevState,
          lastQuery: search,
          posts: resetPosts ? posts : [...prevState.posts, ...posts],
          facets,
          facetKeys,
          filters,
          offset,
        }));
      });
  }

  disableFilter(facet, key) {
    const { filters, facetKeys, lastQuery } = this.state;

    const index = filters[facet].indexOf(key);

    filters[facet].splice(index, 1);

    let noFilters = true;
    facetKeys.forEach((k) => {
      if ('undefined' === typeof filters[k] || 0 !== filters[k].length) {
        noFilters = false;
      }
    });

    this.setState((prevState) => ({ ...prevState, filters, noFilters }));
    this.query(lastQuery, 0, filters, true, false);
  }

  enableFilter(facet, key) {
    const { filters, lastQuery } = this.state;
    filters[facet] = [...filters[facet], key];

    this.setState((prevState) => ({ ...prevState, filters, noFilters: false }));
    this.query(lastQuery, 0, filters, true, false);
  }

  testSelection(post_id) {
    const { selection } = this.state;
    return post_id === selection;
  }

  render() {
    const {
      posts, facets, filters, selection,
    } = this.state;
    return (
      <Fragment>
        <div className={styles.searchControls}>
          <DelayInput
            placeholder={__('Search media...')}
            onChange={this.onChange}
            minLength={2}
            delayTimeout={300}
          />
        </div>
        <FacetControls
          facets={facets}
          filters={filters}
          enableFilter={(facet, key) => this.enableFilter(facet, key)}
          disableFilter={(facet, key) => this.disableFilter(facet, key)}
        />
        <ul
          role="grid"
          tabIndex={- 1}
          className={styles.attachmentsContainer}
          onScroll={this.onScroll}
          onKeyPress={(e) => { e.preventDefault(); }}
        >
          {posts.map((post) => (
            <Attachment
              {...post}
              selected={this.testSelection(post.post_id)}
              select={() => this.setSelection(post.post_id)}
            />
          ))}
        </ul>
        <Sidebar
          selection={selection}
          model={posts.find(({ post_id }) => post_id === selection)}
        />
      </Fragment>
    );
  }
}
export default ESMediaSearchPane;
