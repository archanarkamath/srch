<?php
/**
 * Adapter for SearchPress
 *
 * @package ES_Media_Modal
 */

namespace ES_Media_Modal\Adapters;

/**
 * Provides the standard query interface used by AJAX endpoint to relay queries to ES.
 *
 * @param string $search       The string to be queried.
 * @param array  $post_type    An array of post types (strings) to limit the search to.
 * @param array  $post_status  An array of post statuses (strings) to limit the search to.
 * @param int    $count        The number of results to return.
 * @param int    $offset       An offset to begin returning search results from.
 * @param array  $terms        An array of terms (in format taxonomy => [ term1, term2, ... ]) to limit the search results to.
 * @param array  $fields       An array of fields (see ES _source docs for more details) to return.
 * @param array  $facets       An array of facets (now called aggregations) to return. See README for array format.
 * @return array The Elasticsearch server reply. See Elasticsearch docs for further details.
 */
function query_interface( $search, $post_type, $post_status, $count, $offset, $terms, $fields, $facets ) {
	$query = new \SP_WP_Search(
		[
			'query'          => $search,
			'post_type'      => $post_type,
			'post_status'    => $post_status,
			'posts_per_page' => $count,
			'offset'         => $offset,
			'terms'          => $terms,
			'fields'         => $fields,
			'facets'         => $facets,
		]
	);

	return $query->get_results();
}
