<?php
/**
 * Facets utilities.
 *
 * @package ES_Media_Modal
 */

namespace ES_Media_Modal\Facets;

/**
 * Retrieve facets.
 *
 * @return array
 */
function get_facets() {
	return apply_filters( 'es_media_modal_facets', [] );
}

/**
 * Retrieve facet filters.
 *
 * @return array
 */
function get_default_facet_filters() {
	return apply_filters( 'es_media_modal_default_facet_filters', [] );
}
