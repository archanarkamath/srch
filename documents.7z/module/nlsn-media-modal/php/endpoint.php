<?php
/**
 * Ajax endpoints
 *
 * @package ES_Media_Modal
 */

namespace ES_Media_Modal\Endpoint;

use function ES_Media_Modal\load_adapter;
use function ES_Media_Modal\Adapters\query_interface;

/**
 * Performs Elasticsearch query and returns data.
 */
function es_query() {
	global $wp_filesystem;

	if ( ! load_adapter() ) {
		wp_send_json_error( [ 'error' => __( 'No Elasticsearch adapter available.', 'es-media-modal' ) ] );
	}

	if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), ES_MEDIA_MODAL_SEARCH_NONCE ) ) { // phpcs:ignore WordPress.VIP.SuperGlobalInputUsage.AccessDetected
		wp_send_json_error( [ 'error' => __( 'Nonce verification failed', 'es-media-modal' ) ] );
	}

	if ( ! is_a( $wp_filesystem, 'WP_Filesystem_Base' ) ) {
		$creds = request_filesystem_credentials( site_url() );
		wp_filesystem( $creds );
	}

	// phpcs:disable WordPress.VIP.SuperGlobalInputUsage.AccessDetected
	$search = ! empty( $_POST['query'] ) ? sanitize_text_field( wp_unslash( $_POST['query'] ) ) : '';
	$offset = ! empty( $_POST['offset'] ) ? absint( $_POST['offset'] ) : 0;
	$terms  = ! empty( $_POST['terms'] ) ? json_decode( sanitize_text_field( wp_unslash( $_POST['terms'] ) ), true ) : [];
	// phpcs:enable WordPress.VIP.SuperGlobalInputUsage.AccessDetected

	foreach ( $terms as $taxonomy => $slugs ) {
		if ( empty( $slugs ) ) {
			unset( $terms[ $taxonomy ] );
		} else {
			$terms[ $taxonomy ] = implode( '+', $slugs );
		}
	}
	$facets = \ES_Media_Modal\Facets\get_facets();
	$labels = wp_list_pluck( $facets, 'label', 'taxonomy' );

	try {
		$results = query_interface(
			$search,
			[ 'attachment' ],
			[ 'publish', 'inherit' ],
			40,
			$offset,
			$terms,
			[ 'post_id', 'post_title', 'post_meta', 'terms' ],
			$facets
		);
	} catch ( Exception $e ) {
		wp_send_json_error( [ 'error' => $e->getMessage() ] );
	}

	$upload_dir = wp_get_upload_dir();
	$posts = [];

	if ( isset( $results['hits'] ) ) {
		foreach ( $results['hits'] as $hit ) {
			$thumbnail = $medium = $base_file_path = $filename = $filesize = $filetype = $alt = ''; // phpcs:ignore Squiz.PHP.DisallowMultipleAssignments.Found

			$attachment_id            = $hit['fields']['post_id'];
			$_wp_attached_file        = get_post_meta( $attachment_id, '_wp_attached_file', true );
			$_wp_attachment_metadata  = get_post_meta( $attachment_id, '_wp_attachment_metadata', true );
			$_wp_attachment_image_alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );


			if ( ! empty( $_wp_attached_file ) ) {
				$base_file_path = $upload_dir['baseurl'] . '/' . $_wp_attached_file;

				if ( ! empty( $_wp_attachment_metadata ) ) {
					if ( ! empty( $_wp_attachment_metadata['sizes']['thumbnail']['file'] ) ) {
						$parts = explode( '/', $base_file_path );
						array_splice( $parts, -1, 1, $_wp_attachment_metadata['sizes']['thumbnail']['file'] );
						$thumbnail = implode( '/', $parts );
					} else {
						$thumbnail = wp_get_attachment_thumb_url( $attachment_id );
					}

					// If still no thumbnail, this might be an audio file. Try for a MIME icon.
					// Purposefully using a false-y value here since it could be false or ''.
					if ( ! $thumbnail ) {
						$thumbnail = wp_mime_type_icon( $attachment_id );
					}

					if ( ! empty( $_wp_attachment_metadata['sizes']['medium']['file'] ) ) {
						$parts = explode( '/', $base_file_path );
						array_splice( $parts, -1, 1, $_wp_attachment_metadata['sizes']['medium']['file'] );
						$medium = implode( '/', $parts );
					} else {
						$src = wp_get_attachment_image_url( $attachment_id, 'medium' );
						if ( ! empty( $src[0] ) ) {
							$medium = $src[0];
						}
					}

					if ( ! empty( $_wp_attachment_metadata['file'] ) ) {
						$parts = explode( '/', $_wp_attachment_metadata['file'] );
					} else {
						$parts = explode( '/', $base_file_path );
					}
					$filename = array_pop( $parts );

					if ( ! empty( $_wp_attachment_metadata['file'] ) && $wp_filesystem->exists( $wp_filesystem->wp_content_dir() . 'uploads/' . $_wp_attachment_metadata['file'] ) ) {
						$filesize = size_format( $wp_filesystem->size( $wp_filesystem->wp_content_dir() . 'uploads/' . $_wp_attachment_metadata['file'] ) );
					} else {
						$filesize = size_format( $wp_filesystem->size( $base_file_path ) );
					}

					$filetype = get_post_mime_type( $attachment_id );
				} else {
					// Not an image, so _wp_attachment_metadata will not be available.
					$parts    = explode( '/', $base_file_path );
					$filename = array_pop( $parts );
					$filesize = size_format( $wp_filesystem->size( $base_file_path ) );
					$filetype = get_post_mime_type( $attachment_id );
					if ( $filetype ) {
						$thumbnail = wp_mime_type_icon( $attachment_id );
					}
				}

				if ( ! empty( $_wp_attachment_image_alt ) ) {
					$alt = $_wp_attachment_image_alt;
				}
			}

			$facet_ids = [];

			foreach ( array_keys( $facets ) as $facet_key ) {
				if ( ! isset( $hit['_source']['terms'][ $facet_key ] ) ) {
					$hit['_source']['terms'][ $facet_key ] = wp_get_post_terms( $attachment_id, $facet_key );
				}

				if ( ! empty( $hit['_source']['terms'][ $facet_key ] ) ) {
					$ids = wp_list_pluck( $hit['_source']['terms'][ $facet_key ], 'slug' );
				} else {
					$ids = [];
				}
				$facet_ids[ $facet_key ] = $ids;
			}

			$posts[] = array_merge(
				$facet_ids,
				[
					'post_id'    => $attachment_id,
					'post_title' => get_the_title( $attachment_id ),
					'thumbnail'  => $thumbnail,
					'medium'     => $medium,
					'width'      => ! empty( $image_meta['width'] ) ? intval( $image_meta['width'] ) : 0,
					'height'     => ! empty( $image_meta['height'] ) ? intval( $image_meta['height'] ) : 0,
					'length'     => ! empty( $image_meta['length_formatted'] ) ? $image_meta['length_formatted'] : '0:00',
					'filename'   => $filename,
					'filesize'   => $filesize,
					'filetype'   => $filetype,
					'date'       => get_the_date( 'F j, Y', $attachment_id ),
					'alt'        => $alt,
					'edit'       => current_user_can( 'edit_post', $attachment_id ),
				]
			);
		}
	}

	$facets     = [];
	$facet_keys = [];
	foreach ( $results['aggregations'] as $key => $agg ) {
		$facet = [
			'facet'   => $key,
			'label'   => $labels[ $key ],
			'buckets' => [],
		];

		foreach ( $agg['buckets'] as $bucket ) {
			$term = get_term_by( 'slug', $bucket['key'], $key );
			if ( $term ) {
				$facet['buckets'][] = [
					'key'   => $bucket['key'],
					'name'  => $term->name,
					'count' => $bucket['doc_count'],
				];
			}
		}

		$facets[]     = $facet;
		$facet_keys[] = $key;
	}

	wp_send_json(
		[
			'posts'     => $posts,
			'facets'    => $facets,
			'facetKeys' => $facet_keys,
		]
	);
}
add_action( 'wp_ajax_es_media_search', __NAMESPACE__ . '\es_query' );