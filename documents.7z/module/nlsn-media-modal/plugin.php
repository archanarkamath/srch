<?php
/**
 * Plugin Name: Elasticsearch Media Modal
 * Description: Deploys certain customizations for the Media Modal.
 * Text Domain: es-media-modal
 * Author: Alley
 * Author URI: https://alley.co
 *
 * @package ES_Media_Modal
 */

namespace ES_Media_Modal;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ES_MEDIA_MODAL_SEARCH_NONCE', 'es_media_modal_search' );

/**
 * Enqueues JS assets
 */
function es_media_modal_assets() {
	if ( false !== load_adapter() ) {
		wp_register_script( 'es_media_modal-js', plugins_url( '/dist/main.js', __FILE__ ), [], 1, true );
		wp_enqueue_script( 'es_media_modal-js' );

		wp_localize_script(
			'es_media_modal-js',
			'esMediaModalOpts',
			[
				'queryNonce' => wp_create_nonce( ES_MEDIA_MODAL_SEARCH_NONCE ),
			]
		);

		$default_filters = \ES_Media_Modal\Facets\get_default_facet_filters();
		if ( ! empty( $default_filters ) ) {
			wp_localize_script( 'es_media_modal-js', 'es_media_modal_default_filters', $default_filters );
		}
	}
}

/**
 * Load appropriate adapter. Default to SearchPress, but use Jetpack if available.
 *
 * @return string, or false if no adapter is available.
 */
function load_adapter() {
	$adapter = false;

	// VIP: Disabling SearchPress.
	//if ( class_exists( 'SP_WP_Search' ) ) {
	//	$adapter = 'searchpress';
	//}
	$adapter = 'jetpack';

	if ( $adapter ) {
		$filename = dirname( __FILE__ ) . '/adapters/adapter-' . $adapter . '.php';
	} else {
		$filename = false;
	}

	// Allow manual overriding of the adapter selection.
	$filename = apply_filters( 'es_media_modal_adapter', $filename );

	if ( $filename ) {
		require_once $filename; // phpcs:ignore WordPressVIPMinimum.Files.IncludingFile.UsingVariable
		if ( ! $adapter ) {
			$adapter = $filename;
		}
	}

	return $adapter;
}

add_action( 'enqueue_block_editor_assets', __NAMESPACE__ . '\es_media_modal_assets' );

// Includes.
require_once dirname( __FILE__ ) . '/php/endpoint.php';
require_once dirname( __FILE__ ) . '/php/facets.php';