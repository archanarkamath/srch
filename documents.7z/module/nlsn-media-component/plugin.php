<?php
/**
 * Plugin Name: Nielsen Media Component
 * Description: Customizes Gutenberg media component.
 * Text Domain: nlsn-media-component
 * Author: Alley
 * Author URI: https://alley.co
 *
 */

namespace Nielsen_Media_Component;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueues assets
 */
function assets() {
	wp_enqueue_style( 'nlsn-media-component-css', plugins_url( '/css/editor.css', __FILE__ ) );
}

add_action( 'enqueue_block_editor_assets', __NAMESPACE__ . '\assets' );
