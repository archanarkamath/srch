<?php
/*
Plugin Name: Related Categories Taxonomy
Description: Related Categories Taxonomy for WP Posts.
Plugin URI: http://www.nielsen.com
Version: 1.0.0
Author: Nielsen Dev Team
Author URI: http://www.nielsen.com/
*/

if ( ! function_exists( 'nlsn_related_categories' ) ) {

	// Register Custom Taxonomy
	function nlsn_related_categories() {

		$labels = array(
			'name'                       => _x( 'Related Categories', 'Taxonomy General Name', 'nlsn-related-categories' ),
			'singular_name'              => _x( 'Related Category', 'Taxonomy Singular Name', 'nlsn-related-categories' ),
			'menu_name'                  => __( 'Related Categories', 'nlsn-related-categories' ),
			'all_items'                  => __( 'All Related Categories', 'nlsn-related-categories' ),
			'parent_item'                => __( 'Parent Related Category', 'nlsn-related-categories' ),
			'parent_item_colon'          => __( 'Parent Related Category:', 'nlsn-related-categories' ),
			'new_item_name'              => __( 'New Related Category Name', 'nlsn-related-categories' ),
			'add_new_item'               => __( 'Add New Related Category', 'nlsn-related-categories' ),
			'edit_item'                  => __( 'Edit Related Category', 'nlsn-related-categories' ),
			'update_item'                => __( 'Update Related Category', 'nlsn-related-categories' ),
			'view_item'                  => __( 'View Related Category', 'nlsn-related-categories' ),
			'separate_items_with_commas' => __( 'Separate items with commas', 'nlsn-related-categories' ),
			'add_or_remove_items'        => __( 'Add or remove items', 'nlsn-related-categories' ),
			'choose_from_most_used'      => __( 'Choose from the most used', 'nlsn-related-categories' ),
			'popular_items'              => __( 'Popular Items', 'nlsn-related-categories' ),
			'search_items'               => __( 'Search Related Category', 'nlsn-related-categories' ),
			'not_found'                  => __( 'Not Found', 'nlsn-related-categories' ),
			'no_terms'                   => __( 'No Related Categories', 'nlsn-related-categories' ),
			'items_list'                 => __( 'Related Categories list', 'nlsn-related-categories' ),
			'items_list_navigation'      => __( 'Related Categories list navigation', 'nlsn-related-categories' ),
		);
		$args   = array(
			'labels'            => $labels,
			'hierarchical'      => true,
			'public'            => true,
			'show_ui'           => true,
			'show_admin_column' => true,
			'show_in_nav_menus' => true,
			'show_tagcloud'     => true,
		);
		register_taxonomy( 'related_categories', array( 'post' ), $args );

	}
	add_action( 'init', 'nlsn_related_categories', 0 );

}
