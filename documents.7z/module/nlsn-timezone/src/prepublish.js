const { registerPlugin } = wp.plugins;
const { PluginPrePublishPanel } = wp.editPost;
const {	Component } = wp.element;
const { withSelect } = wp.data;

import { __ } from '@wordpress/i18n';


class TimezoneViewPrePublish extends Component {
    render() {
        return (
            <PluginPrePublishPanel>
                <strong>{ __( 'Publish' ) } { this.props.tzAbbr }: </strong> 
                { this.props.prettyTime }
            </PluginPrePublishPanel>
        )
    }
}

const TimezonePrePublish = withSelect( ( select ) => {
    const { getTimeLocal, getTz, getTzAbbr, getTimeLocalPretty } = select( 'timezone' )
    return {
      timeLocal: getTimeLocal(),
      timezone: getTz(),
      tzAbbr: getTzAbbr(),
      prettyTime: getTimeLocalPretty(),
    }
  })( TimezoneViewPrePublish )
 
registerPlugin( 'pre-publish-time-timezone', { render: TimezonePrePublish } );
