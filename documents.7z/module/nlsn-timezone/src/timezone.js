import moment from 'moment';
import 'moment-timezone/moment-timezone';
import { dateI18n, __experimentalGetSettings } from '@wordpress/date';
import { __ } from '@wordpress/i18n';

const { apiFetch } = wp;
const { registerStore, select, dispatch } = wp.data;
const { getEditedPostAttribute } = wp.data.select("core/editor");

const TIMEZONELESS_FORMAT = 'YYYY-MM-DDTHH:mm:ss';

const DEFAULT_STATE = {
  timeGMT: getEditedPostAttribute("date"),
  timeLocal: '',
  timezone: '',
  timezoneAbbr: ''
};

const actions = {

  newTz( timezone ) {
    // get new abbreviation
    let timezoneAbbr = moment.tz( timezone ).zoneAbbr()
    // calculate new gmt time
    let timeTemp = moment.tz( select('timezone').getTimeLocal(), timezone )
    let timeGMT = timeTemp.tz( "UTC" ).format( TIMEZONELESS_FORMAT )
    dispatch('core/editor').editPost({ date: timeGMT, date_gmt: timeGMT, meta:{ post_meta_timezone: timezone } })
    // console.log( 'new tz: ' + timezoneAbbr + ' | gmt@ ' + timeGMT )

    return {
        type: 'NEW_TZ',
        timezone, timezoneAbbr, timeGMT
    };
  },

  setTz( timezone ) {
    // get the abbreviation
    let timezoneAbbr = moment.tz( timezone ).zoneAbbr()
    // calculate local time
    let timeGMT = moment.tz( getEditedPostAttribute("date"), "UTC" )
    let timeLocal = timeGMT.clone().tz( timezone )
    timeGMT = timeGMT.format( TIMEZONELESS_FORMAT ) 
    timeLocal = timeLocal.format( TIMEZONELESS_FORMAT ) 

    // console.log( 'set to ' + timezoneAbbr + ' | local@' + timeLocal + ' | gmt@' + timeGMT )

    return {
      type: 'SET_TZ',
      timezone, timezoneAbbr, timeLocal
    };
  },

  setTime( timeLocal ) {
      // calculate new gmt time
      let newLocal = moment.tz( timeLocal, select('timezone').getTz() )
      let timeGMT = moment.utc( newLocal ).format( TIMEZONELESS_FORMAT )
      // set local time, gmt time
      dispatch('core/editor').editPost( { date: timeGMT, date_gmt: timeGMT } )
        // console.log('set time, in gmt@ ' + timeGMT + ' local@ ' + newLocal.format( TIMEZONELESS_FORMAT ) )
      return {
          type: 'SET_TIME',
          timeGMT, timeLocal
      };
  },

  fetchFromAPI( path ) {
      return {
          type: 'FETCH_FROM_API',
          path,
      };
  },
};

registerStore( 'timezone', {
  reducer( state = DEFAULT_STATE, action ) {
      switch ( action.type ) {
          case 'SET_TZ':
            return {
              ...state,
              timezone: action.timezone,
              timezoneAbbr: action.timezoneAbbr,
              timeLocal: action.timeLocal,
            };
          case 'NEW_TZ':
            return {
              ...state,
              timezone: action.timezone,
              timezoneAbbr: action.timezoneAbbr,
              timeGMT: action.timeGMT,
            };
          case 'SET_TIME':
            return {
              ...state,
              timeLocal: action.timeLocal, 
              timeGMT: action.timeGMT,
            };
      }
      return state;
  },

  actions,

  selectors: {
    getTz( state ) {
      return state.timezone;
    },
    getTzAbbr( state ) {
      return state.timezoneAbbr;
    },
    getTimeLocal ( state ){
      if ( state.timeLocal ){
        return state.timeLocal
      } else {
        return state.timeGMT
      }
    },
    getTimeGMT( state ) {
      return state.timeGMT
    },
    getTimeLocalPretty( state ) {
      return select( 'core/editor' ).isEditedPostDateFloating() ? 
        __( 'Immediately' ) : dateI18n( "M j, Y g:ia", state.timeLocal )
    },
  },

  controls: {
      FETCH_FROM_API( action ) {
          return apiFetch( { path: action.path } );
      },
  },

  resolvers: {
      * getTz() {
        const response = yield getEditedPostAttribute("meta").post_meta_timezone
          // console.log( "response: " + response )
        if( response ){
          return actions.setTz( response )
        } else {
          return actions.setTz( 'Etc/GMT' )
        }
      },
  },
} );
