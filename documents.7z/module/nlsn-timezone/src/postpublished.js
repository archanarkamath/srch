const { registerPlugin } = wp.plugins;
const { PluginPostPublishPanel } = wp.editPost;
const { withSelect } = wp.data;

import { __ } from '@wordpress/i18n';

export function TimezoneViewPostPublish( { isScheduled, prettyTime, post } ) {
      const postPublishNonLinkHeader = 
          isScheduled ? 
          __( 'is now scheduled. It will go live on ' ) + prettyTime :
          __( 'is now live.' );

      return (
          <PluginPostPublishPanel>
              <a href={ post.link }>{ post.title || __( '(no title)' ) }</a> { postPublishNonLinkHeader }
          </PluginPostPublishPanel>
      )
}

const TimezonePostPublish = withSelect( ( select ) => {
  const { getTimeLocal, getTz, getTzAbbr, getTimeLocalPretty, } = select( 'timezone' )
  const { isCurrentPostScheduled, getCurrentPost, } = select( 'core/editor' );
  return {
    prettyTime: getTimeLocalPretty(),
    post: getCurrentPost(),
    isScheduled: isCurrentPostScheduled(),
  }
})( TimezoneViewPostPublish )

registerPlugin( 'post-publish-time-timezone', { render: TimezonePostPublish } );
