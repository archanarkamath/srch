const { registerPlugin } = wp.plugins;
const { PluginPostStatusInfo } = wp.editPost;
const {	Component } = wp.element;
const { withSelect } = wp.data;

import TimezonePicker from 'react-timezone';
import { __ } from '@wordpress/i18n';
import {  __experimentalGetSettings } from '@wordpress/date';
import { DateTimePicker, Button } from '@wordpress/components';

import { styles } from './styled';

class TimezoneSelect extends Component {
	constructor() {
      super( ...arguments );
      this._handleTZChange = this._handleTZChange.bind(this);
      this._handleLocalTimeChange = this._handleLocalTimeChange.bind(this);
    }

    _handleTZChange( tz ) {
      wp.data.dispatch('timezone').newTz( tz, this.props.timeLocal );
    }

    _handleLocalTimeChange( timeLocal ) {
      wp.data.dispatch('timezone').setTime( timeLocal );
    }

    render() {
      const is12HourTime = /a(?!\\)/i.test(
          __experimentalGetSettings().formats.time
              .toLowerCase() // Test only the lower case a
              .replace( /\\\\/g, '' ) // Replace "//" with empty strings
              .split( '' ).reverse().join( '' ) // Reverse the string and test for "a" not followed by a slash
      );

      return (
          <PluginPostStatusInfo className={ styles.plugin }>
              <div className={ styles.row }>
                  <span>
                      { __( 'Publish' ) } { this.props.tzAbbr }
                  </span>
                  <>
                  { this.props.prettyTime }
                  </>
              </div>
              <TimezonePicker                    
                value={ this.props.timezone }
                onChange={ timezone => this._handleTZChange( timezone ) }
                className={ styles.tz }
                inputProps={{
                    placeholder: 'Select Timezone...',
                    name: 'timezone',
                  }}
              />
              <DateTimePicker
                key="date-time-picker"
                currentDate={ this.props.timeLocal }
                onChange={ date => this._handleLocalTimeChange( date ) }
                is12Hour={ is12HourTime }
              />
          </PluginPostStatusInfo>
      )
    }
}

const TimezoneSelectinStatus = withSelect( ( select ) => {
    const { getTimeLocal, getTz, getTzAbbr, getTimeLocalPretty } = select( 'timezone' )
    return { 
      timeLocal: getTimeLocal(),
      timezone: getTz(),
      tzAbbr: getTzAbbr(),
      prettyTime: getTimeLocalPretty(),
    }
  })( TimezoneSelect )
 
registerPlugin( 'post-status-info-timezone', { render: TimezoneSelectinStatus } );

