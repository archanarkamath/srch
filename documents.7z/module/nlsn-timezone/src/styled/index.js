import styled, { css } from 'astroturf'

export const styles = css`
  .button {
    color: blue;
  }
  .plugin {
    flex-direction: column;
  }
  .row {
    width: 100%;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
  }
  .tz {
    margin-top: 10px;
    width: 100%;
  }
  .tz ul {
    background: white;
    z-index: 99;
    position: relative;
  }
  .tz input{
    font-size: 12px!important;
  }
  :global(.edit-post-post-schedule) {
    display: none;
  }
  :global(.components-datetime) {
    width: 100%;
    padding: 0;
    margin: 8px;
  }
  :global(.editor-post-publish-panel__prepublish :nth-child(4)) { 
    display:none; 
  }
  :global(.post-publish-panel__postpublish-header) { 
    display:none; 
  }
`