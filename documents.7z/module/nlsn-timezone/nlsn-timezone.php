<?php
/*
Plugin Name: Nielsen Timezone
Description: Uses local times in the frontend wp editor
Plugin URI: http://www.nielsen.com
Version: 2.0.0
Author: Nielsen Dev Team
Author URI: http://www.nielsen.com/
*/


namespace Nielsen\Timezone;

/**
 * Load timezone editor slotfill plugin
 * only if user can publish post
 */
add_action( 'plugins_loaded', function() {
    if( current_user_can( 'publish_posts' )){
        add_action(
            'init', function () {
                wp_register_script(
                    'nlsn-timezone-js',
                    plugin_dir_url(__FILE__) .'dist/app.js',
                    [
                        'wp-element',
                        'wp-i18n',
                        'wp-blocks',
                        'wp-components',
                        'wp-editor'
                    ],
                    filemtime( plugin_dir_path( __FILE__ ) . 'dist/app.js' ),
                    true
                );
                wp_register_style(
                    'nlsn-timezone-public-css',
                    plugin_dir_url(__FILE__) .'dist/app.css',
                    [],
                    filemtime( plugin_dir_path( __FILE__ ) . 'dist/app.css' )
                );
                register_block_type(
                    'nlsn/timezone', [
                        'editor_script' => 'nlsn-timezone-js',
                        'editor_style'  => 'nlsn-timezone-public-css',
                    ]
                );
            }
        );
    }
});

/**
 * Register post meta & rest api
 * 
 */
add_action( 'rest_api_init', function(){
	register_meta(
        'post',
        'post_meta_timezone',
        array(
			'type'		    => 'string',
			'single'	    => true,
			'show_in_rest'	=> true,
		)
	);
});

add_action( 'rest_api_init', function(){
    register_rest_route( 'timezone/v1', '/set', array(
        'methods'   => 'POST',
        'callback'  => __NAMESPACE__ . '\\set_post_timezone',
        'args'	    => array(
            'id'           => array(
                'sanitize_callback' => 'absint',
            ),
        ),
    ));
});

function set_post_timezone($data){
    return update_post_meta( $data['id'], 'post_meta_timezone', $data['tz'] );
}

/**
 * Add a timezone 
 * to all WordPress datetime functions
 * ONLY on frontend, when loading a template
 */
add_action( 'template_redirect', function(){ 
    add_filter( 'pre_option_timezone_string', function () {
        $tz = get_post_meta( get_the_ID(), 'post_meta_timezone', true );
        if( is_string( $tz ) ){
            return $tz;
        } else {
            return 'UTC';
        }
    } );
});

/**
 * Add admin notice if timezone isn't set to UTC
 * 
 */
add_action( 'admin_notices', function() {
    $class = 'notice notice-error';
    $tz = wp_timezone_string();
    $message = 'Change the global timezone setting to UTC!! Posts will currently publish at the wrong time! Global server timezone is set to: ' . $tz . '.';
    if ( $tz === '+00:00' || $tz === 'UTC' ) {
        return;
    } else {
        printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), esc_html( $message ) );
    }
} );
