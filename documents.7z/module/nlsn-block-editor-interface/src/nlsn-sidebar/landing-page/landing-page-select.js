import { CheckboxControl } from '@wordpress/components';
import { withSelect, withDispatch } from '@wordpress/data';
import { compose } from '@wordpress/compose';

export const LandingPageSelect = compose(

    withDispatch( function( dispatch, props ) {
		return {
			setMetaValue: function( metaValue ) {
                // disable or enable required fields
                if( metaValue ){
                    dispatch('required-fields').disable()
                } else {
                    dispatch('required-fields').enable()
                }
                dispatch( 'core/editor' ).editPost({ meta: { landing_page: metaValue }})
			}
		}
	} ),

    withSelect( function( select, props ) {
		return {
            landing_page: select( 'core/editor' ).getEditedPostAttribute( 'meta' )[ 'landing_page' ],
        }
	} ) )( function( props ) {

        return(
            <CheckboxControl
                label={ props.landing_page ? 'Page is a landing page.' : 'Set page as landing page!' }
                checked={ props.landing_page }
                onChange={ ( content ) => { props.setMetaValue( content ) } }
            />
        )
	}
);
