import { SelectControl } from '@wordpress/components';
import { withSelect, withDispatch, dispatch, select } from '@wordpress/data';
import { compose } from '@wordpress/compose';

export const CategorySelect = compose(

    withDispatch( function( dispatch, props ) {		
		return {
			setMetaValue: function( metaValue ) {
                dispatch( 'core/editor' ).editPost({ meta: { landing_page_options_content_category: metaValue }})
			}
		}
	} ),

    withSelect( function( select, props ) {
		return {
            terms: select('core').getEntityRecords('taxonomy', select( 'core/editor' ).getCurrentPostType() + '_categories' ),
            landing_page: select( 'core/editor' ).getEditedPostAttribute( 'meta' )[ 'landing_page' ],
            landing_page_options_content_category: select( 'core/editor' ).getEditedPostAttribute( 'meta' )[ 'landing_page_options_content_category' ],
            landing_page_options_type: select( 'core/editor' ).getEditedPostAttribute( 'meta' )[ 'landing_page_options_type' ],
		}
	}))( function( props ){

        if ( ! props.taxonomy || props.landing_page !== true || props.landing_page_options_type !== 'content-category' ){
            return null
		}
		
		let options = [];
		if( props.terms ) {
			options.push( { value: 0, label: 'Select category', key: 0 } );
			props.terms.forEach((term) => {
				options.push({ value: term.id, label: term.name, key: term.id });
			})
		} else {
			options.push( { value: 0, label: 'Loading...' } )
		}
 
		return(
            <SelectControl
                label='Select category:'
                value={ props.landing_page_options_content_category }
                onChange={ ( content ) => { props.setMetaValue( content ) } }
                options={ options }
            />
		)
	}
 
);