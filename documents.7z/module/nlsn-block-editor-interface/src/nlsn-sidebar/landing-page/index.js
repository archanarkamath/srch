
import { __ } from "@wordpress/i18n";
import { Panel, PanelHeader, PanelBody, PanelRow } from '@wordpress/components';
import { select, dispatch } from "@wordpress/data";

import config from './landing_page-config';
import { LandingPageSelect } from './landing-page-select';
import { LandingTypeSelect } from './landing-type-select';
import { CategorySelect } from './category-select';

export const LandingPageStatus = () => {

    // turn off required fields, if land page is set
    if ( select( 'core/editor' ).getEditedPostAttribute( 'meta' )[ 'landing_page' ] ){
        dispatch('required-fields').disable()
    }

    // get taxonomy from config
    const tax = config[ select( 'core/editor' ).getCurrentPostType() ];
    if( tax === undefined ){
        return null;
    }
    return (
        <Panel>
            <PanelBody title="Landing Page Settings">
                <LandingPageSelect/>
                <LandingTypeSelect taxonomy={tax} />
                <CategorySelect taxonomy={tax} />
            </PanelBody>
        </Panel>
    );
}