import { RadioControl } from '@wordpress/components';
import { withSelect, withDispatch } from '@wordpress/data';
import { compose } from '@wordpress/compose';

export const LandingTypeSelect = compose(

    withDispatch( function( dispatch, props ) {
		return {
			setMetaValue: function( metaValue ) {
                dispatch( 'core/editor' ).editPost({ meta: { landing_page_options_type: metaValue }})
			}
		}
	} ),

    withSelect( function( select, props ) {
		return {
            landing_page_options_type: select( 'core/editor' ).getEditedPostAttribute( 'meta' )[ 'landing_page_options_type' ],
            landing_page: select( 'core/editor' ).getEditedPostAttribute( 'meta' )[ 'landing_page' ]
        }
	} ) )( function( props ) {

        console.info( props.taxonomy )

        if ( ! props.landing_page ) { // landing page turned off by user
            return null;
        } else if ( props.taxonomy === false ) { // set false in landing_page-config.json
            return(
                <RadioControl
                    label={ props.landing_page_options_type === 'content-section' ? 'This page is the Content Section landing page.' : 'This is a landing page for a category.' }
                    selected={ props.landing_page_options_type }
                    options={ [
                        { label: 'Content Section', value: 'content-section' },
                    ] }
                    onChange={ ( content ) => { props.setMetaValue( content ) } }
                />
            )
        } else {
            return(
                <RadioControl
                    label={ props.landing_page_options_type === 'content-section' ? 'This page is the Content Section landing page.' : 'This is a landing page for a category.' }
                    selected={ props.landing_page_options_type }
                    options={ [
                        { label: 'Content Section', value: 'content-section' },
                        { label: 'Content Category', value: 'content-category' },
                    ] }
                    onChange={ ( content ) => { props.setMetaValue( content ) } }
                />
            )
        }
	}
);
