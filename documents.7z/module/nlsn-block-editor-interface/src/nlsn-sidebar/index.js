
import { registerPlugin } from "@wordpress/plugins";
import { PluginSidebar, PluginSidebarMoreMenuItem } from '@wordpress/edit-post';
import { __ } from "@wordpress/i18n";
import { select, subscribe } from "@wordpress/data";

import { nIcon } from './icons';
import { LandingPageStatus } from './landing-page/index';


// admin only
const unsubscribe = subscribe( () => {
    let isAdmin = select( 'core' ).canUser( 'create', 'users' );
    if( isAdmin ){
        unsubscribe();

        registerPlugin( 'nlsn-sidebar', {
            icon: nIcon,
            render: () => {
                return (
                    <>
                        <PluginSidebarMoreMenuItem target="nielsen-sidebar">
                            {__("Nielsen Admin Sidebar", "nielsen-sidebar")}
                        </PluginSidebarMoreMenuItem>
                        <PluginSidebar
                            name="nielsen-sidebar"
                            title="Admin Settings"
                        >
                            <LandingPageStatus />
                        </PluginSidebar>
                    </>
                )
            }
        } );

    }
})

