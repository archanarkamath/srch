import {
	get,
	unescape as unescapeString,
	without,
	find,
	some,
	invoke,
} from 'lodash';
const { __, _x, _n, sprintf } = wp.i18n;
const { SelectControl, Button } = wp.components;
const { select, dispatch } = wp.data;

/**
 * Higher order component for WP taxonomy select
 * renders a dropdown select 
 * 
 */
function selectTaxonomySelector(OriginalComponent) {
    return function(props) {
        if ([
			'formats',
			'formats_news_center',
			'insight_categories',
			'event_categories',
			'solution_categories',
			'news_center_categories',
			'about_us_categories',
			'page_categories',
			'panel_categories',
			'client_learning_categories',
			'top_ten_categories'
		].includes(props.slug)) {
            if (!window.HierarchicalTermSelector) {
				window.HierarchicalTermSelector = class HierarchicalTermSelector extends OriginalComponent {

				  // Return only the selected term ID
				  onChange(val) {
					const {
					  onUpdateTerms,
					  taxonomy
					} = this.props;
					const termId = parseInt(val, 10);
					if ( termId === 0 ){
						onUpdateTerms( [], taxonomy.rest_base );
					} else {
						onUpdateTerms( [termId], taxonomy.rest_base );
					}
				  }
				  
				  // Copied from HierarchicalTermSelector, changed to SelectControl
				  renderTerms(renderedTerms) {
					let { terms = [] } = this.props					
					return (
						<SelectControl 
							className = 'taxonomy-select'
							key = { `taxonomy-select-${ this.props.taxonomy.labels.singular_name }` }
							value = { terms[0] }
							onChange = { this.onChange }
							options = {
								[{ value: "0", label: `Select ${ this.props.taxonomy.labels.singular_name }` }]
								.concat( renderedTerms.map((term) => {
									return {
										value: term.id,
										label: term.name
									};
								}))
							}
						/>
					)
				  }
				  
				  render() {
					const {
						slug,
						taxonomy,
						instanceId,
						hasCreateAction,
						hasAssignAction,
					} = this.props;
			
					if ( ! hasAssignAction ) {
						return null;
					}
			
					const {
						availableTermsTree,
						availableTerms,
						filteredTermsTree,
						filterValue,
					} = this.state;

					const groupLabel = get(
						this.props.taxonomy,
						[ 'name' ],
						__( 'Terms' )
					);
			
					return [
						<div
							className="editor-post-taxonomies__dropdown-terms-list"
							key="term-list"
							tabIndex="0"
							role="group"
							aria-label={ groupLabel }
						>
							{ this.renderTerms(
								'' !== filterValue ? filteredTermsTree : availableTermsTree
							) }
						</div>,
					];
				}
				}
				}
				return <window.HierarchicalTermSelector { ...props } />;
			}
		return <OriginalComponent { ...props } />;
	};
}

wp.hooks.addFilter('editor.PostTaxonomyType', 'nlsn-taxonomy-select', selectTaxonomySelector);
