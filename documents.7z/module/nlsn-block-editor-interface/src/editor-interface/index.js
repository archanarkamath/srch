// gutenberg style and component adjustments
import './editor.scss';
import './editor-adjustments'
// new higher order components
import './select-taxonomy-selector'
