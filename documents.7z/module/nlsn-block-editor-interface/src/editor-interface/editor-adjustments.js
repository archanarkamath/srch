/**
 * put all minor adjustments to the editor here
 */
 wp.data.subscribe( () => {

	let saving = wp.data.select('core/editor').isSavingPost()
    let previewing = wp.data.select('core/editor').isPreviewingPost()
    let blockSelected = wp.data.select('core/block-editor').getSelectedBlock() 
    const postType = wp.data.select('core/editor').getCurrentPostType()  

    /**
     * NDCWP-876 
     * On save or preview and if post types
     * inserts subheading metablock if it's not present
     * 
     * may want to be replaced with a template 
     */
	if ( ( previewing || saving ) && ( postType === 'press_release' || postType === 'insight' ) ){
		const blocks = wp.data.select( 'core/block-editor' ).getBlocks()
		if ( blocks.some(e => e.name === 'nlsn-blocks/nlsn-subheading')) {
			return
		} else {
			wp.data.dispatch('core/block-editor').insertBlock(wp.blocks.createBlock('nlsn-blocks/nlsn-subheading'),0)
			wp.data.dispatch('core/editor').savePost();
		}
    }

    /**
     * NDCWP-984
     *
     * using CSS hack, unsupported 
     * 
     * when column selected, add class to body
     * CSS then hides col
     */
    const body = document.getElementsByTagName('body')[0]
	if ( blockSelected && blockSelected.name === "core/column" ){
		body.classList.add('hide-panel-body')
	} else if( blockSelected ) {
		body.classList.remove('hide-panel-body')
	}
	
})
