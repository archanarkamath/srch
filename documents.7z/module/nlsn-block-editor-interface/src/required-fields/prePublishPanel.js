
const { PluginPrePublishPanel } = wp.editPost;
const { useSelect, select, dispatch } = wp.data;

import * as icons from './icons';

export const NlsnPluginPrePublishPanel = () => {
	let requiredFields = select( 'required-fields' ).getFields();
	
	if( ! requiredFields ){
		return false;
	}

	const requiredItems = requiredFields.map((field) => {

		dispatch('required-fields').updateStatus();

		const selected = useSelect( select => {
			return select( 'core/editor' ).getEditedPostAttribute( field.slug )
		}, [ field.slug ]);

		if ( selected && selected[0] > 0 ) {
			return <li className="components-notice is-success" key={field.slug}>{icons.yesIcon} {field.pretty_name}</li>
		} else {
			return <li className="components-notice is-error" key={field.slug}>{icons.noIcon} {field.pretty_name}</li>
		}

	});

    return (
        <PluginPrePublishPanel>
			<h3>Required Sections</h3>
			<ul>{requiredItems}</ul>
        </PluginPrePublishPanel>
    )
}
