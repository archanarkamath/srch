const { select, dispatch, registerGenericStore } = wp.data;

import required from './config.json';
import { errorMessage } from './errorMessage';


/*
 * returns an array of required fields or false 
 */
export function requiredFields() {
    let storeChanged = () => {};
    let enabled = true;
    const currentPostType = select( 'core/editor' ).getCurrentPostType();
    const requiredAll = () => {
        let currentPostType = select( 'core/editor' ).getCurrentPostType();
        return required.required[ currentPostType ] === undefined ? required.required.all : required.required.all.concat( required.required[ currentPostType ] );
    }
    
    // lock or unlock post
    const checkStatus = () => {
        let lockPost = false;

        // create meessage 
        if ( enabled ){
            requiredAll().forEach( (field, index) => {
                let getRequiredTax = select( 'core/editor' ).getEditedPostAttribute( field.slug )
                if ( getRequiredTax && getRequiredTax.length === 0 ) {
                    lockPost === false ? lockPost = [field.pretty_name] : lockPost.push(field.pretty_name);
                }
            })
        }

        // actually lock post
        if( lockPost && select( 'core/editor' ).isCurrentPostPublished() ){
            dispatch( 'core/editor' ).lockPostSaving( 'requiredFields' );
            errorMessage( lockPost );
        } else if( lockPost ){
            dispatch( 'core/editor' ).lockPostSaving( 'requiredFields' );
        } else {
            dispatch( 'core/editor' ).unlockPostSaving( 'requiredFields' );
            dispatch('core/notices').removeNotice( 'required_taxonomy' );
        }
    }

    const selectors = {
        getFields() {
            return enabled ? requiredAll() : false;
        },
        isLocked() {
            return enabled;
        }
    };
 
    const actions = {
        disable() {
            enabled = false;
            checkStatus();
            storeChanged();
        },
        enable() {
            enabled = true;
            checkStatus();
            storeChanged();
        },
        updateStatus() {
            checkStatus();
            storeChanged();
        }
    };
 
    return {
        getSelectors() {
            return selectors;
        },
        getActions() {
            return actions;
        },
        subscribe( listener ) {
            storeChanged = listener;
        }
    };
}

