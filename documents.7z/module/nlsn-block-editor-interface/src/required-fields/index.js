/**
 * Enforces required fields
 * Controlled by config.json: per post type, set the slug & pretty name of a taxonomy
 *
 * todo: the notices could be refactored into independent components + withSelect
 * grabbing the tax from wp.data.select( 'core' ).getTaxonomy( field.slug )
 *
 */
import { registerPlugin } from '@wordpress/plugins';
import { select, dispatch, subscribe, withSelect, registerGenericStore } from '@wordpress/data';

import { requiredFields } from './requiredFields';
import './editor.scss';
import { NlsnPluginPrePublishPanel } from './prePublishPanel';

registerGenericStore( 'required-fields', requiredFields() );


// set listeners from json
let requiredAll = select('required-fields').getFields();
requiredAll.forEach( (field, index) => {
	// setting intial vars
	const getRequiredTax = () => select('core/editor').getEditedPostAttribute( field.slug );
	let requiredTax = getRequiredTax();
	// checking if taxonomy has changed
	subscribe( () => {
		if( requiredTax !== getRequiredTax() ) {
			requiredTax = getRequiredTax(); // break loop
			dispatch('required-fields').updateStatus();
		}
	})
	// run on load
	dispatch('required-fields').updateStatus();
})

registerPlugin( 'nlsn-pre-publish-panel', { render: NlsnPluginPrePublishPanel } )
