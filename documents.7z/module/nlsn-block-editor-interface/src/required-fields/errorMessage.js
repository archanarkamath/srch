const { select, dispatch } = wp.data;

export const errorMessage = ( required ) => {
    // build error message
    let errorText = ""
    required.forEach((field, index) => {
        let comma = index >= 1 ? ", " : " "
        errorText += comma + field
    })
    dispatch( 'core/notices' ).createErrorNotice(
        `Please make a selection for ${errorText} terms`, { id: 'required_taxonomy', }
    )
}
