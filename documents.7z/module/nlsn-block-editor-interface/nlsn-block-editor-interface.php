<?php
namespace Nlsn\EditorInterface;
/*
Plugin Name: Nielsen Block Editor Interface
Description: Modifies the WP block editor interface for nielsen.com
Plugin URI: http://www.nielsen.com
Version: 1.1.0
Author: Nielsen Dev Team
Author URI: http://www.nielsen.com/
*/

add_action('enqueue_block_editor_assets', function(){

    $asset_file = require( dirname( __FILE__ ) . "/build/index.asset.php" );

    wp_enqueue_script(
        'nlsn-block-editor-interface-js',
		plugins_url( 'build/index.js', __FILE__ ),
        $asset_file['dependencies'],
        $asset_file['version'],
        false
      );

    wp_enqueue_style(
        'nlsn-block-editor-interface-css',
        plugins_url( 'build/index.css', __FILE__ ),
        '',
        $asset_file['version']
    );

}, 0 );
