<?php
namespace Nlsn\Smart;

/**
 * Plugin Name: Nielsen Smart List
 * Description: Smart list block
 * Text Domain: nlsn-blocks
 * Author: Nielsen Dev Team
 * Author URI: https://nielsen.com/
 * Version: 1.3.0
 *
 */

define( __NAMESPACE__ . '\PLUGIN_URL', \plugins_url( '/', __FILE__ ) );


add_action( 'enqueue_block_assets', function(){
    wp_enqueue_style(
        'nlsn-smart-list',
        PLUGIN_URL . '/build/index.css',
        '',
        filemtime( plugin_dir_path( __FILE__ ) . '/build/index.css')
    );
});

add_action('enqueue_block_editor_assets', function(){

    $asset_file = include( plugin_dir_path( __FILE__ ) . 'build/index.asset.php');

    wp_enqueue_script(
        'nlsn-smart-list-js',
        PLUGIN_URL . 'build/index.js',
        ['lodash', 'wp-element', 'wp-polyfill', 'wp-primitives'],
        filemtime( plugin_dir_path( __FILE__ ) . '/build/index.js')
      );
});

include( plugin_dir_path( __FILE__ ) . 'src/index.php');
