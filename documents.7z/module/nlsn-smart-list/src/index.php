<?php
/**
 * Server-side rendering of the `nlsn-blocks/nlsn-smartlist` block.
 *
 * @package gutenberg
 */

/**
 * Renders the `nlsn-blocks/nlsn-smartlist` block on server.
 *
 * @param array $attributes The block attributes.
 *
 * @return string Returns the post content with latest posts added.
 */
function render_block_nlsn_blocks_nlsn_smartlist( $attributes ) {

	$tax_query   = array();
	$tax_query[] = array(
		'taxonomy' => 'post_visibility',
		'field'    => 'slug',
		'terms'    => 'hide_search',
		'operator' => 'NOT IN',
	);

	if ( ! empty( $attributes['categories'] ) ) {
		$categoryType = $attributes['postType'] . '_categories';
		$tax_query[]  = array(
			'taxonomy' => $categoryType,
			'field'    => 'term_id',
			'terms'    => $attributes['categories'],
		);
	}
	if ( ! empty( $attributes['tags'] ) ) {
		$relatedTag  = $attributes['postType'] . '_related_tags';
		$tax_query[] = array(
			'taxonomy' => $relatedTag,
			'field'    => 'term_id',
			'terms'    => $attributes['tags'],
		);
	}

	// For published posts in preview, learn more url will use current post market
	$post_status = get_post_status( get_the_ID() );
	if ( isset( $attributes['displaySmByPostMarketLanguage'] ) && $attributes['displaySmByPostMarketLanguage'] === true ) {
		if ( ! is_preview() || 'publish' === $post_status ) {
			$url_realtive_path = '';
			$result            = '';
			$market_slug       = '';

			$url_realtive_path = get_post_permalink( get_the_ID() );
			$url_realtive_path = explode( get_home_url(), $url_realtive_path );

			if ( isset( $url_realtive_path[1] ) ) {
				$result = explode( '/', $url_realtive_path[1] );
				if ( isset( $result ) ) {
					$market_slug = $result[1];
				}
			}
			if ( isset( $market_slug ) ) {
				$market_term = get_term_by( 'slug', $market_slug, 'markets' );

				if ( isset( $market_term ) ) {
					$attributes['marketsSelected'] = array( $market_term->term_id );
					$attributes['marketPrimary'] = $market_term->slug; // Get the slug for learn more url
				}
			}
		}
	}

	if ( ! empty( $attributes['marketsSelected'] ) || ( isset( $attributes['marketsSelected'][0] ) && ! $attributes['marketsSelected'][0] === [''] ) ) {
		$tax_query[] = array(
			'taxonomy' => 'markets',
			'field'    => 'term_id',
			'terms'    => $attributes['marketsSelected'],
		);
	}

	if ( ! empty( $attributes['languagesSelected'] ) || ( isset( $attributes['languagesSelected'][0] ) && ! $attributes['languagesSelected'][0] === array( '' ) ) ) {
		$tax_query[] = array(
			'taxonomy' => 'languages',
			'field'    => 'term_id',
			'terms'    => $attributes['languagesSelected'],
		);
	}
	if ( ! empty( $attributes['formats'] ) ) {
		$tax_query[] = array(
			'taxonomy' => 'formats',
			'field'    => 'term_id',
			'terms'    => $attributes['formats'],
		);
	}
	if ( ! empty( $attributes['businessTerm'] ) ) {
		$tax_query[] = array(
			'taxonomy' => 'business',
			'field'    => 'term_id',
			'terms'    => $attributes['businessTerm'],
		);
	}
	if ( count( $tax_query ) > 1 ) {
		$tax_query['relation'] = 'AND';
	}

	// Check toggle open in new for Learn More Button.
	if ( $attributes['openInNewTab'] === true ) {
		$open_in_new = '_blank';
	} else {
		$open_in_new = '';
	}
	/**
	  * Refactor the $results, the previous way is not good for complex multi meta query.
	  * Instead putting arguments array inside of get_post(), build the argument first and separate
	  * In order to add more arrays into meta query
	  * Compare operator NOT LIKE is working only with single value, but not array
	  * To be able to compare arrays in meta query, after building arguments, loop thru array and add properties to meta query
	  */

	if ( isset( $attributes['postType'] ) && $attributes['postType'] !== '' ) {
		if ( $attributes['enableFeaturedPosts'] === 'show-featured' ) {

			// Create an arg first and then get posts with the args
			$results_args = array(
				'post_type'        => $attributes['postType'],
				'tax_query'        => $tax_query,
				'orderby'          => $attributes['orderBy'],
				'order'            => $attributes['order'],
				'numberposts'      => $attributes['postsToShow'],
				'has_password'     => false,
				'suppress_filters' => false,
				'meta_query'       => array(
					'relation' => 'AND',
					array(
						'key'     => 'article_featured',
						'value'   => true,
						'compare' => '=',

					),
				),
			);
			$market_selected_list = $attributes['marketsSelected'];
			if ( $market_selected_list ) {
				foreach ( $market_selected_list as $taxonomy ) {

					// Add each item from market_selected_list to the meta query because NOT LIKE is not comparing all the values from an array at once, had to loop thru the array
					$results_args['meta_query'][] = array(
						'key'     => 'article_exclude_markets',
						'value'   => $taxonomy,
						'compare' => 'NOT LIKE',
					);

				}
			}
			// Output the posts
			$results = get_posts( $results_args );

		} elseif ( $attributes['enableFeaturedPosts'] === 'non-featured' ) {
			$results = get_posts(
				array(
					'post_type'        => $attributes['postType'],
					'tax_query'        => $tax_query,
					'orderby'          => $attributes['orderBy'],
					'order'            => $attributes['order'],
					'numberposts'      => $attributes['postsToShow'],
					'has_password'     => false,
					'suppress_filters' => false,
					'meta_query'       => array(
						array(
							'key'     => 'article_featured',
							'compare' => 'NOT EXISTS',
						),
					),

				)
			);

		} else {
			$results = get_posts(
				array(
					'post_type'        => $attributes['postType'],
					'tax_query'        => $tax_query,
					'orderby'          => $attributes['orderBy'],
					'order'            => $attributes['order'],
					'numberposts'      => $attributes['postsToShow'],
					'has_password'     => false,
					'suppress_filters' => false,
				)
			);
		}
	};

	/**
	 * For Categories
	 */
	// Define button variable
	$button_markup = '';

	if ( isset( $attributes['listType'] ) && $attributes['listType'] === 'list-of-categories' ) {
		$categoryType      = $attributes['postType'] . '_categories';
		$categories        = get_terms(
			array(
				'taxonomy'   => $categoryType,
				'hide_empty' => false,
			)
		);
		$list_items_markup = '';

		// HTML Rendering
		if ( ! is_wp_error( $categories ) ) {
			foreach ( $categories as $category ) {
				$category_name = $category->name;
				$page_id       = get_the_id();
				$market        = wp_get_post_terms( $page_id, 'markets' )[0]->slug;
				$language      = wp_get_post_terms( $page_id, 'languages' )[0]->slug;
				$postType      = $attributes['postType'];
				$category_url  = '/' . $market . '/' . $language . '/' . $postType . '/' . $category_name;
				if ( ! $category_name ) {
					$category_name = __( '(Untitled)', 'gutenberg' );
				}
				$list_items_markup .= sprintf(
					'<li><a target="_blank" href="%1$s">%2$s</a>',
					esc_url( $category_url ),
					esc_html( $category_name )
				);
				$list_items_markup .= "</li>\n";
			}
		}

		// HTML Classes Rendering
		$class = 'wp-block-nlsn-blocks-nlsn-smartlist';
		if ( isset( $attributes['align'] ) ) {
			$class .= ' align' . $attributes['align'];
		}

		// if NOT grid
		if ( isset( $attributes['postLayout'] ) && 'grid' !== $attributes['postLayout'] ) {
			$class .= ' link-list nav';
		}

		// if grid
		if ( isset( $attributes['postLayout'] ) && 'grid' === $attributes['postLayout'] ) {
			$class .= ' is-grid';
		}

		if ( isset( $attributes['columns'] ) && 'grid' === $attributes['postLayout'] ) {
			$class .= ' columns-' . $attributes['columns'];
		}

		// add block name
		if ( isset( $attributes['className'] ) ) {
			$class .= ' ' . $attributes['className'];
		}

		// compile everything
		if ( isset( $attributes['postType'] ) && $attributes['postType'] !== '' ) {
			$block_content = sprintf(
				'<h2>%1$s</h2><div class="module"><ul class="%2$s">%3$s</ul></div>',
				esc_html( $attributes['title'] ),
				esc_attr( $class ),
				$list_items_markup
			);
		};

		// HTML Button Rendering, using non relative URL
		$homeUrl = get_home_url();
        $url = $homeUrl . $attributes['learnMoreUrl'];
		// use post market in Learn More URL
		if ( isset( $attributes['displaySmByPostMarketLanguage'] ) && $attributes['displaySmByPostMarketLanguage'] === true ) {
			$primary_market = $attributes['marketPrimary'] . '&language';
			$temp = explode( '=' ,$url );
			$temp[2] = $primary_market; // replace the url market with post market
			$url = implode( '=', $temp );
		}
		if ( $attributes['enableLearnMoreButton'] === true && $attributes['customLearnMoreUrl'] === '' ) {
			$button_markup .= sprintf(
				'<div><a class="content-button btn regular btn-blue" target="%3$s" href="%1$s">%2$s</a></div>',
				esc_url( $url ),
				esc_html( $attributes['learnMoreText'] ),
				esc_attr( $open_in_new )
			);
		} elseif ( $attributes['enableLearnMoreButton'] === true && $attributes['customLearnMoreUrl'] !== '' ) {
			$button_markup .= sprintf(
				'<div><a class="content-button btn regular btn-blue" href="%1$s" target="%3$s">%2$s</a></div>',
				esc_url( $attributes['customLearnMoreUrl'] ),
				esc_html( $attributes['learnMoreText'] ),
				esc_attr( $open_in_new )
			);
		}

		$block_content .= $button_markup;

		return $block_content;

	} elseif ( $attributes['postLayout'] === 'grid' ) {
		// list types that render posts, not categories in grid-view
		$items_content = '';
		$block_content = '';

		// HTML Rendering
		foreach ( $results as $post ) {
			$post_id           = $post->ID;
			$post_url          = get_permalink( $post_id );
			$post_meta         = get_post_meta( $post_id );
			// definning all these so don't get null errors
			$results            = [];
			$final_description  = '';
			$read_more_content  = '';
			$img_element        = '';
			$term_slug          = '';
			$nlsn_taxonomy_translation_format = '';

			if ( $attributes['displayItemThumbnail'] === true ) {
				// if no meta_image, use main image, otherwise, use default
				if ( wp_get_attachment_image_url( $post_meta['meta_image'][0] ) ) {
					$image_url = wp_get_attachment_image_url( $post_meta['meta_image'][0], [364,205] );
					$srcset = wp_get_attachment_image_srcset( $post_meta['meta_image'][0] );
					$srcsetsizes = wp_get_attachment_image_sizes( $post_meta['meta_image'][0], [364,205] );
				} else if (  get_the_post_thumbnail_url( $post_id ) ) {
					$image_id = get_post_thumbnail_id( $post_id );
					$image_url = get_the_post_thumbnail_url( $post_id, [364,205] );
					$srcset = wp_get_attachment_image_srcset( $image_id );
					$srcsetsizes = wp_get_attachment_image_sizes( $image_id, [364,205] );
				} else {
					$srcset = '';
					$srcsetsizes = '';
					$image_url = '/wp-content/themes/nielsen-base/dist/images/open-graph-default.png';
				}
				$img_element = '<div class="img-wrap ratio-16-9"><div class="img-content"><img class="img-fluid" src="' . esc_url( $image_url ) . '" srcset="' . esc_attr( $srcset ). '" sizes="' . esc_attr( $srcsetsizes ) . '" ></div></div>';
			};

			// add the title
			$final_title = empty( $post_meta['meta_title'][0] ) ? $post->post_title : $post_meta['meta_title'][0];

			if ( $attributes['postLayout'] === 'grid' && $attributes['displayItemDescription'] === true ) {
				if ( ! empty( $post_meta['meta_description'][0] ) ) {
					$final_description = nlsn_custom_excerpt_length( $post_meta['meta_description'][0] );
				} else {
					$post_excerpt = get_the_excerpt( $post->ID );
					$final_description = $post_excerpt === 'Excerpt' ? nlsn_custom_excerpt_length( $post->post_content ) : nlsn_custom_excerpt_length( $post_excerpt );
				}
			}

			// if display format is enabled, render individual format to the grid view.
			if ( $attributes['postLayout'] === 'grid' && $attributes['displayFormat'] === true ) {
				$cpt_taxonomies = array( 'formats' );

				foreach ( $cpt_taxonomies as $cpt_taxonomy ) {
					$cpt_terms = wp_get_post_terms( $post_id, $cpt_taxonomy );

					if ( ! is_wp_error( $cpt_terms ) ) {

						$format_list_markup  = '';
						$format_list_markup .= '<div class="entry-meta h5">';
						$numItems            = count( $cpt_terms );
						$i                   = 0;

						foreach ( $cpt_terms as $term ) {
							if ( ++$i === $numItems ) {

								$term_link = get_term_link( $term );
								$term_slug = $term->slug;
								
								if ( ! empty( $term_link ) ) {

									$nlsn_taxonomy_translation_format = nlsn_taxonomy_translation( 'formats', 'format', $term );

									// add the individual formats
									$format_list_markup .= sprintf(
										'<span class="taxonomy-term knockout"><a style="color: #00aeef" href="%1$s">%2$s</a></span>',
										esc_url( $term_link ),
										esc_html( $nlsn_taxonomy_translation_format )
									);
								}
							} else {
								$term_link = get_term_link( $term );
								if ( ! empty( $term_link ) ) {

									$nlsn_taxonomy_translation_format = nlsn_taxonomy_translation( 'formats', 'format', $term );

									// add the individual categories
									$format_list_markup .= sprintf(
										'<span class="taxonomy-term knockout"><a style="color: #00aeef" href="%1$s">%2$s</a> | </span>',
										esc_url( $term_link ),
										esc_html( $nlsn_taxonomy_translation_format )
									);
								}
							}

						}
					}
				}
			}

			// if display category is enabled, render individual category to the grid view.
			if ( $attributes['postLayout'] === 'grid' && $attributes['displayCategory'] === true ) {

				$cpt_taxonomies = array( $post->post_type . '_categories' );

				foreach ( $cpt_taxonomies as $cpt_taxonomy ) {
					$cpt_terms = wp_get_post_terms( $post_id, $cpt_taxonomy );

					if ( ! is_wp_error( $cpt_terms ) ) {

						// add the beginning part of the category/date section
						$category_list_markup  = '';
						$category_list_markup .= '<div class="entry-meta h5">';

						$numItems = count( $cpt_terms );
						$i        = 0;

						foreach ( $cpt_terms as $term ) {
							if ( ++$i === $numItems ) {

								$term_link = get_term_link( $term );
								if ( ! empty( $term_link ) ) {

									$nlsn_taxonomy_translation_category = nlsn_taxonomy_translation( $post->post_type . '_categories', 'category', $term );

									// add the individual categories
									$category_list_markup .= sprintf(
										'<span class="taxonomy-term knockout"><a style="color: #00aeef" href="%1$s">%2$s</a></span>',
										esc_url( $term_link ),
										esc_html( $nlsn_taxonomy_translation_category )
									);
								}
							} else {

								$term_link = get_term_link( $term );
								if ( ! empty( $term_link ) ) {

									$nlsn_taxonomy_translation_category = nlsn_taxonomy_translation( $post->post_type . '_categories', 'category', $term );

									// add the individual categories
									$category_list_markup .= sprintf(
										'<span class="taxonomy-term knockout"><a style="color: #00aeef" href="%1$s">%2$s</a> | </span>',
										esc_url( $term_link ),
										esc_html( $nlsn_taxonomy_translation_category )
									);

								}
							}
						}
					}
				}
			}

			// if read more buttons enabled, add it
			if ( $attributes['postLayout'] === 'grid' && $attributes['enableReadMoreButton'] === true ) {

				$readMoreText = $attributes['readMoreText'];

				$read_more_content = sprintf(
					'<div class="related-read-more"><a class="more-link" href="%1$s" title="%2$s">%3$s</a></div>',
					esc_url( $post_url ),
					esc_html( $final_title ),
					esc_html( $readMoreText )
				);

			}

			// compile everything
			if ( isset( $attributes['columns'] ) && 'grid' === $attributes['postLayout'] && $attributes['displayCategory'] === true && $attributes['displayFormat'] === true ) {
				$column_class = ' col-md-' . $attributes['bootstrap_columns'] . ' p-2';

				if ( $attributes['displayItemThumbnail'] === true ) {
					$items_content .= sprintf(
						'<div class="%1$s p-2"><div class="related-post">
              <div class="smt-format-wrapper" style="position: relative;"><a href="%2$s">%3$s</a><h5 class="formats taxonomy-term knockout d-flex align-items-center text-center mb-0 smt-format" style="position: absolute; bottom: 0;"><span class="format %9$s"></span><a class="format-link text-white">%8$s</a></h5></div><div class="related-entry-summary bg-white" style="padding: 1rem 1rem 1rem 0"><span class="taxonomy-term knockout"><h5 style="color: #333; font-family: Open Sans,Helvetica Neue,Helvetica,Arial,sans-serif; font-weight: bold; text-transform: capitalize; font-size: 16px;">%7$s</h5></span><div class="related-title"><h3><a href="%2$s" title="%4$s">%4$s</a></h3></div><div class="related-excerpt" style="color: black;"><p class="mb-2">%5$s</p></div>%6$s</div></div></div>',
						esc_attr( $column_class ),
						esc_url( $post_url ),
						 $img_element ,
						esc_html( $final_title ),
						esc_html( $final_description ),
						$read_more_content,
						esc_html( $nlsn_taxonomy_translation_category ),
						esc_html( $nlsn_taxonomy_translation_format ),
						esc_html( $term_slug )
					);
				} elseif ( $attributes['displayItemThumbnail'] === false ) {
					$items_content .= sprintf(
						'<div class="%1$s p-2"><div class="related-post">
              <div class="smt-format-wrapper"><a href="%2$s">%3$s</a><h5 class="formats taxonomy-term knockout d-flex align-items-center text-center mb-0 smt-format"><span class="format %9$s"></span><a class="format-link text-white">%8$s</a></h5></div><div class="related-entry-summary bg-white " style="padding: 1rem 1rem 1rem 0"><span class="taxonomy-term knockout"><h5 style="color: #333; font-family: Open Sans,Helvetica Neue,Helvetica,Arial,sans-serif; font-weight: bold; text-transform: capitalize; font-size: 16px;">%7$s</h5></span><div class="related-title"><h3><a href="%2$s" title="%4$s">%4$s</a></h3></div><div class="related-excerpt" style="color: black;"><p class="mb-2">%5$s</p></div>%6$s</div></div></div>',
						esc_attr( $column_class ),
						esc_url( $post_url ),
						 $img_element ,
						esc_html( $final_title ),
						esc_html( $final_description ),
						$read_more_content,
						esc_html( $nlsn_taxonomy_translation_category ),
						esc_html( $nlsn_taxonomy_translation_format ),
						esc_html( $term_slug )
					);
				}
			} elseif ( isset( $attributes['columns'] ) && 'grid' === $attributes['postLayout'] && $attributes['displayCategory'] === true ) {
					$column_class = ' col-md-' . $attributes['bootstrap_columns'] . ' p-2';
					$items_content .= sprintf(
						'<div class="%1$s p-2"><div class="related-post">
            <a href="%2$s">%3$s</a><div class="related-entry-summary bg-white" style="padding: 1rem 1rem 1rem 0"><span class="taxonomy-term knockout"><h5 style="color: #333; font-family: Open Sans,Helvetica Neue,Helvetica,Arial,sans-serif; font-weight: bold; text-transform: capitalize; font-size: 16px;">%7$s</h5></span><div class="related-title"><h3><a href="%2$s" title="%4$s">%4$s</a></h3></div><div class="related-excerpt" style="color: black;"><p class="mb-2">%5$s</p></div>%6$s</div></div></div>',
						esc_attr( $column_class ),
						esc_url( $post_url ),
						 $img_element ,
						esc_html( $final_title ),
						esc_html( $final_description ),
						$read_more_content,
						esc_html( $nlsn_taxonomy_translation_category )
					);
			} elseif ( isset( $attributes['columns'] ) && 'grid' === $attributes['postLayout'] && $attributes['displayFormat'] === true ) {
				$column_class = ' col-md-' . $attributes['bootstrap_columns'] . ' p-2';

				$items_content .= sprintf(
					'<div class="%1$s p-2"><div class="related-post">
            <div class="smt-format-wrapper" style="position: relative;"><a href="%2$s">%3$s</a><h5 class="formats taxonomy-term knockout d-flex align-items-center text-center mb-0 smt-format" style="position: absolute; bottom: 0;"><span class="format %8$s"></span><a class="format-link text-white">%7$s</a></h5></div><div class="related-entry-summary bg-white" style="padding: 1rem 1rem 1rem 0"><div class="related-title"><h3><a href="%2$s" title="%4$s">%4$s</a></h3></div><div class="related-excerpt" style="color: black;"><p class="mb-2">%5$s</p></div>%6$s</div></div></div>',
					esc_attr( $column_class ),
					esc_url( $post_url ),
					 $img_element ,
					esc_html( $final_title ),
					esc_html( $final_description ),
					$read_more_content,
					esc_html( $nlsn_taxonomy_translation_format ),
					esc_html( $term_slug )
				);
			} elseif ( isset( $attributes['columns'] ) && 'grid' === $attributes['postLayout'] ) {
				$column_class = ' col-md-' . $attributes['bootstrap_columns'] . ' p-2';

				$items_content .= sprintf(
					'<div class="%1$s p-2"><div class="related-post">
            <a href="%2$s">%3$s</a><div class="related-entry-summary bg-white" style="padding: 1rem 1rem 1rem 0"><div class="related-title"><h3><a href="%2$s" title="%4$s">%4$s</a></h3></div><div class="related-excerpt" style="color: black;"><p class="mb-2">%5$s</p></div>%6$s</div></div></div>',
					esc_attr( $column_class ),
					esc_url( $post_url ),
					 $img_element ,
					esc_html( $final_title ),
					esc_html( $final_description ),
					$read_more_content
				);
			}
		}

		// HTML Classes Rendering
		$class = 'wp-block-nlsn-blocks-nlsn-smartlist ';
		if ( isset( $attributes['align'] ) ) {
			$class .= ' align' . $attributes['align'];
		}

		// if NOT grid
		if ( isset( $attributes['postLayout'] ) && 'grid' !== $attributes['postLayout'] ) {
			$class .= ' link-list nav';
		}

		// if grid
		if ( isset( $attributes['postLayout'] ) && 'grid' === $attributes['postLayout'] ) {
			$class .= ' is-grid';
		}

		// add block name
		if ( isset( $attributes['className'] ) ) {
			$class .= ' ' . $attributes['className'];
		}

		// compile everything
		if ( isset( $attributes['title'] ) ) {
			$block_content = sprintf(
				'<h2>%1$s</h2><div class="entry-related-posts module row %2$s">%3$s</div>',
				esc_html( $attributes['title'] ),
				esc_attr( $class ),
				$items_content
			);
		} else {
			$block_content = sprintf(
				'<div class="entry-related-posts module row %1$s">%2$s</div>',
				esc_attr( $class ),
				$items_content
			);
		}

		// HTML Button Rendering, using non relative URL
		$homeUrl = get_home_url();
        $url = $homeUrl . $attributes['learnMoreUrl'];
		// use post market in Learn More URL
		if ( isset( $attributes['displaySmByPostMarketLanguage'] ) && $attributes['displaySmByPostMarketLanguage'] === true ) {
			$primary_market = $attributes['marketPrimary'] . '&language';
			$temp = explode( '=' ,$url );
			$temp[2] = $primary_market; // replace the url market with post market
			$url = implode( '=', $temp );
		}
		if ( $attributes['enableLearnMoreButton'] === true && $attributes['customLearnMoreUrl'] === '' ) {
			$button_markup .= sprintf(
				'<div><a class="content-button btn regular btn-blue" target="%3$s" href="%1$s">%2$s</a></div>',
				esc_url( $url ),
				esc_html( $attributes['learnMoreText'] ),
				esc_attr( $open_in_new )
			);
			$block_content .= $button_markup;
		} elseif ( $attributes['enableLearnMoreButton'] === true && $attributes['customLearnMoreUrl'] !== '' ) {
			$button_markup .= sprintf(
				'<div><a class="content-button btn regular btn-blue" href="%1$s" target="%3$s">%2$s</a></div>',
				esc_url( $attributes['customLearnMoreUrl'] ),
				esc_html( $attributes['learnMoreText'] ),
				esc_attr( $open_in_new )
			);
			$block_content .= $button_markup;
		}

		return $block_content;

	} else {   // list types that render posts, not categories in list-view

		$list_items_markup = '';

		// add list title
		if( isset( $attributes['title'] ) && isset( $attributes['postType'] ) && $attributes['postType'] !== '' ){
			if( $attributes['enableFeaturedPosts'] === 'show-featured' && $attributes['postType'] === 'insight'){
				$list_items_markup .= sprintf(
					'<h2>%1$s</h2><h1 class="mb-5" style="color: #3e484e">FEATURED INSIGHTS</h1>', 
					esc_html( $attributes['title'] ) 
				);
			} elseif ($attributes['enableFeaturedPosts'] === 'show-featured' && $attributes['postType'] === 'news_center' ){
				$list_items_markup .= sprintf(
					'<h2>%1$s</h2><h1 class="mb-5" style="color: #3e484e">FEATURED NEWS</h1>', 
					esc_html( $attributes['title'] ) 
				);
			} else {
			  $list_items_markup .= sprintf(
				'<h2>%1$s</h2>',
				esc_html( $attributes['title'] )
			  );
			}
		}

		// HTML Rendering
		foreach ( $results as $post ) {
			$post_id           = $post->ID;
			$post_url          = get_permalink( $post_id );
			$post_meta         = get_post_meta( $post_id );
			$final_description = '';
			$read_more_content = '';

			// beginning of li tag
			if ( $attributes['enableFeaturedPosts'] === 'show-featured' ) {
				$list_items_markup .= '<li class="nielsen-post">';
			} else {
				$list_items_markup .= '<li>';
			}

			// if display format is enabled, render individual format to the list view.
			if ( $attributes['displayFormat'] === true ) {
				$cpt_taxonomies = array( 'formats' );

				foreach ( $cpt_taxonomies as $cpt_taxonomy ) {
					$cpt_terms = wp_get_post_terms( $post_id, $cpt_taxonomy );

					if ( ! is_wp_error( $cpt_terms ) ) {
						$format_list_markup  = '';
						$format_list_markup .= '<div class="entry-meta h5">';
						$numItems            = count( $cpt_terms );
						$i                   = 0;

						foreach ( $cpt_terms as $term ) {
							if ( ++$i === $numItems ) {
								$term_link = get_term_link( $term );
								$term_slug = $term->slug;
								if ( ! empty( $term_link ) ) {

									$nlsn_taxonomy_translation_format = nlsn_taxonomy_translation( 'formats', 'format', $term );

									// add the individual format
									$list_items_markup .= sprintf(
										'<h5 class="formats taxonomy-term knockout d-flex align-items-center text-center" style="margin: 15px auto 10px;"><span class="format %3$s"></span><a class="format-link text-white" href="%1$s">%2$s</a></h5>',
										esc_url( $term_link ),
										esc_html( $nlsn_taxonomy_translation_format ),
										esc_html( $term_slug )
									);
								}
							} else {
								$term_link = get_term_link( $term );
								if ( ! empty( $term_link ) ) {

									$nlsn_taxonomy_translation_format = nlsn_taxonomy_translation( 'formats', 'format', $term );

									// add the individual formats
									$list_items_markup .= sprintf(
										'<h5 class="formats taxonomy-term knockout d-flex align-items-center text-center"><span class="format %3$s"></span><a class="format-link text-white" href="%1$s">%2$s</a> | </h5>',
										esc_url( $term_link ),
										esc_html( $nlsn_taxonomy_translation_format )
									);
								}
							}
						}
					}
				}
			}

			// CATEGORY
			if ( $attributes['displayCategory'] === true && $attributes['displayDate'] === true ) {
				$date_format = get_field( 'date_format', 'markets_' . $GLOBALS['nlsnvars']['current_market_taxonomy_id'] );
				$post_date   = get_the_date( $date_format, $post_id );

				$cpt_taxonomies = array( $post->post_type . '_categories' );

				foreach ( $cpt_taxonomies as $cpt_taxonomy ) {

					$cpt_terms = wp_get_post_terms( $post_id, $cpt_taxonomy );

					if ( ! is_wp_error( $cpt_terms ) ) {

						// add the beginning part of the category/date section
						$category_list_markup  = '';
						$category_list_markup .= '<div class="entry-meta h5">';

						foreach ( $cpt_terms as $term ) {

							$term_link = get_term_link( $term );
							if ( ! empty( $term_link ) ) {

								$nlsn_taxonomy_translation_category = nlsn_taxonomy_translation( $post->post_type . '_categories', 'category', $term );

								// add the individual categories
								$category_list_markup .= sprintf(
									'<span class="taxonomy-term knockout"><a style="color: #00aeef" href="%1$s">%2$s</a> | </span>',
									esc_url( $term_link ),
									esc_html( $nlsn_taxonomy_translation_category )
								);
							}
						}

						// add the date & the closing div for the whole category/date section
						$category_list_markup .= sprintf(
							'<time class="updated knockout h5" datetime="%1$s">%1$s</time></div>',
							esc_html( $post_date )
						);

						$list_items_markup .= sprintf(
							'%1$s',
							$category_list_markup
						);
					}
				}
			} elseif ( $attributes['displayCategory'] === true ) {
				$cpt_taxonomies = array( $post->post_type . '_categories' );

				foreach ( $cpt_taxonomies as $cpt_taxonomy ) {
					$cpt_terms = wp_get_post_terms( $post_id, $cpt_taxonomy );

					if ( ! is_wp_error( $cpt_terms ) ) {

						// add the beginning part of the category/date section
						$category_list_markup  = '';
						$category_list_markup .= '<div class="entry-meta h5">';

						$numItems = count( $cpt_terms );
						$i        = 0;

						foreach ( $cpt_terms as $term ) {
							if ( ++$i === $numItems ) {
								$term_link = get_term_link( $term );
								if ( ! empty( $term_link ) ) {

									$nlsn_taxonomy_translation_category = nlsn_taxonomy_translation( $post->post_type . '_categories', 'category', $term );

									// add the individual categories
									$category_list_markup .= sprintf(
										'<span class="taxonomy-term knockout"><a style="color: #00aeef" href="%1$s">%2$s</a></span>',
										esc_url( $term_link ),
										esc_html( $nlsn_taxonomy_translation_category )
									);
								}
							} else {
								$term_link = get_term_link( $term );
								if ( ! empty( $term_link ) ) {

									$nlsn_taxonomy_translation_category = nlsn_taxonomy_translation( $post->post_type . '_categories', 'category', $term );

									// add the individual categories
									$category_list_markup .= sprintf(
										'<span class="taxonomy-term knockout"><a style="color: #00aeef" href="%1$s">%2$s</a> | </span>',
										esc_url( $term_link ),
										esc_html( $nlsn_taxonomy_translation_category )
									);
								}
							}
						}
						// add the closing div for the whole category/date section
						$list_items_markup .= sprintf(
							'%1$s</div>',
							$category_list_markup
						);
					}
				}
			} elseif ( $attributes['displayDate'] === true ) {
					$date_format = get_field( 'date_format', 'markets_' . $GLOBALS['nlsnvars']['current_market_taxonomy_id'] );
					$post_date   = get_the_date( $date_format, $post_id );

					$list_items_markup .= sprintf(
						'<div class="entry-meta h5"><time class="updated knockout h5" datetime="%1$s">%1$s</time></div>',
						esc_html( $post_date )
					);
			}


			// TITLE
			$final_title = empty( $post_meta['meta_title'][0] ) ? $post->post_title : $post_meta['meta_title'][0];

			if ( $attributes['displayTitleAsBrandedFont'] === true ) {
				$list_items_markup .= sprintf(
					'<h2 class="entry-title h1"><a href="%1$s" target="_blank">%2$s</a></h2>',
					esc_url( get_permalink( $post_id ) ),
					esc_html( $final_title )
				);
			} else {
				$list_items_markup .= sprintf(
					'<a href="%1$s">%2$s</a>',
					esc_url( get_permalink( $post_id ) ),
					esc_html( $final_title )
				);
			}

			if ( $attributes['displayItemDescription'] === true ) {
				if ( ! empty( $post_meta['meta_description'][0] ) ) {
					$final_description = nlsn_custom_excerpt_length( $post_meta['meta_description'][0] );
				} else {
					$post_excerpt = get_the_excerpt( $post->ID );
					$final_description = $post_excerpt === 'Excerpt' ? nlsn_custom_excerpt_length( $post->post_content ) : nlsn_custom_excerpt_length( $post_excerpt );
				}
				if ( $final_description ) {
					$list_items_markup .= sprintf(
						'<p>%1$s</p>',
						esc_html( $final_description )
					);
				}
			}

			// end of li tag
			$list_items_markup .= "</li>\n";
		}

		// HTML Classes Rendering
		$class = 'wp-block-nlsn-blocks-nlsn-smartlist ';
		if ( isset( $attributes['align'] ) ) {
			$class .= ' align' . $attributes['align'];
		}

		// if NOT grid
		if ( isset( $attributes['postLayout'] ) && 'grid' !== $attributes['postLayout'] ) {
			$class .= ' link-list nav';
		}

		// if grid
		if ( isset( $attributes['postLayout'] ) && 'grid' === $attributes['postLayout'] ) {
			$class .= ' is-grid';
		}

		if ( isset( $attributes['columns'] ) && 'grid' === $attributes['postLayout'] ) {
			$class .= ' columns-' . $attributes['columns'];
		}

		// add block name
		if ( isset( $attributes['className'] ) ) {
			$class .= ' ' . $attributes['className'];
		}

		// if FeaturedPosts enabled and NOT grid
		if ( isset( $attributes['postLayout'] ) && 'grid' !== $attributes['postLayout'] && $attributes['enableFeaturedPosts'] === 'show-featured' ) {
			$class .= ' link-list nav featured-insights bg-lighter-gray px-3 py-4';
		}

		// compile everything
		$block_content = sprintf(
			'<div class="module"><ul class="%1$s">%2$s</ul></div>',
			esc_attr( $class ),
			$list_items_markup
		);


		// HTML Button Rendering, using non relative URL
		$homeUrl = get_home_url();
        $url = $homeUrl . $attributes['learnMoreUrl'];
		// use post market in Learn More URL
		if ( isset( $attributes['displaySmByPostMarketLanguage'] ) && $attributes['displaySmByPostMarketLanguage'] === true ) {
			$primary_market = $attributes['marketPrimary'] . '&language';
			$temp = explode( '=' ,$url );
			$temp[2] = $primary_market; // replace the url market with post market
			$url = implode( '=', $temp );
		}
		if ( $attributes['enableLearnMoreButton'] === true && $attributes['customLearnMoreUrl'] === '' ) {
			$button_markup .= sprintf(
				'<div><a class="content-button btn regular btn-blue" target="%3$s" href="%1$s">%2$s</a></div>',
				esc_url( $url ),
				esc_html( $attributes['learnMoreText'] ),
				esc_attr( $open_in_new )
			);
		} elseif ( $attributes['enableLearnMoreButton'] === true && $attributes['customLearnMoreUrl'] !== '' ) {
			$button_markup .= sprintf(
				'<div><a class="content-button btn regular btn-blue" href="%1$s" target="%3$s">%2$s</a></div>',
				esc_url( $attributes['customLearnMoreUrl'] ),
				esc_html( $attributes['learnMoreText'] ),
				esc_attr( $open_in_new )
			);
		}

		$block_content .= $button_markup;
		return $block_content;
	}
}

/**
 * Registers the `nlsn/smartlist` block on server.
 */
function register_block_nlsn_blocks_nlsn_smartlist() {
	register_block_type(
		'nlsn-blocks/nlsn-smartlist',
		array(
			'attributes'      => array(
				'marketLanguages' => array(
					'type' => 'array',
					'items' => array(
						'type' => 'string',
					),
				  ),
				'title'                     => array(
					'type' => 'string',
				),
				'categories'                => array(
					'type' => 'string',
				),
				'categoryType'              => array(
					'type' => 'string',
				),
				'tags'                      => array(
					'type' => 'string',
				),
				'formats'                   => array(
					'type' => 'string',
				),
				'postType'                  => array(
					'type' => 'string',
				),
				'postTypeOptions'           => array(
					'type'  => 'array',
					'items' => array(
						'type' => 'string',
					),
				),
				'postsToShow'               => array(
					'type'    => 'number',
					'default' => 6,
				),
				'featuredPosts'             => array(
					'type'    => 'array',
					'default' => 6,
					'items'   => array(
						'type' => 'string',
					),
				),
				'displayPostDate'           => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'postLayout'                => array(
					'type'    => 'string',
					'default' => 'list',
				),
				'order'                     => array(
					'type'    => 'string',
					'default' => 'desc',
				),
				'orderBy'                   => array(
					'type'    => 'string',
					'default' => 'date',
				),
				'markets'                   => array(
					'type'  => 'array',
					'items' => array(
						'type' => 'string',
					),
				),
				'marketsSelected'           => array(
					'type'  => 'array',
					'items' => array(
						'type' => 'number',
					),
				),
				'languages'                 => array(
					'type'  => 'array',
					'items' => array(
						'type' => 'string',
					),
				),
				'languagesSelected'         => array(
					'type'  => 'array',
					'items' => array(
						'type' => 'number',
					),
				),
				'listType'                  => array(
					'type' => 'string',
				),
				'className'                 => array(
					'type' => 'string',
				),
				'columns'                   => array(
					'type'    => 'number',
					'default' => 3,
				),
				'bootstrap_columns'         => array(
					'type'    => 'number',
					'default' => 4,
				),
				'align'                     => array(
					'type' => 'string',
				),
				'enableLearnMoreButton'     => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'enableFeaturedPosts'       => array(
					'type'    => 'string',
					'default' => 'include-featured',
				),
				'learnMoreText'             => array(
					'type'    => 'string',
					'default' => 'Learn More',
				),
				'learnMoreUrl'              => array(
					'type' => 'string',
				),
				'openInNewTab'              => array(
					'type'    => 'boolean',
					'default' => true,
				),
				'customLearnMoreUrl'        => array(
					'type' => 'string',
				),
				'customizeLearnMoreButton'  => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'displayItemDescription'    => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'displayItemThumbnail'      => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'displayDate'               => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'displayCategory'           => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'displayFormat'             => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'displayTitleAsBrandedFont' => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'enableReadMoreButton'      => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'customizeReadMoreButton'   => array(
					'type'    => 'boolean',
					'default' => false,
				),
				'readMoreText'              => array(
					'type'    => 'string',
					'default' => 'Read More >',
				),
				'isfeaturedEnable'          => array(
					'type'    => 'boolean',
					'default' => false,
				),
			),
			'render_callback' => 'render_block_nlsn_blocks_nlsn_smartlist',
		)
	);
}


function editor_assets() {
	// market taxonomy
	$markets_raw = get_terms([
		'taxonomy'   => 'markets',
		'hide_empty' => false,
	]);
	$markets     = array();

	if ( is_wp_error( $markets_raw ) ) {
	} else {
		foreach ( $markets_raw as $market ) {
			$markets[] = array(
				'id'   => $market->term_id,
				'name' => $market->rest_base ? $market->rest_base : $market->name,
				'slug' => $market->slug,
			);
		}
	}

	  // language taxonomy
	$languages_raw = get_terms([
        'taxonomy' => 'languages',
        'hide_empty' => false,
    ]);
    $languages = array();

    if ( is_wp_error($languages_raw) ){
    } else {
      foreach( $languages_raw as $language ) {
        $languages[] = array(
			'id' => $language->term_id,
			'name' => $language->rest_base ? $language->rest_base  : $language->name,
			'slug' => $language->slug,
        );
      }
    }

	// build the market and its assigned languages pair
	if ( isset( $markets ) && is_array( $markets ) ) {
		$market_languages_arr = array();
		foreach ( $markets as $market ) {
			$market_languages = get_term_meta( $market['id'], 'market_language', false );
			if ( isset( $market_languages ) && is_array( $market_languages ) ) {
				foreach ( $market_languages as $market_language ) {
					$languages_wp_term_objects = get_term( $market_language );

					if ( isset( $languages_wp_term_objects ) ) {
						  $custom_props = array();
						foreach ( $languages_wp_term_objects as $key => $language_wp_term_object ) {
							if ( $key === 'term_id' ) {
								$custom_props['id'] = $language_wp_term_object;
							}
							if ( $key === 'slug' ) {
								$custom_props[ $key ] = $language_wp_term_object;
							}
							if ( $key === 'name' ) {
								$custom_props[ $key ] = $language_wp_term_object;
							}
						}
						$market_languages_arr[ $market['id'] ][] = $custom_props;
					}
				}
			}
		}
	}

	// post types
	$types_raw = get_post_types( array( 'public' => true ), 'objects' );
	$types     = array();

	foreach ( $types_raw as $type ) {

		// Avoid WooCommerce Products CPT
		if ( $type->name === 'product' ) {
			continue;
		}

		$types[] = array(
			'label' => $type->label,
			'value' => $type->rest_base ? $type->rest_base : $type->name,
		);
	}

	 // Declare vars
	$wp_market_object               = get_the_terms( get_the_id(), 'markets' );
	$wp_language_object             = get_the_terms( get_the_id(), 'languages' );
	$current_post_market_arr        = array();
	$current_post_market_slug_arr   = array();
	$current_post_language_arr      = array();
	$current_post_language_slug_arr = array();

	// Check if value is valid to avoid PHP error
	if ( isset( $wp_market_object ) && is_array( $wp_market_object ) ) {
		foreach ( $wp_market_object as $market ) {
			array_push( $current_post_market_arr, $market->term_id );
			array_push( $current_post_market_slug_arr, $market->slug );
		}
	}

	if ( isset( $wp_language_object ) && is_array( $wp_language_object ) ) {
		foreach ( $wp_language_object as $language ) {
			array_push( $current_post_language_arr, $language->term_id );
			array_push( $current_post_language_slug_arr, $language->slug );
		}
	}

	// load values into scripts
	wp_localize_script(
		'nlsn-smart-list-js',
		'smartListEditorData',
		array(
			'postTypes'                  => wp_json_encode( $types ),
			'markets'                    => wp_json_encode( $markets ),
			'languages' 				 => wp_json_encode( $languages ),
			'marketLanguages'            => wp_json_encode( $market_languages_arr ),
			'currentPostMarketIdArr'     => $current_post_market_arr,
			'currentPostMarketSlugArr'   => $current_post_market_slug_arr,
			'currentPostLanguageIdArr'   => $current_post_language_arr,
			'currentPostLanguageSlugArr' => $current_post_language_slug_arr,
		)
	);

}


add_action( 'init', 'register_block_nlsn_blocks_nlsn_smartlist' );

add_action( 'enqueue_block_editor_assets', 'editor_assets' );

/**
 * Utility Functions
 */

/**
 * Get the translated value of the taxonomy term from the language taxonomy.
 *
 * @param string   $acf_taxonomy_repeater_name   The name of the ACF repeater that references the taxonomy
 * @param string   $taxonomy_var_name            The name of the ACF field that references the single taxonomy term
 * @param variable $term_var_name                The variable name that references the single taxonomy term.
 *
 * @return string  $term_translation             Print the translated text that the user has entered in the ACF textfield
 *                                               that corresponds to the single taxonomy term.
 *
 * <sample>
 *
 * $cpt_terms = wp_get_post_terms( $post->ID, 'taxonomy_name' );
 *
 *   if ( ! is_wp_error( $cpt_terms ) ) :
 *
 *     foreach ( $cpt_terms as $term ) :
 *
 *       nlsn_taxonomy_translation( 'taxonomy__acf_repeater', 'taxonomy_acf_name', $term );
 *
 *     endforeach
 *
 *   endif;
 *
 * </sample>
 */
function nlsn_taxonomy_translation( $acf_taxonomy_repeater_name, $taxonomy_var_name, $term_var_name ) {

	/*
	* Get the ID value for the language that should be used for translations, either the 'original' or 'override' language.
	*/
	$new_language_taxonomy_id = nlsn_get_language_override_id();

	/*
	* Create array to assign the translation, if one is available.
	*/
	$translation_array = array();

	// Check the ACF taxonomy repeater for the current language to get the term objects
	if ( have_rows( $acf_taxonomy_repeater_name, 'languages_' . $new_language_taxonomy_id ) ) :
		while ( have_rows( $acf_taxonomy_repeater_name, 'languages_' . $new_language_taxonomy_id ) ) :
			the_row();

			// get the Format terms
			$term_object = get_sub_field( $taxonomy_var_name );

			// if the id of the current term matches the id of one of the term objects in the repeater
			if ( $term_var_name->term_id === $term_object->term_id ) :
				// if a translation exists, push to the translation array the corresponding translation
				if ( get_sub_field( 'translation' ) ) :
					array_push( $translation_array, get_sub_field( 'translation' ) );
				endif;
		  endif;

	  endwhile;
  endif;

	/*
	* If the translation array is not empty, use the first translation in the array.
	* Otherwise, use the term name (the Original English name).
	*/
	$term_translation = $translation_array ? $translation_array[0] : $term_var_name->name;

	return $term_translation;
}


/**
 * Get the ID value for the language that should be used for translations.
 *
 * Check the current Market taxonomy for language-override relationships that may have been created.
 * If one exists for the current language, return the ID value of the override language,
 * else, return the ID value of the current language.
 *
 * @return array|mixed
 *
 * <sample>
 *
 * $new_language_taxonomy_id = nlsn_get_language_override_id;
 *
 * </sample>
 */

function nlsn_get_language_override_id() {

	/*
	* Create array to hold the 'ID' value of the override language that should be used for translations,
	* if one has been added on the market taxonomy.
	*/
	$new_language_taxonomy_id = array();

	// get the current market and language taxonomy IDs
	$current_market_taxonomy_id   = $GLOBALS['nlsnvars']['current_market_taxonomy_id'];
	$current_language_taxonomy_id = $GLOBALS['nlsnvars']['current_language_taxonomy_id'];

	// Check the ACF market taxonomy repeater for language-override relationships created for the current market
	if ( have_rows( 'language_overrides', 'markets_' . $current_market_taxonomy_id ) ) :
		while ( have_rows( 'language_overrides', 'markets_' . $current_market_taxonomy_id ) ) :
			the_row();

			// get the 'original language'
			$term_object = get_sub_field( 'original_language' );

			// if the id of the current language term matches the ID of one of the 'original language' term objects in the repeater
			if ( $current_language_taxonomy_id === $term_object->term_id ) :
				// if a match exists, push to the override array the ID of the corresponding 'override language'
				if ( get_sub_field( 'override_language' ) ) :
					array_push( $new_language_taxonomy_id, get_sub_field( 'override_language' )->term_id );
				endif;
		  endif;

	  endwhile;
  endif;

	/*
	* If there were any matches and the array has a value, use that 'Language ID' for translations,
	* otherwise use the 'Language ID' of the current language.
	*/
	$new_language_taxonomy_id = $new_language_taxonomy_id ? $new_language_taxonomy_id[0] : $GLOBALS['nlsnvars']['current_language_taxonomy_id'];

	return $new_language_taxonomy_id;
}
