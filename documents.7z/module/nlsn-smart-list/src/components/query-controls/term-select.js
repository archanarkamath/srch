/**
 * Internal dependencies
 */
import { buildTermsTree } from './terms';
import TreeSelect from './tree-select';

export default function TermSelect( { label, noOptionLabel, termsList, selectedTermId, onChange } ) {
  const termsTree = buildTermsTree( termsList );
  return (
    <TreeSelect
      { ...{ label, noOptionLabel, onChange } }
      tree={ termsTree }
      selectedId={ selectedTermId }
    />
  );
}