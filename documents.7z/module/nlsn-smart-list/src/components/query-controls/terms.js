/**
 * External dependencies
 */
import groupBy from 'lodash/groupBy';
// import { groupBy } from 'lodash';

/**
 * Returns terms in a tree form.
 *
 * @param {Array} flatTerms  Array of terms in flat format.
 *
 * @return {Array} Array of terms in tree format.
 */
export function buildTermsTree( flatTerms ) {
  const termsByParent = groupBy( flatTerms, 'parent' );
  const fillWithChildren = ( terms ) => {
    return terms.map( ( term ) => {
      const children = termsByParent[ term.id ];
      return {
        ...term,
        children: children && children.length ?
          fillWithChildren( children ) :
          [],
      };
    } );
  };

  return fillWithChildren( termsByParent[ '0' ] || [] );
}