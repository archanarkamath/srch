/**
 * WordPress dependencies
 */
const { __ } = wp.i18n;

const {
  RangeControl,
  SelectControl,
} = wp.components;

/**
 * Internal dependencies
 */
import TermSelect from './term-select';

const DEFAULT_MIN_ITEMS = 1;
const DEFAULT_MAX_ITEMS = 100;

export default function CustomQueryControls( {
  termsList,
  selectedTermId,
  onTermChange,

  order,
  orderBy,
  onOrderChange,
  onOrderByChange,

  maxItems = DEFAULT_MAX_ITEMS,
  minItems = DEFAULT_MIN_ITEMS,
  numberOfItems,
  onNumberOfItemsChange,

  label,
} ) {
  return [
    ( onOrderChange && onOrderByChange ) && (
      <SelectControl
        key="query-controls-order-select"
        label={ __( 'Order by' ) }
        value={ `${ orderBy }/${ order }` }
        options={ [
          {
            label: __( 'Publish Date' ),
            value: 'date/desc',
          },
          {
            label: __( 'Updated Date' ),
            value: 'modified/desc',
          },
          // {
          //   /* translators: label for ordering posts by title in ascending order */
          //   label: __( 'A → Z' ),
          //   value: 'title/asc',
          // },
          // {
          //   /* translators: label for ordering posts by title in descending order */
          //   label: __( 'Z → A' ),
          //   value: 'title/desc',
          // },
        ] }
        onChange={ ( value ) => {
          const [ newOrderBy, newOrder ] = value.split( '/' );
          if ( newOrder !== order ) {
            onOrderChange( newOrder );
          }
          if ( newOrderBy !== orderBy ) {
            onOrderByChange( newOrderBy );
          }
        } }
      />
    ),
    onNumberOfItemsChange && (
      <RangeControl
        key="query-controls-range-control"
        label={ __( 'Number of items' ) }
        value={ numberOfItems }
        onChange={ onNumberOfItemsChange }
        min={ minItems }
        max={ maxItems }
      />
    ),
    onTermChange && (
      <TermSelect
        key="query-controls-category-select"
        termsList={ termsList }
        // label={ __( 'Category' ) }
        label={ label }
        noOptionLabel={ __( 'All' ) }
        selectedTermId={ selectedTermId }
        onChange={ onTermChange }
      /> ),
  ];
}