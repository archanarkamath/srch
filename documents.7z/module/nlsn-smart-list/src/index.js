/**
 * WordPress dependencies
 */
import { __}                 from '@wordpress/i18n';
import { registerBlockType } from '@wordpress/blocks';

/**
 * Internal dependencies
 */
import edit from './edit';

import './editor.scss';

// Register: Container Block.
registerBlockType( 'nlsn-blocks/nlsn-smartlist', {
  title: __( 'Smartlist - NLSN' ),
  description: __( 'Create custom post lists.', 'nlsn-blocks' ),
  // <svg role="img" aria-hidden="true" focusable="false" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M0,0h24v24H0V0z" fill="none" /><path d="M12,2l-5.5,9h11L12,2z M12,5.84L13.93,9h-3.87L12,5.84z" /><path d="m17.5 13c-2.49 0-4.5 2.01-4.5 4.5s2.01 4.5 4.5 4.5 4.5-2.01 4.5-4.5-2.01-4.5-4.5-4.5zm0 7c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" /><path d="m3 21.5h8v-8h-8v8zm2-6h4v4h-4v-4z" /></svg>,
  category: 'nielsen-blocks',
  keywords: [
    __( 'smartlist', 'nlsn-blocks' ),
    __( 'nielsen', 'nlsn-blocks' ),
  ],

  supports: {
    html: false,
  },
  attributes: {

    marketLanguages: {
      type: 'array',
    },
    title: {
      type: 'string',
    },
    categories: {
      type: 'string',
    },
    categoryType: {
      type: 'string',
    },

    tags: {
      type: 'string',
    },

    formats: {
      type: 'string',
    },

    year: {
      type: 'string',
    },

    postType: {
      type: 'string',
      default: 'choose-section'
    },
    postTypeOptions: {
      type: 'array',
    },
    postsToShow: {
      type: 'number',
      default: 6
    },
    displayPostDate: {
      type: 'boolean',
      default: false,
    },
    postLayout: {
      type: 'string',
      default: 'list'
    },

    order: {
      type: 'string',
      default:'desc'
    },
    orderBy: {
      type: 'string',
      default: 'date'
    },

    markets: {
      type: 'array',
    },
    marketsSelected: {
      type: 'array',
      default: []
    },
    languages: {
      type: 'array',
    },
    languagesSelected: {
      type: 'array',
      default: [],
    },

    listType: {
      type: 'string',
      default: 'choose-list-type',
    },
    className: {
      type: 'string',
    },
    columns: {
      type: 'number',
      default: 3,
    },
    bootstrap_columns: {
      type: 'number',
      default: 4,
    },
    align: {
      type: 'string',
    },
    enableLearnMoreButton: {
      type: 'boolean',
      default: false,
    },
    learnMoreText: {
      type: 'string',
      default: 'Learn More',
    },
    learnMoreUrl: {
      type: 'string',
    },
    finalLearnMoreUrl: {
      type: 'string',
    },
    customLearnMoreUrl: {
      type: 'string',
    },
    customizeLearnMoreButton: {
     type: 'boolean',
     default: false,
   },

    displayItemDescription: {
     type: 'boolean',
     default: false,
   },
    displayItemThumbnail: {
     type: 'boolean',
     default: false,
   },
    displayDate: {
     type: 'boolean',
     default: false,
   },
    displayCategory: {
     type: 'boolean',
     default: false,
   },
   displayFormat: {
    type: 'boolean',
    default: false,
  },
    displayTitleAsBrandedFont: {
     type: 'boolean',
     default: false,
   },
   openInNewTab: {
     type: 'boolean',
     default: true,
   },
   enableReadMoreButton: {
     type: 'boolean',
     default: false,
   },
   enableFeaturedPosts: {
     type: 'string',
     default: 'include-featured',
   },
   customizeReadMoreButton: {
     type: 'boolean',
     default: false,
   },
   readMoreText: {
     type: 'string',
     default: 'Read More >',
   },
   businessTerm: {
     type: 'string',
   },
   displaySmByPostMarketLanguage:{
     type: 'boolean',
     default: false,
   },
   currentPostMarketIdArr:{
     type: 'array',
   },
   currentPostLanguageIdArr:{
     type: 'array',
  },
  currentPostMarketSlugArr:{
    type: 'array',
  },
  currentPostLanguageSlugArr:{
    type: 'array',
 },
  marketsSelectedSlug:{
    type: 'array',
  },
  languagesSelectedSlug:{
    type: 'array',
 }

  },

  getEditWrapperProps( attributes ) {
    const { align } = attributes;
    if ( 'left' === align || 'right' === align || 'wide' === align || 'full' === align ) {
      return { 'data-align': align };
    }
  },

  edit,

  save() {
    return null;
  },
});
