/**
 * External dependencies
 */
import isUndefined from 'lodash/isUndefined';
import pickBy from 'lodash/pickBy';
import differenceBy from 'lodash/differenceBy';
// import { isUndefined, pickBy } from 'lodash';
import classnames from 'classnames';
import CustomQueryControls from './components/query-controls';
import _ from 'lodash';

/**
 * WordPress dependencies
 */
import { Component, Fragment } from '@wordpress/element';
import { __ }                  from '@wordpress/i18n';
import { withSelect }          from '@wordpress/data';
import { InspectorControls, BlockControls } from '@wordpress/blockEditor';
import { blockTable, postList, grid } from '@wordpress/icons';

import {
  PanelBody,
  PanelRow,
  Placeholder,
  QueryControls,
  RangeControl,
  TextControl,
  Spinner,
  ToggleControl,
  Toolbar,
  SelectControl,
  CheckboxControl,
  Button
} from '@wordpress/components';;

const MAX_POSTS_COLUMNS = 6;

class SmartListEdit extends Component {
  constructor() {
    super( ...arguments );
    this.toggleDisplayPostDate = this.toggleDisplayPostDate.bind(this );
    const {marketLanguages, currentPostMarketIdArr, currentPostLanguageIdArr, currentPostMarketSlugArr, currentPostLanguageSlugArr} = window.smartListEditorData;
    this.props.attributes.marketLanguages = marketLanguages;
    this.props.attributes.currentPostMarketIdArr = currentPostMarketIdArr;
    this.props.attributes.currentPostLanguageIdArr = currentPostLanguageIdArr;
    this.props.attributes.currentPostLanguageSlugArr = currentPostLanguageSlugArr;
    this.props.attributes.currentPostMarketSlugArr = currentPostMarketSlugArr;

  }

  toggleDisplayPostDate() {
    const { displayPostDate } = this.props.attributes;
    const { setAttributes } = this.props;
    setAttributes( { displayPostDate: ! displayPostDate } );
  }

  // reusable method to remove duplicate records from languages for the smartlist
 getUniqueInObjArr(arr, comp) {
     try {
       if( Array.isArray(arr) && typeof(arr) !== 'undefined' ){
         const unique = arr
             .map(e => e[comp])
              // store the keys of the unique objects
             .map((e, i, final) => final.indexOf(e) === i && i)
             // eliminate the dead keys & store unique objects
             .filter(e => arr[e]).map(e => arr[e]);

          return unique;
        }
     } catch ( error ) {
        console.log("Error: " + error.description );
     }
 };

 //reusable method to get index in an object array
 getIndexInObjArr(arr, attr, value) {
     try {
       if( Array.isArray(arr) && typeof(arr) !== 'undefined' ){
         for (var i = 0; i < arr.length; i += 1) {
             if (arr[i][attr] === value) {
               return i;
             }
         }
         return -1;
       }
     }catch ( error ) {
        console.log("Error: " + error.description );
     }
 };

 //reusable method to sort an object array by the props
 getCompare(a, b) {
    try {

      let nameA;
      let nameB;

      if( a !== undefined ){
        nameA = a.name.toUpperCase();
      }
      if( b !== undefined ){
        nameB = b.name.toUpperCase();
      }

      let comparison = 0;
      if (nameA > nameB) {
        comparison = 1;
      } else if (nameA < nameB) {
        comparison = -1;
      }
      return comparison;
   }catch ( error ) {
     console.log("Error: " + error.description );
   }
  };


  //method triggers on click of market checkbox
  marketToggleCheckbox(index) {
    const { setAttributes } = this.props;
    const { markets, marketsSelected ,marketLanguages, languages, languagesSelected} = this.props.attributes;

    markets[index].checked = !markets[index].checked;

    setAttributes( {
      markets: markets,
    });

    let marketsSelectedArray = [];
    let marketsSelectedSlugArray = [];
    markets.map( market => {
      if(market.checked === true){
        marketsSelectedArray.push(market.id),
        marketsSelectedSlugArray.push(market.slug)  //Pass the market slug to below functions

      }
    });
    setAttributes( {
      marketsSelected: marketsSelectedArray,
      marketsSelectedSlug:marketsSelectedSlugArray
    });

    //assign languages based on markets chosen in the checkbox
    let langArr = [];

    if( Array.isArray(marketsSelectedArray) && marketsSelectedArray !== 'undefined' && marketsSelectedArray.length !== 0){
      var obj = JSON.parse(marketLanguages);

      for( var i=0 ; i < marketsSelectedArray.length ;i++ ){
        var subarr = obj[ marketsSelectedArray[i] ];

        if( Array.isArray(subarr) && typeof(subarr) !== 'undefined' ){
          for ( var j=0 ; j < subarr.length ; j++ ){
            langArr.push((subarr[j]));
          };
        };
      };

      langArr = this.getUniqueInObjArr(langArr, 'id');
      langArr = langArr.sort(this.getCompare);
    };

    setAttributes({
      languages: langArr,
    });

    if( Array.isArray(marketsSelectedArray) && marketsSelectedArray !== 'undefined' && marketsSelectedArray.length !== 0 ){
      //on edit,make the language checkbox selected if it is saved in the post
      if( Array.isArray( languages ) && typeof( languages ) !== 'undefined' ){
        languages.map(lang => {
          if(lang.checked){
            var index = this.getIndexInObjArr(langArr, 'id', lang.id);
             if(index !== -1)langArr[index].checked = true;
          }
        });
      }
    }else{
      //languagesSelected must be empty if no markets chosen
      setAttributes({
        languagesSelected: [],
      });
    }
 };

  //method triggers on click of language checkbox
  languageToggleCheckbox(index) {
      const { setAttributes } = this.props;
      const { languages, languagesSelected } = this.props.attributes;

      languages[index].checked = !languages[index].checked;

      setAttributes( {
        languages: languages
      });

      let languagesSelectedArray = [];
      let languagesSelectedSlugArray = [];
      languages.map( language => {
        if(language.checked === true){
          languagesSelectedArray.push(language.id),
          languagesSelectedSlugArray.push(language.slug)
        }
      })

      setAttributes( {
        languagesSelected: languagesSelectedArray,
        languagesSelectedSlug:languagesSelectedSlugArray
      });

  }

  // componentWillMount() {
  // }

  convertColumnsToBootstrapColumns(columns){

    const {
      setAttributes,
    } = this.props;

    const {
      bootstrap_columns
    } = this.props.attributes;

    switch(columns) {
      case 6:
        setAttributes( {
          bootstrap_columns: 2,
        } );
        break;
      case 5:
        setAttributes( {
          bootstrap_columns: 2,
        } );
        break;
      case 4:
        setAttributes( {
          bootstrap_columns: 3,
        } );
        break;
      case 3:
        setAttributes( {
          bootstrap_columns: 4,
        } );
        break;
      case 2:
        setAttributes( {
          bootstrap_columns: 6,
        } );
        break;
      case 1:
        setAttributes( {
          bootstrap_columns: 12,
        } );
        break;
      default:
        setAttributes( {
          bootstrap_columns: 4,
        } );
    }
  }


//click handler triggers on click of radio button
  smartlistByPostMarketLanguage(value){
    const { setAttributes } = this.props;
    const { displaySmByPostMarketLanguage, currentPostMarketIdArr, currentPostMarketSlugArr, currentPostLanguageSlugArr, currentPostLanguageIdArr, marketsSelected, languagesSelected, markets, languages } = this.props.attributes;

    let marketsSelectedArray = [];
    let marketsSelectedSlugArray = [];
      markets.map( market => {
        if(market.checked === true){
          marketsSelectedArray.push(market.id),
          marketsSelectedSlugArray.push(market.slug)
        }
    });

    let languagesSelectedArray = [];
    let languagesSelectedSlugArray = [];
    if( Array.isArray( languages ) && typeof( languages ) !== 'undefined' ){
      languages.map( language => {
        if(language.checked === true){
          languagesSelectedArray.push(language.id),
          languagesSelectedSlugArray.push(language.slug)
        }
    });
  }

    if( typeof(value) === 'boolean' && value === true ){
        setAttributes({
          marketsSelected: currentPostMarketIdArr,
          marketsSelectedSlug:currentPostMarketSlugArr,
          languagesSelected: currentPostLanguageIdArr,
          languagesSelectedSlug:currentPostLanguageSlugArr
        });
    }else{
      setAttributes({
        marketsSelected: marketsSelectedArray,
        marketsSelectedSlug:marketsSelectedSlugArray,
        languagesSelected: languagesSelectedArray,
        languagesSelectedSlug:languagesSelectedSlugArray
      });
    }
  }

  onResetList(){
    // reset variables
    const { setAttributes } = this.props;

    // set initial variables
    setAttributes({
      markets: JSON.parse(smartListEditorData.markets),
      languages: JSON.parse(smartListEditorData.languages),
      marketsSelected: [],
      marketsSelectedSlug: [],
      languagesSelected: [],
      languagesSelectedSlug: [],
      categories: '',
      tags: '',
      formats: '',
      businessTerm:'',
      excludedMarkets:'',
      enableLearnMoreButton: false,
      customizeLearnMoreButton: false,
      customLearnMoreUrl: '',
      learnMoreUrl: '',
      featuredPosts: [],
      nonfeaturedPosts: [],
      enableReadMoreButton: false,
      customizeReadMoreButton: false,
      readMoreText: 'Read More >',
      postLayout: 'list',
      displayItemDescription: false,
      displayDate: false,
      displayCategory: false,
      displayFormat: false,
      displayTitleAsBrandedFont: false,
      displaySmByPostMarketLanguage: false,
      currentPostMarketIdArr: smartListEditorData.currentPostMarketIdArr,
      currentPostLanguageIdArr:smartListEditorData.currentPostLanguageIdArr,
      currentPostMarketSlugArr: smartListEditorData.currentPostMarketSlugArr,
      currentPostLanguageSlugArr: smartListEditorData.currentPostLanguageSlugArr,
      enableFeaturedPosts: 'include-featured',
  });

  }

  render() {
    const {
      attributes,
      setAttributes,
      categoriesList,
      relatedTagsList,
      formatsList,
      businessList,
      smartListPosts,
      featuredPosts,
      nonfeaturedPosts,
      smartListPostsEx,
    } = this.props;
    const {
      title,
      displayPostDate,
      align,
      postLayout,
      columns,
      bootstrap_columns,
      order,
      orderBy,
      postsToShow,
      postType,
      postTypeOptions,
      listType,
      enableFeaturedPosts,
      categoryType,
      categories,
      tags,
      formats,
      businessTerm,
      markets,
      marketsSelected,
      marketsSelectedSlug,
      excludedMarkets,
      languages,
      languagesSelected,
      languagesSelectedSlug,
      enableLearnMoreButton,
      learnMoreText,
      learnMoreUrl,
      customLearnMoreUrl,
      customizeLearnMoreButton,
      displayItemDescription,
      displayItemThumbnail,
      displayDate,
      displayCategory,
      displayFormat,
      displayTitleAsBrandedFont,
      enableReadMoreButton,
      customizeReadMoreButton,
      readMoreText,
      categoriesName,
      displaySmByPostMarketLanguage,
      currentPostMarketIdArr,
      currentPostMarketSlugArr,
      currentPostLanguageIdArr,
      currentPostLanguageSlugArr,
      openInNewTab,

    } = attributes;

    const simplifyDate = (date) =>{
      let tempDate = new Date(date)
      let month = tempDate.getMonth() + 1
      let year = tempDate.getFullYear()
      let day = tempDate.getDate()
      if (month < 10) {
        month = "0" + month
      }
      if (day < 10) {
        day = "0" + day
      }
      return month + "-" + day + "-" + year;
    }

    // Use this.props to access the attributes and re assign with current market id and language id, setAttributes is not working, using full name
    // Reassign the market and language slug, syncing after posts localization
    let currentPrimayMarket = [];
    currentPrimayMarket.push(currentPostMarketSlugArr[0]);

    if( typeof(displaySmByPostMarketLanguage) === 'boolean' && displaySmByPostMarketLanguage === true ){
      this.props.attributes.marketsSelected = currentPostMarketIdArr;
      this.props.attributes.marketsSelectedSlug = currentPrimayMarket; // Only show the primary post market in the button url
      this.props.attributes.languagesSelected = currentPostLanguageIdArr;
      this.props.attributes.languagesSelectedSlug = currentPostLanguageSlugArr;
    };

// Construct Learn More URL

    const hasCategoriesList = Array.isArray( categoriesList ) && typeof( formatsList ) !== 'undefined',
          hasFormatsList = Array.isArray( formatsList ) && typeof( formatsList ) !== 'undefined',
          hasTagsList = Array.isArray( relatedTagsList ) && typeof( formatsList ) !== 'undefined',
          hasMarketsSelected = Array.isArray( marketsSelectedSlug ) && ( marketsSelectedSlug.length ),
          hasLanguagesSelected = Array.isArray( languagesSelectedSlug ) && ( languagesSelectedSlug.length );

    let categorySlug,
        formatSlug,
        tagSlug,
        languageSelected,
        marketSelected;

      hasCategoriesList ?
      categorySlug = categoriesList.filter(category =>
        category.id === parseInt(categories)
      ).map(category =>
        category.slug
      ) : ""

      hasFormatsList ?
      formatSlug = formatsList.filter(format =>
        format.id === parseInt(formats)
      ).map(format =>
        format.slug
      ) : ""

      hasTagsList ?
      tagSlug = relatedTagsList.filter(tag =>
        tag.id === parseInt(tags)
      ).map(tag =>
        tag.slug
      ) : ""

      // Use empty string instead of null, php url doesn't return undefined
      hasLanguagesSelected && hasMarketsSelected ? languageSelected = languagesSelectedSlug : languageSelected = ""

      hasMarketsSelected ? marketSelected = marketsSelectedSlug : marketSelected = ""

    const tempLearnMoreUrl = '/?s=&market=' + marketSelected + '&language=' + languageSelected + '&post_type[]=' + postType + '&' + postType + '_related_tags=' + tagSlug +'&formats=' + formatSlug + '&' + postType + '_categories=' + categorySlug;

    // Assign the url attribute
     this.props.attributes.learnMoreUrl = tempLearnMoreUrl;

    const inspectorControls = (
      <InspectorControls>
        <PanelBody title={ __( 'SmartList Settings' ) }>

          <SelectControl
            label={ __( 'Content Section' ) }
            value={ postType }
            options={ [
              {label: 'Choose A Content Section', value:'choose-section'},
              {label: 'About Us', value:'about_us'},
              {label: 'Solutions', value:'solution'},
              {label: 'Insights', value:'insight'},
              {label: 'Press Releases', value:'press_release'},
              {label: 'Events', value:'event'},
              {label: 'News Center', value:'news_center'},
              {label: 'Top Ten', value:'top_ten'},
              {label: 'Panel', value:'panel'},
              {label: 'Legal', value:'legal'},
              {label: 'Pages', value:'page'},
              {label: 'Client Learning', value:'client_learning'},
            ] }
            onChange={ ( value ) => {
              setAttributes( { postType: value } );
              setAttributes( { categoryType: value + "_categories" } );
              this.onResetList()
            } }
          />

          { postType === 'choose-section' ? (
                <p><i>If no content section is selected, the search is implemented across all content sections.</i></p>
              ) : (
                <Fragment>
                  <TextControl
                    label={ __( 'Title' ) }
                    value={ title }
                    placeholder={ __( "Type a title" ) }
                    onChange={ ( value ) => setAttributes( { title: value } ) }
                  />
                  <SelectControl
                    label={ __( 'List Based On' ) }
                    value={ listType }
                    options={[
                      {label: 'Choose List Type', value:'choose-list-type'},
                      {label: 'List of Posts', value:'list-of-posts'},
                      {label: 'List of Categories', value:'list-of-categories'},
                      // {label: 'Format', value:'format'},
                    ]}
                    onChange={ ( value ) => {
                      setAttributes( { listType: value } );
                      this.onResetList()
                    } }
                  />

                  {/* list type conditionals */}
                  {(() => {
                   if (listType === 'choose-list-type')
                      return <p></p>
                   if (listType === 'list-of-categories' )
                      return <p></p>
                   if (listType === 'list-of-posts' )
                      return [
                        <CustomQueryControls
                          label='Category'
                          termsList={ categoriesList }
                          selectedTermId={ categories }
                          onTermChange={ ( value ) => setAttributes(
                            {
                              categories: '' !== value ? value : undefined,

                            }
                          ) }

                        />,
                        <CustomQueryControls
                          label='Related Tags'
                          termsList={ relatedTagsList }
                          selectedTermId={ tags }
                          onTermChange={ ( value ) => setAttributes(
                            {
                              tags: '' !== value ? value : undefined
                            }
                           ) }
                        />,
                        <CustomQueryControls
                          label='Formats'
                          termsList={ formatsList }
                          selectedTermId={ formats }
                          onTermChange={ ( value ) => setAttributes(
                            {
                              formats: '' !== value ? value : undefined,
                            }
                          ) }
                        />,
                        <SelectControl
                          label='Article Types'
                          value={ enableFeaturedPosts }
                          options={[

                            {label: 'All', value: 'include-featured'},
                            {label: 'Non Featured', value: 'non-featured'},
                            {label: 'Featured', value: 'show-featured' },

                          ]}
                          onChange={ ( value ) => {
                            setAttributes( { enableFeaturedPosts: value } );
                            // this.onResetList()
                          } }

                        />,
                      <CustomQueryControls
                          label='Business'
                          termsList={ businessList }
                          selectedTermId={ businessTerm }
                          onTermChange={ ( value ) => setAttributes(
                            { businessTerm : '' !== value ? value : undefined } ) }
                        />,
                        <CustomQueryControls
                          { ...{ order, orderBy } }
                          onOrderChange={ ( value ) => setAttributes( { order: value } ) }
                          onOrderByChange={ ( value ) => setAttributes( { orderBy: value } ) }
                          numberOfItems={ postsToShow }
                          onNumberOfItemsChange={ ( value ) => setAttributes( { postsToShow: value } ) }
                        />,
                   ]

                  })()}
                  {/* end of list type conditionals */}

                  {/* generic parameters */}

                  { ( listType === 'choose-list-type' || listType === 'list-of-categories') ? (
                    <p></p>
                  ) : (
                  <Fragment>
                    <ToggleControl
                        label={ __( 'Toggle Post Market Language selection' ) }
                        help={ 'Important Note:Please ensure to refresh the post once if you assign/change current market and language.'}
                        checked={ displaySmByPostMarketLanguage }
                        onChange={ ( value ) => {
                              setAttributes({ displaySmByPostMarketLanguage: value })
                              this.smartlistByPostMarketLanguage(value);
                              }}
                     />
                    { !displaySmByPostMarketLanguage && [
                      <Fragment>
                        <PanelBody title={ __( 'Markets' ) }>
                          {markets &&
                            markets.map( (market, index) =>
                              <CheckboxControl
                                label={market.name}
                                checked={ market.checked }
                                onChange={
                                  this.marketToggleCheckbox.bind(this, index)
                                }
                              />
                            )
                          }
                        </PanelBody>
                        <PanelBody title={ __( 'Languages' ) }>
                          {languages &&
                            languages.map( (language, index) =>
                              <CheckboxControl
                                label={language.name}
                                checked={ language.checked }
                                onChange={
                                  this.languageToggleCheckbox.bind(this, index)
                                }
                              />
                            )
                          }
                        </PanelBody>
                      </Fragment>
                      ]
                    }

                      <PanelBody title={ __( 'Learn More Button' ) }>
                          <ToggleControl
                            label={ __( 'Enable Learn More Button' ) }
                            checked={ enableLearnMoreButton }
                            // onChange={ ( value ) => setAttributes( { enableLearnMoreButton: value } ) }

                            onChange={ ( value ) => {
                              setAttributes( {
                                enableLearnMoreButton: value,
                                customizeLearnMoreButton: false,
                                customLearnMoreUrl: '',
                                learnMoreText: 'Learn More',
                              } );
                            } }
                          />
                          <Fragment>
                            { enableLearnMoreButton === true && [
                                <Fragment>
                                  <ToggleControl
                                    label={ __( 'Open In New Tab' ) }
                                    checked={ openInNewTab }
                                    onChange={ ( value ) => setAttributes( { openInNewTab: value } ) }
                                  />
                                  <ToggleControl
                                    label={ __( 'Customize' ) }
                                    checked={ customizeLearnMoreButton }
                                    onChange={ ( value ) => setAttributes( { customizeLearnMoreButton: value,
                                      customLearnMoreUrl: '',
                                      learnMoreText: 'Learn More'
                                    } ) }
                                  />
                                  { customizeLearnMoreButton === true && [
                                      <TextControl
                                        label={ __( 'Button Text' ) }
                                        value={ learnMoreText }
                                        placeholder={ __( "Customize text" ) }
                                        onChange={ ( value ) => setAttributes( { learnMoreText: value } ) }
                                      />,
                                      <TextControl
                                        label={ __( 'Custom Link' ) }
                                        // value={ customLearnMoreUrl ?
                                        //     ( customLearnMoreUrl ) :
                                        //     ( learnMoreUrl )
                                        // }
                                        placeholder={ __( "New Custom Link" ) }
                                        onChange={ ( value ) => setAttributes( { customLearnMoreUrl: value } ) }
                                        // onChange={ ( value ) =>
                                        //   this.customizeLearnMoreUrl(value)
                                        // }
                                      />,
                                      // <p><i>Current Link Path:<br></br> { customLearnMoreUrl ?
                                      //     ( customLearnMoreUrl ) :
                                      //     ( learnMoreUrl )
                                      // }</i></p>
                                    ]
                                  }
                                </Fragment>
                              ]
                            }
                          </Fragment>
                      </PanelBody>

                      { postLayout === 'grid' && [
                        <PanelBody title={ __( 'Display' ) }>
                          <RangeControl
                            label={ __( 'Columns' ) }
                            value={ columns }
                            onChange={ ( value ) => {
                              setAttributes( { columns: value } )
                              this.convertColumnsToBootstrapColumns(value);
                            }}
                            min={ 1 }
                            max={ ! hasPosts ? MAX_POSTS_COLUMNS : Math.min( MAX_POSTS_COLUMNS, smartListPosts.length ) }
                          />
                          { postType === 'insight' && [
                            <Fragment>
                              <ToggleControl
                                label={ __( 'Display Category' ) }
                                checked={ displayCategory }
                                onChange={ ( value ) => setAttributes( { displayCategory: value } ) }
                              />

                              <ToggleControl
                                label={ __( 'Display Format' ) }
                                checked={ displayFormat }
                                onChange={ ( value ) => setAttributes( { displayFormat: value } ) }
                              />
                            </Fragment>
                        ]}
                          <ToggleControl
                            label={ __( 'Display Item Description' ) }
                            checked={ displayItemDescription }
                            onChange={ ( value ) => setAttributes( { displayItemDescription: value } ) }
                          />
                          <ToggleControl
                            label={ __( 'Display Item Thumbnail' ) }
                            checked={ displayItemThumbnail }
                            onChange={ ( value ) => setAttributes( { displayItemThumbnail: value } ) }
                          />
                          <ToggleControl
                            label={ __( 'Enable Read More Buttons' ) }
                            checked={ enableReadMoreButton }
                            onChange={ ( value ) => {
                              setAttributes( {
                                enableReadMoreButton: value,
                                customizeReadMoreButton: false,
                                readMoreText: 'Read More >',
                              } );
                            } }
                          />
                          <Fragment>
                            { enableReadMoreButton === true && [
                                <Fragment>
                                  <ToggleControl
                                    label={ __( 'Customize Read More Button Text' ) }
                                    checked={ customizeReadMoreButton }
                                    onChange={ ( value ) => setAttributes( { customizeReadMoreButton: value,
                                      readMoreText: 'Read More >'
                                    } ) }
                                  />
                                  { customizeReadMoreButton === true && [
                                      <TextControl
                                        label={ __( 'Link Text' ) }
                                        value={ readMoreText }
                                        placeholder={ __( "Customize text" ) }
                                        onChange={ ( value ) => setAttributes( { readMoreText: value } ) }
                                      />
                                    ]
                                  }
                                </Fragment>
                              ]
                            }
                          </Fragment>


                        </PanelBody>
                      ]}

                      { (postLayout === 'list' && postType === 'insight') && [
                        <PanelBody title={ __( 'Display' ) }>
                          <ToggleControl
                            label={ __( 'Display Category' ) }
                            checked={ displayCategory }
                            onChange={ ( value ) => setAttributes( { displayCategory: value } ) }
                          />
                          <ToggleControl
                            label={ __( 'Display Format' ) }
                            checked={ displayFormat }
                            onChange={ ( value ) => setAttributes( { displayFormat: value } ) }
                          />
                          <ToggleControl
                            label={ __( 'Display Date' ) }
                            checked={ displayDate }
                            onChange={ ( value ) => setAttributes( { displayDate: value } ) }
                          />
                          <ToggleControl
                            label={ __( 'Display Title As Branded Font' ) }
                            checked={ displayTitleAsBrandedFont }
                            onChange={ ( value ) => setAttributes( { displayTitleAsBrandedFont: value } ) }
                          />
                          <ToggleControl
                            label={ __( 'Display Item Description' ) }
                            checked={ displayItemDescription }
                            onChange={ ( value ) => setAttributes( { displayItemDescription: value } ) }
                          />

                        </PanelBody>
                      ]}

                    </Fragment>
                  )}
                </Fragment>
              )
            }

        </PanelBody>
      </InspectorControls>
    );

    // RENDER POSTS OR CATEGORIES

    const hasCategories = Array.isArray( categoriesList ) && categoriesList.length;

    const hasPosts = enableFeaturedPosts === 'show-featured' ? Array.isArray( featuredPosts ) && featuredPosts.length : Array.isArray( smartListPosts ) && smartListPosts.length


    if(listType === "list-of-categories"){
      // Categories List Render
        if ( ! hasCategories ) {
          return (
            <Fragment>
              {inspectorControls}
              <Placeholder
                icon={ blockTable }
                label={ __( 'SmartList Posts' ) }
              >
                { ! Array.isArray( categoriesList ) && typeof(categoriesList) !== 'undefined' ?
                  <Spinner /> :
                  __( 'No Categories found.' )
                }
              </Placeholder>
            </Fragment>
          );
        }

        // Removing posts from display should be instant.
        const displayCategories = categoriesList;
        const layoutControls = [
          {
            icon: postList,
            title: __( 'List View' ),
            onClick: () => setAttributes( { postLayout: 'list' } ),
            isActive: postLayout === 'list',
          }
        ];

          // Render editor content (if available)
          return (
            <Fragment>
              {inspectorControls}
              <BlockControls>
                <Toolbar controls={ layoutControls } />
              </BlockControls>
              <div className="module">
                <h2>{title}</h2>
                <ul
                  className={
                    classnames(
                      this.props.className,
                      {
                        'is-grid': postLayout === 'grid',
                        [ `columns-${ columns }` ]: postLayout === 'grid',
                      },
                      {
                        'link-list nav': postLayout != 'grid',
                      },
                    )
                  }
                >
                  { displayCategories.map( ( category, i ) =>
                    <li key={ i }>
                      <a href={ category.link } target="_blank">
                        { category.name || __( '(Untitled)' ) }
                      </a>
                    </li>
                  ) }
                </ul>
              </div>

              { enableLearnMoreButton === true && [
                  <div
                    style={ { display: 'inline-block' } }
                    className='regular'
                  >
                    <Button
                      className={ classnames( 'content-button', 'btn', 'btn-blue' ) }
                      style={ { marginTop: '0px' } }
                      // href={ customLearnMoreUrl && customLearnMoreUrl.length ? customLearnMoreUrl : learnMoreUrl }
                      href={ customLearnMoreUrl ?
                          ( customLearnMoreUrl ) :
                          ( learnMoreUrl )
                      }
                      target="_blank"
                    >{ learnMoreText }
                    </Button>
                  </div>
                ]
              }
            </Fragment>
          );
    }

    if (listType ==="format" || listType ==="list-of-posts"){

      // Posts List Render
      if ( ! hasPosts ) {
        return (
          <Fragment>
            {inspectorControls}
            <Placeholder
              icon={ blockTable }
              label={ __( 'SmartList Posts' ) }
            >
              { ! Array.isArray( smartListPosts ) ?
                <Spinner /> :
                __( 'No posts found.' )
              }
            </Placeholder>
          </Fragment>
        );
      }

      // Removing posts from display should be instant.

      let displayPosts;
      let nonfeaturedPosts;
      nonfeaturedPosts = differenceBy(smartListPostsEx, featuredPosts, 'id');

      if ( enableFeaturedPosts === 'show-featured' ) {
        displayPosts = featuredPosts.length > postsToShow ?
          featuredPosts.slice( 0, postsToShow ) :
          featuredPosts;
      } else if( enableFeaturedPosts === 'non-featured') {
        displayPosts = nonfeaturedPosts.length > postsToShow ?
          nonfeaturedPosts.slice( 0, postsToShow ) :
          nonfeaturedPosts;
      }
      else {
        displayPosts = smartListPosts.length > postsToShow ?
          smartListPosts.slice( 0, postsToShow ) :
          smartListPosts;
      }
      const layoutControls = [
        {
          icon: postList,
          title: __( 'List View' ),
          onClick: () => setAttributes( { postLayout: 'list' } ),
          isActive: postLayout === 'list',
        },
        {
          icon: grid,
          title: __( 'Grid View' ),
          onClick: () => setAttributes( { postLayout: 'grid' } ),
          isActive: postLayout === 'grid',
        },
      ];

      // Render editor content (if available)
      return [
        <Fragment>
          { inspectorControls }
          <BlockControls>
            <Toolbar controls={ layoutControls } />
          </BlockControls>


            { /* STYLING FOR GRID VS LIST */}
            { postLayout === 'grid' ? [
              <Fragment>

                <div className="module row">
                  <h2>{title}</h2>

                { /* Begin main container with className */}
                <div
                  className={
                    classnames(
                      this.props.className,
                      {
                        'is-grid': postLayout === 'grid',
                        // [ `col-md-${ columns }` ]: postLayout === 'grid',
                      },
                      {
                        'link-list nav': postLayout != 'grid',
                      },
                    )
                  }
                >
                { displayPosts.map( ( post, i ) =>
                  post.visibility_options_exclude_from_search_results ? '' : (

                  <div key={ i } className={
                    classnames(
                      {
                        [ `col-md-${ bootstrap_columns } p-2` ]: postLayout === 'grid',
                      },
                    )
                  }>

                    {/* BEGIN POST */}
                    <div className="related-post">

                    <div className="format-wrapper" style={ { position: 'relative' } }>
                    {/* IMAGE */}
                    { postLayout === 'grid' ? (
                      <Fragment>
                      {displayItemThumbnail === true && [
                        <Fragment>
                          {/* if no meta_image, use featured image, otherwise use the open-graph default image */}
                          { post.meta_image ? (
                              // <img src={post.meta_image}/>
                              // <Fragment>
                                <a href={post.link}>
                                  <div className="related-featured-image">
                                    <img className="featured-image-thumbnail img-fluid" src={post.meta_image}/>
                                  </div>
                                </a>
                              // </Fragment>
                            ): (
                             post._links['wp:featuredmedia'] ? (
                              <a href={post.link}>
                                <div className="related-featured-image">
                                  <img className="featured-image-thumbnail img-fluid" src='/wp-content/themes/nielsen-base/dist/images/smartlist-placeholder.png'/>
                                </div>
                              </a>
                              // <img src='/wp-content/themes/nielsen-base/dist/images/smartlist-placeholder.png'/>
                              ): (
                              <a href={post.link}>
                                <div className="related-featured-image">
                                  <img className="featured-image-thumbnail img-fluid" src='/wp-content/themes/nielsen-base/dist/images/open-graph-default.png'/>
                                </div>
                              </a>
                              // <img src='/wp-content/themes/nielsen-base/dist/images/open-graph-default.png'/>
                              )
                            )
                          }
                        </Fragment>
                      ]}

                      </Fragment>
                    ): null }

                    {/* INSIGHT FORMAT FOR GRID */}
                       { (! Array.isArray( formatsList ) ) && (postType === "insight") ?
                          <Spinner /> : [
                          <Fragment>
                            { displayFormat === true ? [
                              <Fragment>
                                <div className="entry-formats" style={ { 'position': 'absolute', 'bottom': '0' } }>

                                { post.formats.map((postFormat, i) =>
                                   <h5 className='taxonomy-term formats knockout d-flex align-items-center text-center mb-0'>

                                     <a className="format-link" style={ { 'backgroundColor': '#333', 'color': 'white', 'padding': '3px' } }>
                                       { formatsList.filter(format =>
                                         format.id === postFormat
                                       ).map(format =>
                                         format.name
                                       )}
                                     </a> {i === post.formats.length - 1 ? '' : ' | '}
                                     <span className={"format " + postFormat.name}>
                                     </span>
                                   </h5>
                                 )}

                                </div>

                              </Fragment>
                            ]: null }
                          </Fragment>
                          ]
                        }
                    { /* END FORMAT-WRAPPER */}
                    </div>

                    {/* BEGIN SUMMARY */}
                    <div className="related-entry-summary bg-white p-3 cat-grid"
                          ref={(el) => {
                            if (el) {
                              el.style.setProperty( 'padding-left', '0px', 'important');
                            }
                          } }
                          >

                    {/* INSIGHT CATEGORY FOR GRID */}
                       { (! Array.isArray( categoriesList ) ) && (postType === "insight") ?
                          <Spinner /> : [
                          <Fragment>
                            { displayCategory === true ? [
                              <Fragment>
                                <div className="entry-meta h5 grid-cat">

                                { post.insight_categories.map((postCategory, i) =>
                                   <span className='taxonomy-term knockout'>
                                     <h5 style={ { color: '#333' } }>
                                       { categoriesList.filter(category =>
                                         category.id === postCategory
                                       ).map(category =>
                                         category.name
                                       )}
                                     </h5> {i === post.insight_categories.length - 1 ? '' : ' | '}
                                   </span>
                                    // category.id === post.insight_categories[i]
                                 )}

                                </div>

                              </Fragment>
                            ]: null }
                          </Fragment>
                          ]
                        }


                    {/* TITLE */}
                    {/* Check if meta-title exists. If so, use it. Otherwise, use the default rendered title. Also check if it's grid display. Add an h3 if it's grid */}
                    { post.meta_title ? (
                      <div className="related-title">
                        <h3>
                          <a href={ post.link } title={ post.meta_title.trim() || __( '(Untitled)' ) }>{ post.meta_title.trim() || __( '(Untitled)' ) }
                          </a>
                        </h3>
                      </div>
                    ): (
                      <div className="related-title">
                        <h3>
                          <a href={ post.link } title={ post.title.rendered.trim() || __( '(Untitled)' ) }>{ post.title.rendered.trim() || __( '(Untitled)' ) }
                          </a>
                        </h3>
                      </div>
                    )}

                    {/* DESCRIPTION */}
                    {/* Interim EXCERPT EDITOR CODE - to prevent editor from pulling in auto-generated excerpts from post page content */}


                    { displayItemDescription === true ? (
                      <Fragment>
                      { post.meta_description ? [
                        <div className="related-excerpt">
                          <p style={{color: 'black'}}>{ post.meta_description }</p>
                        </div>
                      ]:
                        <div className="related-excerpt">
                          <p style={{color: 'black'}}></p>
                        </div>
                      }
                      </Fragment>
                    ): null }


                  {/* READ MORE */}
                  {/* Interim EXCERPT EDITOR CODE - to prevent editor from pulling in auto-generated excerpts from post page content */}

                  { enableReadMoreButton === true ? (
                    <Fragment>
                    { post.meta_title ? (
                      <div className="related-read-more">
                        <a className="more-link" href={post.link} title={post.meta_title.trim()}
                        style={
                          { 'font-family': 'Open Sans,Helvetica Neue,Helvetica,Arial,sans-serif' , 'font-size': '16px' , 'line-height': '26px' ,'font-weight': '400' , 'font-style': 'normal' , 'background': '#fff' }
                        }>
                          {readMoreText}
                        </a>
                      </div>
                    ): (
                      <div className="related-read-more">
                        <a className="more-link" href={post.link} title={post.title.rendered.trim()}
                        style={
                          { 'font-family': 'Open Sans,Helvetica Neue,Helvetica,Arial,sans-serif' , 'font-size': '16px' , 'line-height': '26px' ,'font-weight': '400' , 'font-style': 'normal' , 'background': '#fff' }
                        }>
                          {readMoreText}
                        </a>
                      </div>
                    )}
                    </Fragment>

                    ) : null
                  }



                      {/* END SUMMARY */}
                      </div>

                      {/* END POST */}
                      </div>

                    </div>
                  ) ) }
                </div>
                {/* finish creation of main post components: image, title, description */}
                </div>

                {/* finish styling for GRID */}
                </Fragment>


              ] : [

                <Fragment>

                {/* begin styling for list-view */}

                  <div
                    className={
                      classnames(
                        this.props.className,
                        {
                          'module': enableFeaturedPosts !== 'show-featured',

                        },
                        {
                          'module featured-list pl-3': enableFeaturedPosts === 'show-featured',
                        },
                      )
                    }
                    style={
                      {
                        backgroundColor: enableFeaturedPosts === 'show-featured'? '#f8f9fa': ''
                    }
                  }
                  >
                    <h2>{title}</h2>

                      { enableFeaturedPosts === 'show-featured' && postType === 'insight'? [
                        <Fragment>
                          <h1 style={ { 'color': '#3e484e', 'marginBottom': '40px' } }>Featured Insights</h1>

                        </Fragment>
                      ]: enableFeaturedPosts === 'show-featured' && postType === 'news_center'? [
                          <Fragment>
                            <h1 style={ { 'color': '#3e484e', 'marginBottom': '40px' } }>Featured News</h1>

                          </Fragment>
                        ]: null
                      }

                    <ul
                      className={
                        classnames(
                          this.props.className,
                          {
                            'is-grid': postLayout === 'grid',
                            [ `columns-${ columns }` ]: postLayout === 'grid',
                          },
                          {
                            'link-list nav': postLayout != 'grid',
                          },
                        )
                      }
                    >

                    { displayPosts.map( ( post, i ) =>
                      post.visibility_options_exclude_from_search_results ? '' : (

                      <li key={ i }
                        className={
                          enableFeaturedPosts === 'show-featured' ? "nielsen-post" : ""
                        }
                      >

                      {/* INSIGHT FORMAT FOR LIST */}
                         { (! Array.isArray( formatsList ) ) && (postType === "insight") ?
                            <Spinner /> : [
                            <Fragment>
                              { displayFormat === true ? [
                                <Fragment>
                                  <div className="entry-formats" style={ { 'marginBottom': '15px' } }>

                                  { post.formats.map((postFormat, i) =>
                                     <h5 className='taxonomy-term formats knockout d-flex align-items-center text-center mb-0'>

                                       <a className="format-link" style={ { 'backgroundColor': '#333', 'color': 'white', 'padding': '3px' } }>
                                         { formatsList.filter(format =>
                                           format.id === postFormat
                                         ).map(format =>
                                           format.name
                                         )}
                                       </a> {i === post.formats.length - 1 ? '' : ' | '}
                                       <span className={"format " + postFormat.name}>
                                       </span>
                                     </h5>
                                   )}

                                  </div>

                                </Fragment>
                              ]: null }
                            </Fragment>
                            ]
                          }
                      { /* END FORMAT-WRAPPER */}

                       {/* CATEGORY & DATE */}

                       { (! Array.isArray( categoriesList ) ) && (postType === "insight") ?
                          <Spinner /> : [
                          <Fragment>
                            { displayCategory === true ? [
                              <Fragment>
                                <div className="entry-meta h5 list-cat">

                                { post.insight_categories.map((postCategory, i) =>
                                   <span className='taxonomy-term knockout'>
                                     <a style={ { color: '#00aeef' } } href={ categoriesList.filter(category =>
                                       category.id === postCategory
                                     ).map(category =>
                                       category.link
                                    )}>
                                       { categoriesList.filter(category =>
                                         category.id === postCategory
                                       ).map(category =>
                                         category.name
                                       )}
                                     </a> {i === post.insight_categories.length - 1 ? '' : ' | '}
                                   </span>
                                    // category.id === post.insight_categories[i]
                                 )}

                                  {/* display divider bar if a category exists before the date */}
                                  { displayDate === true ? [
                                    <Fragment>
                                      { categoriesList.filter(category =>
                                         category.id === post.insight_categories[0]
                                       ).map(category =>
                                         category.name
                                       ) != "" ?
                                        " | "
                                        :
                                        null
                                      }

                                      {/* display the date */}
                                      <time className="updated knockout h5" dateTime={ post.date }> { simplifyDate(post.date) } </time>
                                    </Fragment>
                                    ]: null
                                  }

                                </div>

                              </Fragment>
                            ]: null }
                          </Fragment>
                          ]
                        }

                        {/* DATE ALONE */}
                        { displayDate === true && displayCategory === false ? [
                          <Fragment>
                            {/* display the date */}
                            <time className="updated knockout h5" dateTime={ post.date }> { simplifyDate(post.date) } </time>
                          </Fragment>
                        ]: null }

                        {/* TITLE */}
                        { displayTitleAsBrandedFont === true ? [
                          <Fragment>
                            { post.meta_title ? (
                              <h2 className="entry-title h1"><a href={ post.link } target="_blank">{ post.meta_title.trim() || __( '(Untitled)' ) }</a></h2>
                            ): (
                              <h2 className="entry-title h1"><a href={ post.link } target="_blank">{ post.title.rendered.trim() || __( '(Untitled)' ) }</a></h2>
                            )}
                          </Fragment>
                        ] :
                          <Fragment>
                            { post.meta_title ? (
                              <a href={ post.link } target="_blank">{ post.meta_title.trim() || __( '(Untitled)' ) }</a>
                            ): (
                              <a href={ post.link } target="_blank">{ post.title.rendered.trim() || __( '(Untitled)' ) }</a>
                            )}
                          </Fragment>
                        }


                        {/* DESCRIPTION */}
                        { displayItemDescription === true && [
                          <Fragment>

                              <div className="entry-summary">{ post.meta_description }</div>
                          </Fragment>
                        ]}

                        </li>
                      ) ) }
                    </ul>
                    {/* finish creation of main post components: image, title, description */}

                  </div>
                  {/* begin styling for list-view */}

                </Fragment>

            ]}




          { enableLearnMoreButton === true && [
              <div
                style={ { display: 'inline-block' } }
                className='regular'
              >
                <Button
                  className={ classnames( 'content-button', 'btn', 'btn-blue' ) }
                  style={ { marginTop: '0px' } }
                  // href={ customLearnMoreUrl && customLearnMoreUrl.length ? customLearnMoreUrl : learnMoreUrl }
                  href={ customLearnMoreUrl ?
                      ( customLearnMoreUrl ) :
                      ( learnMoreUrl )
                    }
                  target="_blank"
                >{ learnMoreText }
                </Button>
              </div>
            ]
          }
        </Fragment>,
      ];
    }

    // if section and list type haven't been selected yet
    if (postType === 'choose-section' && listType === "choose-list-type") {

      if ( ! hasPosts ) {
        return (
          <Fragment>
            {inspectorControls}
            <Placeholder
              icon={ blockTable }
              label={ __( 'SmartList Posts' ) }
            >
              { ! Array.isArray( smartListPosts ) ?
                <Spinner /> :
                __( 'Choose Content Section' )
              }
            </Placeholder>
          </Fragment>
        );
      }


      // Removing posts from display should be instant.

      let displayPosts;
      let nonfeaturedPosts;
      nonfeaturedPosts = differenceBy(smartListPostsEx, featuredPosts, 'id');

      if ( enableFeaturedPosts === 'show-featured' ) {
         displayPosts = featuredPosts.length > postsToShow ?
          featuredPosts.slice( 0, postsToShow ) :
          featuredPosts;
      } else if( enableFeaturedPosts === 'non-featured') {
        displayPosts = nonfeaturedPosts.length > postsToShow ?
          nonfeaturedPosts.slice( 0, postsToShow ) :
          nonfeaturedPosts;
      }
      else {
         displayPosts = smartListPosts.length > postsToShow ?
          smartListPosts.slice( 0, postsToShow ) :
          smartListPosts;
      }


      const layoutControls = [
        {
          icon: postList,
          title: __( 'List View' ),
          onClick: () => setAttributes( { postLayout: 'list' } ),
          isActive: postLayout === 'list',
        }
      ];


      // Render editor content (if available)
      return [
        <Fragment>
          { inspectorControls }
          <BlockControls>
            <Toolbar controls={ layoutControls } />
          </BlockControls>
          <div className="module">
            <h2>{title}</h2>
            <ul
              className={
                classnames(
                  this.props.className,
                  {
                    'is-grid': postLayout === 'grid',
                    [ `bootstrap_columns-${ columns }` ]: postLayout === 'grid',
                  },
                  {
                    'link-list nav': postLayout != 'grid',
                  },
                )
              }
            >
              { displayPosts.map( ( post, i ) =>
                post.visibility_options_exclude_from_search_results ? '' : (
                <li key={ i }>
                  {/* TITLE */}
                  { post.meta_title ? (
                    <a href={ post.link } target="_blank">{ post.meta_title.trim() || __( '(Untitled)' ) }</a>
                  ): (
                    <a href={ post.link } target="_blank">{ post.title.rendered.trim() || __( '(Untitled)' ) }</a>
                  )}
                </li>
              ) ) }
            </ul>
          </div>
          { enableLearnMoreButton === true && [
              <div
                style={ { display: 'inline-block' } }
                className='regular'
              >
                <Button
                  className={ classnames( 'content-button', 'btn', 'btn-blue' ) }
                  style={ { marginTop: '0px' } }
                  // href={ customLearnMoreUrl && customLearnMoreUrl.length ? customLearnMoreUrl : learnMoreUrl }
                  href={ customLearnMoreUrl ?
                      ( customLearnMoreUrl ) :
                      ( learnMoreUrl )
                    }
                  target="_blank"
                >{ learnMoreText }
                </Button>
              </div>
            ]
          }
        </Fragment>,
      ];
    }

    // if list type hasn't been selected yet
    if (listType === "choose-list-type") {

      if ( ! hasPosts ) {
        return (
          <Fragment>
            {inspectorControls}
            <Placeholder
              icon={ blockTable }
              label={ __( 'SmartList Posts' ) }
            >
              { ! Array.isArray( smartListPosts ) ?
                <Spinner /> :
                __( 'Choose List Type.' )
              }
            </Placeholder>
          </Fragment>
        );
      }

      // Removing posts from display should be instant.

      let displayPosts;
      let nonfeaturedPosts;
      nonfeaturedPosts = differenceBy(smartListPostsEx, featuredPosts, 'id');

      if ( enableFeaturedPosts === 'show-featured' ) {
        displayPosts = featuredPosts.length > postsToShow ?
          featuredPosts.slice( 0, postsToShow ) :
          featuredPosts;
      } else if( enableFeaturedPosts === 'non-featured') {
        displayPosts = nonfeaturedPosts.length > postsToShow ?
          nonfeaturedPosts.slice( 0, postsToShow ) :
          nonfeaturedPosts;
      }
      else {
        displayPosts = smartListPosts.length > postsToShow ?
          smartListPosts.slice( 0, postsToShow ) :
          smartListPosts;
      }

      const layoutControls = [
        {
          icon: postList,
          title: __( 'List View' ),
          onClick: () => setAttributes( { postLayout: 'list' } ),
          isActive: postLayout === 'list',
        }
      ];


      // Render editor content (if available)
      return [
        <Fragment>
          { inspectorControls }
          <BlockControls>
            <Toolbar controls={ layoutControls } />
          </BlockControls>
          <div className="module">
            <h2>{title}</h2>
            <ul
              className={
                classnames(
                  this.props.className,
                  {
                    'is-grid': postLayout === 'grid',
                    [ `columns-${ columns }` ]: postLayout === 'grid',
                  },
                  {
                    'link-list nav': postLayout != 'grid',
                  },
                )
              }
            >
              { displayPosts.map( ( post, i ) =>
                post.visibility_options_exclude_from_search_results ? '' : (
                <li key={ i }>
                  {/* TITLE */}
                  { post.meta_title ? (
                    <a href={ post.link } target="_blank">{ post.meta_title.trim() || __( '(Untitled)' ) }</a>
                  ): (
                    <a href={ post.link } target="_blank">{ post.title.rendered.trim() || __( '(Untitled)' ) }</a>
                  )}
                </li>
              ) ) }
            </ul>
          </div>
          { enableLearnMoreButton === true && [
              <div
                style={ { display: 'inline-block' } }
                className='regular'
              >
                <Button
                  className={ classnames( 'content-button', 'btn', 'btn-blue' ) }
                  style={ { marginTop: '0px' } }
                  // href={ customLearnMoreUrl && customLearnMoreUrl.length ? customLearnMoreUrl : learnMoreUrl }
                  href={ customLearnMoreUrl ?
                      ( customLearnMoreUrl ) :
                      ( learnMoreUrl )
                    }
                  target="_blank"
                >{ learnMoreText }
                </Button>
              </div>
            ]
          }
        </Fragment>,
      ];
    }


  }
}

export default withSelect( ( select, props ) => {
  const {
    postsToShow,
    order,
    orderBy,
    categories,
    tags,
    formats,
    businessTerm,
    marketsSelected,
    featuredPosts,
    nonfeaturedPosts,
    smartListPosts,
    languagesSelected,
    postType

  } = props.attributes;

  const categoriesName = postType + "_categories"
  const tagsName = postType + "_related_tags"
  const excludedMarkets = "exclude_markets"
  const { getEntityRecords } = select( 'core' );
  const smartListPostsQueryObj = {
    order,
    orderby: orderBy,
    per_page: postsToShow,
  }

  let queryPostType = ''
  if (postType==='choose-section') {
    queryPostType = 'post'
  } else {
    queryPostType = postType
  }

//Find out excluded post ids and add them to an array

  // Select all featured articles after selecting markets
  let featuredArticles = getEntityRecords('postType', queryPostType, { orderby: orderBy, metaKey: 'article_featured', metaValue: '1', per_page: postsToShow, markets: marketsSelected });
  // Pick the info of excluded market ids and post ids from featured articles
  const excludeMarketPosts = _.map(featuredArticles, i =>_.pick(i, 'id','exclude_markets', 'title') );
  let excludePostArr = [];
  for (let i=0; i < excludeMarketPosts.length; i++){
    //Check if excluded market ids have intersection with selected market ids, if so get that post id and save it in an array
    const excludeMarketsExist = _.intersection(excludeMarketPosts[i]['exclude_markets'],marketsSelected);
    if( excludeMarketsExist.length > 0  ) {
      excludePostArr.push( excludeMarketPosts[i]['id'] );
    }
  }

  const featuredPostsQueryObj = {
    order,
    orderby: orderBy,
    metaKey: 'article_featured',
    metaValue: '1',
    per_page: postsToShow,
    markets: marketsSelected,
    exclude: excludePostArr,//Add the excluded array
  }
  const smartListPostsQueryObjEx = {
    order,
    orderby: orderBy,
    per_page: postsToShow,
    exclude: excludePostArr,
  }

  if(marketsSelected.length){
    smartListPostsQueryObj['markets'] = marketsSelected.join(',')
    smartListPostsQueryObjEx['markets'] = marketsSelected.join(',')
    featuredPostsQueryObj['markets'] = marketsSelected.join(',')
  }
  if(languagesSelected.length){
    smartListPostsQueryObj['languages'] = languagesSelected.join(',')
    smartListPostsQueryObjEx['languages'] = languagesSelected.join(',')
    featuredPostsQueryObj['languages'] = languagesSelected.join(',')
  }
  if(categories && categories.length){
    smartListPostsQueryObj[categoriesName] = categories
    smartListPostsQueryObjEx[categoriesName] = categories
    featuredPostsQueryObj[categoriesName] = categories
  }
  if(tags && tags.length){
    smartListPostsQueryObj[tagsName] = tags
    smartListPostsQueryObjEx[tagsName] = tags
    featuredPostsQueryObj[tagsName] = tags
  }
  if(formats && formats.length){
    smartListPostsQueryObj['formats'] = formats
    smartListPostsQueryObjEx['formats'] = formats
    featuredPostsQueryObj['formats'] = formats
  }
  if(businessTerm && businessTerm.length){
    smartListPostsQueryObj['business'] = businessTerm
    smartListPostsQueryObjEx['business'] = businessTerm
    featuredPostsQueryObj['business'] = businessTerm
  }

  const smartListPostsQuery = pickBy( smartListPostsQueryObj, ( value ) => ! isUndefined( value ) );
  const featuredPostsQuery = pickBy( featuredPostsQueryObj, ( value ) => ! isUndefined( value ) );

  let smartListPostsEx = getEntityRecords( 'postType', queryPostType, smartListPostsQueryObjEx );

  const listQuery = {
    per_page: 100,
  };

	switch( queryPostType ) {
    case 'event':
      return {
        smartListPosts: getEntityRecords( 'postType', queryPostType, smartListPostsQuery ),
        categoriesList: getEntityRecords( 'taxonomy', queryPostType + '_categories', listQuery ),
        businessList: getEntityRecords( 'taxonomy', 'business', listQuery ),
        relatedTagsList: getEntityRecords( 'taxonomy', queryPostType + '_related_tags', listQuery ),
        formatsList: getEntityRecords( 'taxonomy', 'formats', listQuery ),

        };
    break;
    case 'press_release':
      return {
        smartListPosts: getEntityRecords( 'postType', queryPostType, smartListPostsQuery ),
        relatedTagsList: getEntityRecords( 'taxonomy', queryPostType + '_related_tags', listQuery ),
        businessList: getEntityRecords( 'taxonomy', 'business', listQuery ),
        formatsList: getEntityRecords( 'taxonomy', 'formats', listQuery ),
        categoriesList: getEntityRecords( 'taxonomy', queryPostType + '_categories', listQuery ),
        };
    break;
    case 'solution':
      return {
        smartListPosts: getEntityRecords( 'postType', queryPostType, smartListPostsQuery ),
        categoriesList: getEntityRecords( 'taxonomy', queryPostType + '_categories', listQuery ),
        relatedTagsList: getEntityRecords( 'taxonomy', queryPostType + '_related_tags', listQuery ),
        businessList: getEntityRecords( 'taxonomy', 'business', listQuery ),
        formatsList: getEntityRecords( 'taxonomy', 'formats', listQuery ),
        };
    break;
    case 'about_us':
    case 'client_learning':
    case 'top_ten':
    case 'panel':
    case 'legal':
    case 'page':
      return {
        smartListPosts: getEntityRecords( 'postType', queryPostType, smartListPostsQuery ),
        categoriesList: getEntityRecords( 'taxonomy', queryPostType + '_categories', listQuery ),
        businessList: getEntityRecords( 'taxonomy', 'business', listQuery ),
        relatedTagsList: getEntityRecords( 'taxonomy', queryPostType + '_related_tags', listQuery ),
        formatsList: getEntityRecords( 'taxonomy', 'formats', listQuery ),
        };
      break;
    default:
      return {
        smartListPosts: getEntityRecords( 'postType', queryPostType, smartListPostsQuery ),
        smartListPostsEx: getEntityRecords( 'postType', queryPostType, smartListPostsQueryObjEx ),
        featuredPosts: getEntityRecords('postType', queryPostType, featuredPostsQueryObj ),
        nonfeaturedPosts: differenceBy(smartListPostsEx, featuredPosts, 'id'),
        categoriesList: getEntityRecords( 'taxonomy', queryPostType + '_categories', listQuery ),
        relatedTagsList: getEntityRecords( 'taxonomy', queryPostType + '_related_tags', {per_page: 300} ),
        formatsList: getEntityRecords( 'taxonomy', 'formats', listQuery ),
        businessList: getEntityRecords( 'taxonomy', 'business', listQuery ),
      };
  }

} )( SmartListEdit );
