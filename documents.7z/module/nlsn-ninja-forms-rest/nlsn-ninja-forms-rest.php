<?php
/**
 * Plugin Name: Nielsen Ninja Forms REST API
 * Description: Ninja Forms data feed for google sheets
 * Version: 1.0
 * Author: Nielsen
 * Author URI: nielsen.com
 */

add_action( 'rest_api_init', function(){
  // all forms
  // wp-json/wp/v2/ninja-forms
	register_rest_route( 'wp/v2', '/ninja-forms', array(
		'methods' => WP_REST_Server::READABLE,
		'callback' => 'nlsn_process_ninja_forms_endpoint'
  ));
  // submissions by form id
  // wp-json/wp/v2/ninja-forms
  register_rest_route( 'wp/v2', '/ninja-forms(?:/(?P<id>\d+))?', array(
		'methods' => WP_REST_Server::READABLE,
		'callback' => 'nlsn_process_ninja_forms_subs_endpoint',
  ));
});

// ********------- NF Forms ----------************* //

// all forms
// wp-json/wp/v2/ninja-forms
function nlsn_process_ninja_forms_endpoint() {
  $forms_modified = array();
  $forms = Ninja_Forms()->form()->get_forms();
  foreach ( $forms as $form ) {
    $form_array = array();
    $form_array[ 'id' ] = $form->get_id();
    $form_array[ 'created_at' ] = $form->get_setting( 'created_at' );
    $form_array[ 'form_title' ] = $form->get_setting( 'form_title' );
    $form_array[ 'seq_num' ] = $form->get_setting( 'seq_num' );
    $forms_modified[] = $form_array;
  }
	return $forms_modified; 
}

// ********------- NF Submissions ----------************* //


// submissions by form id
// wp-json/wp/v2/ninja-forms/:form-id
function nlsn_process_ninja_forms_subs_endpoint($form_id) {

	$valid_key  = get_theme_mod( 'ninja_forms_api_key' );
	$valid_token  = get_theme_mod( 'ninja_forms_api_token' );
	if ( isset( $_SERVER['HTTP_KEY'] ) ) {
		$key = sanitize_text_field( wp_unslash( $_SERVER['HTTP_KEY'] ) );
	}
	if ( isset( $_SERVER['HTTP_TOKEN'] ) ) {
		$token = sanitize_text_field( wp_unslash( $_SERVER['HTTP_TOKEN'] ) );
	}
	// check if the key and token supplied in headers are valid
	if ( $key !== $valid_key || $token !== $valid_token ) {
		return get_forbidden_error();
	} else {
		$form_id = $form_id['id'];
		$value_array = [];
		// get submissions for given form_id
		$subs = Ninja_Forms()->form( $form_id )->get_subs(); 

		// if no subs; supply just the form fields
		if (empty($subs)) {
			$value = [];
			$value[ '_date_submitted' ] = 'no entries; data placeholder'; 
			$hidden_field_types = apply_filters( 'nf_sub_hidden_field_types', array() );
			$fields = Ninja_Forms()->form( $form_id )->get_fields(); 
			foreach ($fields as $field_id => $field) { 
				$field_key = $field->get_setting( 'key' );
				$field_labels = [];
				if (!is_int($field_id)) continue; 
				if( in_array( $field->get_setting( 'type' ), $hidden_field_types, TRUE ) ) continue; 
				if ( $field->get_setting( 'admin_label' ) ) { 
					$field_labels[ $field->get_id() ] = $field->get_setting( 'admin_label' ); 
				} else { 
					$field_labels[ $field->get_id() ] = $field->get_setting( 'label' );
				} 
				$field_value = 'no entries; data placeholder';
				if ( is_array($field_value ) ) { 
					$field_value = implode( ', ', $field_value ); 
				} 
				// add sanitized field value into array
				$value[ $field_key ] = $field_value; 
			}
			$value[ '_seq_num' ] = 'no entries; data placeholder'; 
			$value[ '_form_id' ] = 'no entries; data placeholder'; 
			$value_array[] = $value; 
			return $value_array;
		} else {
			// loop thru submissions
			foreach( $subs as $sub ) { 
				$value = [];
				// add date submitted value
				$value[ '_date_submitted' ] = $sub->get_sub_date( 'm/d/Y H:i' ); 
	
				// get all submission fields & values
				$fields = Ninja_Forms()->form( $form_id )->get_fields(); 
				$hidden_field_types = apply_filters( 'nf_sub_hidden_field_types', array() );
				// sanitize the fields & values
				foreach ($fields as $field_id => $field) { 
					$field_key = $field->get_setting( 'key' );
					$field_labels = [];
					if (!is_int($field_id)) continue; 
					if( in_array( $field->get_setting( 'type' ), $hidden_field_types, TRUE ) ) continue; 
					if ( $field->get_setting( 'admin_label' ) ) { 
						$field_labels[ $field->get_id() ] = $field->get_setting( 'admin_label' ); 
					} else { 
						$field_labels[ $field->get_id() ] = $field->get_setting( 'label' );
					} 
					$field_value = maybe_unserialize( $sub->get_field_value( $field_id ) );
					$field_value = apply_filters('nf_subs_export_pre_value', $field_value, $field_id); 
					$field_value = apply_filters('ninja_forms_subs_export_pre_value', $field_value, $field_id, $form_id); 
					if ( is_array($field_value ) ) { 
						$field_value = implode( ', ', $field_value ); 
					} 
					// add sanitized field value into array
					$value[ $field_key ] = $field_value; 
				} 
				// add additional submission detail values
				$value[ '_seq_num' ] = $sub->get_seq_num(); 
				$value[ '_form_id' ] = $sub->get_form_id(); 
				$value_array[] = $value; 
				$value_array = WPN_Helper::stripslashes( $value_array ); 
			} 
			return $value_array;
		}

	}
}

// ********------- NF Permissions ----------************* //

function get_forbidden_error() {
	return new WP_Error(
		'rest_forbidden',
		esc_html( "You do not have permission to do this." ),
		[ 'status' => 403 ]
	);
}