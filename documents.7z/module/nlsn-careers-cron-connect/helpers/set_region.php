<?php

namespace Nielsen\Smart_Recruiters_Cron;


function set_region( $region ) {
    if ($region === "Africa and the Middle East") {
      $region = "Africa and Middle East";
    } else if ( $region === "South East Asia, North Asia and Pacific" ) {
      $region = "Asia Pacific";
    } else if ( $region === "us" || $region === "ca" ) {
      $region = "North America";
    }
    return $region;
}
