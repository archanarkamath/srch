<?php
/* -----------------------------------
 * From smart recuriters API, returns 1st valueLabel
 * 
 * @param string    $label      The valueLabel to search and return
 * @param array     $array      The array object from smart recuriters API to search through
 * 
 * @return string|bool          false if can't find in array
 * ----------------------------------- */

 namespace Nielsen\Smart_Recruiters_Cron;

 function get_value_label( $label, $array ){
    foreach( $array as $item ){
        if( $item->fieldLabel === $label ){
            $value = $item->valueLabel;
        }
    }
    if( isset( $value )){
        return $value;
    } else {
        return false;
    }
 }