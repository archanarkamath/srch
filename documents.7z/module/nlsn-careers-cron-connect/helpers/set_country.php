<?php 

namespace Nielsen\Smart_Recruiters_Cron;



function set_country( $country ) {
    if ($country === "Russian Federation") {
      $country = "Russia";
    } else if ($country === "Viet Nam") {
      $country = "Vietnam";
    }
    return $country;
}
