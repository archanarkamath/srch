<?php 

namespace Nielsen\Smart_Recruiters_Cron;


function set_post_date( $job_date ){
    return gmdate( 'Y-m-d H:i:s', strtotime( $job_date ) );
}

