<?php 

namespace Nielsen\Smart_Recruiters_Cron;

function set_job_team( $team ) {
    $team = preg_replace( '/ and /', ' & ', $team );
    return $team;
}
