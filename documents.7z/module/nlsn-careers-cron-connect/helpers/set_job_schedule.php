<?php 

namespace Nielsen\Smart_Recruiters_Cron;



function set_job_schedule( $schedule ) {
    switch ( $schedule ) {
        case "Part-Time":
        case "Em part time":
            $schedule = "Part-Time";
            break;
        case "Full-Time":
        case "A tempo inteiro":
        default:
            $schedule = "Full-Time";
            break;
    }
    return $schedule;
}
