<?php

namespace Nielsen\Smart_Recruiters_Cron;


function set_location( $job_region, $job_country, $job_state, $job_city ) {

	$new_location = array();

	if ( ! empty( $job_region ) ) {
		$region_term = wpcom_vip_term_exists( $job_region, 'job_locations', 0 );

		// Create region if it doesn't exist
		if ( ! $region_term ) {
			$region_term = wp_insert_term( sanitize_text_field( $job_region ), 'job_locations' );
			if ( is_wp_error( $region_term ) ) {
				nlsn_careers_check_error( $region_term );
			}
		}
		$new_location[] = sanitize_text_field( $job_region );

		// for sub region, use state in United States, country elsewhere 
		if ( $job_country === "United States" ){
			$job_subregion = $job_state . " - " . $job_city;
		} else if ( $job_region === "India" ){
			$job_subregion = $job_city;
		} else {
			$job_subregion = $job_country;
		}

		// $job_subregion needs $job_region as parent, hence the nested nature here
		if ( ! empty( $job_subregion ) ) {
			// Check if the subregion exists
			$subregion_term = wpcom_vip_term_exists( sanitize_text_field( $job_subregion ), 'job_locations', $region_term['term_taxonomy_id'] );

			// Create subregion if it doesn't exist
			if ( ! $subregion_term ) {
				$subregion_term = wp_insert_term( sanitize_text_field( $job_subregion ), 'job_locations', array(
					'parent' => $region_term['term_taxonomy_id'],
				) );
				if ( is_wp_error( $subregion_term ) ) {
					nlsn_careers_check_error( $subregion_term );
				}
			}
			$new_location[] = sanitize_text_field( $job_subregion );
		}
	}
	return $new_location;
}
