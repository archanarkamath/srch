<?php 

namespace Nielsen\Smart_Recruiters_Cron;



function set_market( $region, $country ) {
    // add global to all
    $market = ['global'];

    if ( $country === "us") {
        $market[] = 'us';
    } else if ( $country === "ca" ) {
        $market[] = 'ca';
    } else if ( $country === "in" ) {
        $market[] = 'in';
    } else if ( $region === "Latin America") {
        $market[] = 'latam';
    } else if ( $region === "Europe") {
        $market[] = 'eu';
    } else if ( $region === "Africa and the Middle East") {
        $market[] = 'mena';
    } else if ( $region === "China") {
        $market[] = 'cn';
    }
    return $market;
}
