<?php
/*
Plugin Name: Nielsen Careers Connect Cron
Description: Cron function to create/update job openings 
Version: 2.0
*/

namespace Nielsen\Smart_Recruiters_Cron;

require_once __DIR__ . '/cron-function.php';
require_once __DIR__ . '/helpers/convert_state.php';
require_once __DIR__ . '/helpers/convert_country.php';
require_once __DIR__ . '/helpers/get_value_label.php';
require_once __DIR__ . '/helpers/set_city.php';
require_once __DIR__ . '/helpers/set_country.php';
require_once __DIR__ . '/helpers/set_job_schedule.php';
require_once __DIR__ . '/helpers/set_job_team.php';
require_once __DIR__ . '/helpers/set_market.php';
require_once __DIR__ . '/helpers/set_post_date.php';
require_once __DIR__ . '/helpers/set_location.php';


function nlsn_smart_recruiters_deactivate() {
    wp_clear_scheduled_hook( 'nlsn_smart_recruiters_action' );
}
 
add_action('init', function() {
    add_action( 'nlsn_smart_recruiters_action', 'Nielsen\Smart_Recruiters_Cron\nlsn_smart_recruiters_check', 9 );

    register_deactivation_hook( __FILE__, 'nlsn_smart_recruiters_deactivate' );
 
    if (! wp_next_scheduled ( 'nlsn_smart_recruiters_action' )) {
        wp_schedule_event( time(), 'hourly', 'nlsn_smart_recruiters_action' );
    }
});