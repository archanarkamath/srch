<?php

namespace Nielsen\Smart_Recruiters_Cron;


function nlsn_careers_check_error( $careers_cron_error_message ) {
	//used to catch and log any errors from the cron job
	// phpcs:disable
	if ( extension_loaded( 'newrelic' ) ) {
		newrelic_notice_error( print_r( $careers_cron_error_message, true ) );
	} else {
		error_log( print_r( $careers_cron_error_message, true ), 0 );
	}
	// phpcs:enable
}

function nlsn_smart_recruiters_check() {

	// set user because nlsn internationalization plugin requires permissions
	wp_set_current_user( null, 'nlsncronbot' );

	// grab current posts 
	$count = 1;
	$post_meta_ids = array();
	do {
		$query_posts = get_posts( array(
			'posts_per_page'   => 100,
			'post_type'        => 'career_job',
			'paged'            => $count,
			'suppress_filters' => false,
		));
		foreach ( $query_posts as $job_post ) {
			$post_meta_id = get_field( 'job_post_id', $job_post );
			// push value to custom-post-type array for comparison
			array_push( $post_meta_ids, $post_meta_id );
		}
		$count++;
		sleep( 2 ); // Take a breather.
	} while ( count( $query_posts ) );

	// get basic data from Smart Recruiters 
	$feed_url = 'https://api.smartrecruiters.com/v1/companies/TheNielsenCompany/postings';
	$get_data = wpcom_vip_file_get_contents( esc_url_raw( $feed_url ), 3 );
	if ( $get_data === false ) {
		nlsn_careers_check_error( $get_data );
		return false;
	}
	$job_feed = json_decode( $get_data );

	// figure out how many times to run API call, then build array of jobs
	$iterations = ceil( $job_feed->totalFound / 100 );
	$job_list = [];
	do {
		$iterations--;
		// build new feed url using iterations var to set offset
		$get_data = wpcom_vip_file_get_contents( esc_url_raw( $feed_url . "?limit=100&offset=" . 100 * $iterations ), 3 );
		if ( $get_data === false ) {
			nlsn_careers_check_error( $get_data );
			return false;
		}
		$job_feed = json_decode( $get_data );
		$job_list = array_merge( $job_list, $job_feed->content );
		sleep( 2 ); // Take a breather.
	} while ( $iterations > 0 );

	// post ids to check if duplicate 
	$data_post_ids = array();

	// foreach, get needed values for post creation
	foreach ( $job_list as $key => $job ) {

		// make additonal API call to get job details 
		$get_data_job = wpcom_vip_file_get_contents( esc_url_raw( $feed_url . "/" . (string) $job->id ), 3 );
		if ( $get_data_job === false ) {
			nlsn_careers_check_error( $get_data_job );
			return false;
		}
		$job_data = json_decode( $get_data_job );

		// check to see if data exists
		if ( ! isset( $job->customField ) ){
			nlsn_careers_check_error( "No custom fields on " . (string) $job->name );
		} else if ( ! isset( $job_data->jobAd ) ){
			nlsn_careers_check_error( "No Job Ad details on " . (string) $job->name );
		}
		

		$data_post_id       = (string) $job->id;
		$job_req_number     = (string) $job->refNumber; // is this neeeded?

		$post_date          = set_post_date( (string) $job->releasedDate );

		$job_region         = set_country( convert_country( $job->location->country, true ) );
		$job_country        = set_country( convert_country( $job->location->country, false, true ) );
		$job_state          = "";

		// fix the state if the country is the us
		if ( isset( $job->location->region ) ){
			if ( strtolower( $job->location->country ) === "us" && strlen( $job->location->region ) > 2 ){
				$job_state = convert_state( $job->location->region );
			} else {
				$job_state = $job->location->region;
			}
		}

		$job_city           = set_city( isset( $job->location->city ) ? $job->location->city : "" );
		
		$job_remote         = isset( $job->location->remote ) ? $job->location->remote : "";

		$job_title          = (string) $job->name;
		$job_url            = (string) $job_data->postingUrl;
		$job_jobtype        = (string) $job_data->experienceLevel->label;
		$job_team           = set_job_team( (string) get_value_label( "Career Site Team", $job->customField ) );
		$job_shift          = set_job_schedule( (string) $job->typeOfEmployment->label );
		$market             = set_market( $job_region, (string) $job->location->country );
		$language           = 'en';
		$job_description    = "<p><strong>" . (string) $job_data->jobAd->sections->jobDescription->title . "</strong></p><p>" .(string) $job_data->jobAd->sections->jobDescription->text . "</p>";
		$job_qualifications = "<p><strong>" . (string) $job_data->jobAd->sections->qualifications->title . "</strong></p><p>" . (string) $job_data->jobAd->sections->qualifications->text . "</p>";
		
		$post_content = '<p>' . $job_region . " / " . $job_country . " / " . $job_state . " / " . $job_city   . " / " . $job_remote . '</p><p>' . $job_team . '</p><p>#: ' . $data_post_id . ' / ' . $job_req_number . '</p><p>' . $job_jobtype . '</p><p>' . $job_shift . '</p>' . $job_description  . $job_qualifications . '<p>' . $job_url . '</p>';

		array_push( $data_post_ids, $data_post_id );
		// check if post id exists in our custom-post-type array. create new post if it doesn't
		if ( ! in_array( $data_post_id, $post_meta_ids, true ) ) {
			// Check if the region exists
			$new_location = set_location( $job_region, $job_country, $job_state, $job_city );

			// our new post
			$new_post = array(
				'post_date'    => $post_date,
				'post_content' => $post_content,
				'post_title'   => $job_title,
				'post_status'  => 'publish',
				'post_type'    => 'career_job',
				'meta_input'   => array(
					'job_post_id'       => $data_post_id,
					'job_req_number'    => $job_req_number,
					'job_post_url'      => $job_url,
					'job_region'        => $job_region,
					'job_subregion'     => $job_state,
				),
			);
			$post_id  = wp_insert_post( $new_post );

			// add corresponding taxonomy terms
			if ( ! is_wp_error( $post_id, true ) ) {

				$term_taxonomy_business = wp_set_object_terms( $post_id, 'connect', 'business' );
				if ( is_wp_error( $term_taxonomy_business ) ) {
					nlsn_careers_check_error( $term_taxonomy_business );
				}

				$term_taxonomy_market = wp_set_object_terms( $post_id, $market, 'markets' );
				if ( is_wp_error( $term_taxonomy_market ) ) {
					nlsn_careers_check_error( $term_taxonomy_market );
				}

				$term_taxonomy_language = wp_set_object_terms( $post_id, $language, 'languages' );
				if ( is_wp_error( $term_taxonomy_language ) ) {
					nlsn_careers_check_error( $term_taxonomy_language );
				}

				$term_taxonomy_team = wp_set_object_terms( $post_id, $job_team, 'job_teams' );
				if ( is_wp_error( $term_taxonomy_team ) ) {
					nlsn_careers_check_error( $term_taxonomy_team );
				}

				$term_taxonomy_location = wp_set_object_terms( $post_id, $new_location, 'job_locations' );
				if ( is_wp_error( $term_taxonomy_location ) ) {
					nlsn_careers_check_error( $term_taxonomy_location );
				}

				$term_taxonomy_type = wp_set_object_terms( $post_id, $job_jobtype, 'job_types' );
				if ( is_wp_error( $term_taxonomy_type ) ) {
					nlsn_careers_check_error( $term_taxonomy_type );
				}
				$term_taxonomy_schedule = wp_set_object_terms( $post_id, $job_shift, 'job_schedules' );
				if ( is_wp_error( $term_taxonomy_schedule ) ) {
					nlsn_careers_check_error( $term_taxonomy_schedule );
				}
			} else {
				nlsn_careers_check_error( $data_post_id );
			}
		} else {
			// update existing post
			$new_location = set_location( $job_region, $job_country, $job_state, $job_city );

			// get the latest existing post with this data_post_id, if any.
			$existing_args  = array(
				'post_status'      => 'publish',
				'post_type'        => 'career_job',
				'meta_key'         => 'job_post_id',
				'meta_value'       => $data_post_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'posts_per_page'   => 1,
				'suppress_filters' => false,
			);
			$existing_posts = get_posts( $existing_args );

			// foreach, update the post. Will only update info if one of the values in the arguments below have changed
			foreach ( $existing_posts as $post_to_update ) {
				$query   = array(
					'ID'           => $post_to_update->ID,
					'post_date'    => $post_date,
					'post_content' => $post_content,
					'post_title'   => $job_title,
				);
				$post_id = wp_update_post( $query, true );
				if ( ! is_wp_error( $post_id ) ) {
					// update corresponding taxonomy terms
					$term_taxonomy_team = wp_set_object_terms( $post_id, $job_team, 'job_teams' );
					if ( is_wp_error( $term_taxonomy_team ) ) {
						nlsn_careers_check_error( $term_taxonomy_team );
					}

					$term_taxonomy_location = wp_set_object_terms( $post_id, $new_location, 'job_locations' );
					if ( is_wp_error( $term_taxonomy_location ) ) {
						nlsn_careers_check_error( $term_taxonomy_location );
					}

					$term_taxonomy_type = wp_set_object_terms( $post_id, $job_jobtype, 'job_types' );
					if ( is_wp_error( $term_taxonomy_type ) ) {
						nlsn_careers_check_error( $term_taxonomy_type );
					}

					$term_taxonomy_schedule = wp_set_object_terms( $post_id, $job_shift, 'job_schedules' );
					if ( is_wp_error( $term_taxonomy_schedule ) ) {
						nlsn_careers_check_error( $term_taxonomy_schedule );
					}

					// might want to add a primary market / language? 
					update_post_meta( $post_to_update->ID, 'job_req_number', $job_req_number );
					update_post_meta( $post_to_update->ID, 'job_post_url', esc_url_raw( $job_url ) );
					update_post_meta( $post_to_update->ID, 'job_region', $job_region );
					update_post_meta( $post_to_update->ID, 'job_subregion', $job_state );
				} else {
					nlsn_careers_check_error( $data_post_id );
				}
			}
		}

		// get existing posts, except the latest one, with this data_post_id, if any.
		$duplicate_args  = array(
			'post_status'      => 'publish',
			'post_type'        => 'career_job',
			'meta_key'         => 'job_post_id',
			'meta_value'       => $data_post_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			'posts_per_page'   => 10,
			'offset'           => 1,
			'suppress_filters' => false,
		);
		$duplicate_posts = get_posts( $duplicate_args );

		// foreach duplicate, change status to trash
		foreach ( $duplicate_posts as $post_to_archive ) {
			$query = array(
				'ID'          => $post_to_archive->ID,
				'post_status' => 'trash',
			);
			wp_update_post( $query, true );
		}
	}

	foreach ( $post_meta_ids as $key ) {
		$this_meta_id = $key;
		if ( ! in_array( $this_meta_id, $data_post_ids, true ) ) {
			// get all existing posts with this post meta_value, if any.
			$meta_args  = array(
				'post_status'      => 'publish',
				'post_type'        => 'career_job',
				'meta_key'         => 'job_post_id',
				'meta_value'       => $this_meta_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'posts_per_page'   => 10,
				'suppress_filters' => false,
				'tax_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
					array(
						'taxonomy' => 'business',
						'field'    => 'slug',
						'terms'    => 'connect'
					)
				)
			);
			$meta_posts = get_posts( $meta_args );

			// foreach, change status to pending since these are not available in the json data anymore
			foreach ( $meta_posts as $post_to_archive ) {
				$query = array(
					'ID'          => $post_to_archive->ID,
					'post_status' => 'trash',
				);
				wp_update_post( $query, true );
			}
		}
	}
}