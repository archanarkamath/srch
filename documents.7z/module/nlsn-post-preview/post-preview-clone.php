<?php
/**
 * This file contains logic related to cloning posts and
 * is a modified version of the Post Internationalization
 * plugin and copying terms instead of changing them.
 *
 * @package Nielsen\Plugins\Post_Preview
 */

/* TODO:
Find out which code calls clone_post, add_market_to_post,
add_all_available_markets_to_post, remove_market_from_post,
set_parent_post_relationship, and delete_clone_relationship
*/

// Make sure user data is available to all functions
global $user;
$user = wp_get_current_user();

/**
 * Clone a specific post.
 *
 * @param int $post_id        The post to clone.
 * @return int $clone_id The cloned post ID.
 */
function clone_post( $data ) { // Original passed $market and $language

  // Validate input.
  if ( empty( $data['id'] ) ) {
    return [];
  }

  // Store the ID and the status ('draft', 'publish') if it exists
  $post_id = (int) $data['id'];
  $status = get_post_status( $post_id );

  // If post doesn't exist, quit
  if ( FALSE === $status ) {
    return [];
  }

  $clone_id       = 0;
  $post           = get_post( $post_id );
  $parent_post_id = $post_id;

  /**
   * Can this post be cloned?
   *
   * @param WP_Post $post The current post object.
   */
  if ( ! apply_filters( 'nlsn_post_preview_clone_validate_post', true, $post ) ) {
    return new \WP_Error( 'broke', __( 'You are not allowed to clone posts of this type. Please contact your administrator for more information.', 'nielsen-base' ) );
  }

  // Non-admin users were getting this warning causing Fetch requests to fail
  // If they are not defined, set to an empty value here
  if (!defined('EDIT_FORM_FIELD_NAME')) {
    define('EDIT_FORM_FIELD_NAME', '');
  }

  if (!defined('META_KEY_INDEPENDENT_ARTICLES')) {
    define('META_KEY_INDEPENDENT_ARTICLES', '');
  }

  if (!defined('META_KEY_MAIN_ARTICLE')) {
    define('META_KEY_MAIN_ARTICLE', '');
  }

  /* This was causing issues with sync, so comment out for now
  // Ensure this post is not a child post.
  $main_article_id = get_post_meta( $post_id, META_KEY_MAIN_ARTICLE, true );
  if ( ! empty( $main_article_id ) ) {
    $parent_post_id = $main_article_id;
  }
  */

  if ( ! empty( $post_id ) && $post instanceof \WP_Post ) {

    // Set default post status to shareable draft for
    // Admin, Authors, and Editors, but if a Contributor,
    // set to the private version to require a login
    $post_status = 'shareable-draft';

    $clone_id = wp_insert_post(
      [
        'comment_status' => $post->comment_status,
        'ping_status'    => $post->ping_status,
        'post_author'    => $post->post_author,
        'post_content'   => $post->post_content,
        'post_excerpt'   => $post->post_excerpt,
        'post_parent'    => $parent_post_id,
        'post_password'  => $post->post_password,
        'post_title'     => $post->post_title,
        'post_type'      => $post->post_type,
        'post_status'    => $post_status,
      ]
    );

    // Add all custom fields.
    if ( $clone_id ) {
      $custom_fields = get_post_custom( $post_id );

      /**
       * Filters the meta keys that should be ignored.
       *
       * @param array The meta keyes to be ignored.
       */
      $ignored_meta = apply_filters(
        'nlsn_post_plugin_clone_ignored_meta',
        [
          // Our relation fields.
          META_KEY_MAIN_ARTICLE,
          META_KEY_INDEPENDENT_ARTICLES,
          EDIT_FORM_FIELD_NAME,
          // WordPress hidden fields.
          '_edit_lock',
          '_edit_last',
          '_wp_old_slug',
          '_wp_trash_meta_time',
          '_wp_trash_meta_status',
          '_previous_revision',
          '_wpas_done_all',
          '_encloseme',
        ]
      );

      foreach ( $custom_fields as $meta_key => $custom_field ) {
        // Skip ignored meta.
        if ( in_array( $meta_key, $ignored_meta, true ) ) {
          continue;
        }

        foreach ( $custom_field as $meta_value ) {
          /**
           * Allow other plugins to determine if this meta data
           * should be added to this post.
           *
           * @param int    $clone_id   The cloned post ID.
           * @param string $meta_key   The meta key.
           * @param mixed  $meta_value The meta value.
           */
          if ( apply_filters( 'nlsn_post_preview_clone_posts_add_post_meta', true, $clone_id, $meta_key, $meta_value ) ) {
            add_post_meta( $clone_id, $meta_key, maybe_unserialize( $meta_value ) );
          }
        }
      }
    }

    // Add the terms.
    $taxonomies = get_post_taxonomies( $post_id );
    $taxonomies = array_diff(
      $taxonomies,
      [
        'markets',
        'languages',
      ]
    );

    foreach ( $taxonomies as $taxonomy ) {
      $terms = get_the_terms( $post_id, $taxonomy );
      if ( ! empty( $terms ) ) {
        /**
         * Allow other plugins to determine if these terms should
         * be added to the cloned post.
         *
         * @param int    $clone_id The cloned post ID.
         * @param string $taxonomy The term taxonomy.
         * @param array  $terms    The terms.
         * @param int    $post_id  The source post ID.
         */
        if ( apply_filters( 'nlsn_post_preview_clone_posts_add_post_terms', true, $clone_id, $taxonomy, $terms, $post_id ) ) {
          wp_set_object_terms( $clone_id, wp_list_pluck( $terms, 'term_id' ), $taxonomy );
        }
      }
    }

    // Set the relationship.
    set_parent_post_relationship( $clone_id, $parent_post_id );

  }

  // Unable to clone the post.
  if ( 0 === $clone_id ) {
    return new \WP_Error( 'broke', __( 'Unable to clone the post:', 'nielsen-base' ) . ' ' . $post->post_title );
  }

  $output = [
    'expires'        => strtotime('+72 hours'),
    'parentId'       => $post_id,
    'previewId'      => $clone_id,
    'previewUrl'     => get_preview_link(get_post($clone_id)),
    'status'         => get_post_status($clone_id)
  ];

  return $output;

}

// 'clone_post' looks good as of 11:21 on 09/17!
// Removed 'add_market_to_post' function

/**
 * Add all available markets to a given post.
 *
 * @param int $post_id Post ID.
 * @return int|\WP_Error
 */
function add_all_available_markets_to_post( int $post_id ) {
  $primary_market = get_primary_market( $post_id );
  $language       = get_object_language( $post_id );

  if (
    ! $primary_market instanceof \WP_Term ||
    ! $language instanceof \WP_Term ||
    ! current_user_can_access( $primary_market->term_id, $language->term_id )
  ) {
    return new \WP_Error(
      'broke',
      sprintf(
        /* translators: 1: Market name, 2: Post title */
        __( 'You do not have permission to add the %1$s market to %2$s', 'nielsen-base' ),
        $primary_market->name,
        get_the_title( $post_id )
      )
    );
  }

  $available = get_remaining_markets_for_post( $post_id, 'add_market' );

  if ( empty( $available ) ) {
    return new \WP_Error( 'no-available-markets', __( 'There are no remaining markets to add.', 'nielsen-base' ) );
  }

  $available = wp_list_pluck( $available, 'id' );

  wp_set_object_terms( $post_id, $available, TAXONOMY_MARKETS, true );

  return $post_id;
}

// 'add_all_available_markets_to_post' looks good as of 11:36 on 09/17!
// Removed 'remove_market_from_post' function

/**
 * Set a parent child relationship.
 *
 * @param int $child_id  The child post.
 * @param int $parent_id The parent post.
 */
function set_parent_post_relationship( $child_id, $parent_id ) {
  // Set main post.
  update_post_meta( $child_id, META_KEY_MAIN_ARTICLE, $parent_id );

  // Add this post to the main post's cloned ids.
  $cloned_posts = get_post_meta( $parent_id, META_KEY_INDEPENDENT_ARTICLES, true );
  if ( empty( $cloned_posts ) ) {
    $cloned_posts = [];
  }

  // Add post.
  $cloned_posts[] = $child_id;

  update_post_meta( $parent_id, META_KEY_INDEPENDENT_ARTICLES, $cloned_posts );
}

// 'set_parent_post_relationship' looks good as of 11:41 on 09/17!

/**
 * When a post is deleted, be sure to delete the clone relationship.
 *
 * @param int $post_id The post ID.
 */
function delete_clone_relationship( $post_id ) {
  $main_article_id = get_post_meta( $post_id, META_KEY_MAIN_ARTICLE, true );
  $cloned_ids      = get_post_meta( $post_id, META_KEY_INDEPENDENT_ARTICLES, true );

  // Cloned post.
  if ( ! empty( $main_article_id ) ) {
    // Remove this post to the main post's cloned ids.
    $cloned_posts = get_post_meta( $main_article_id, META_KEY_INDEPENDENT_ARTICLES, true );

    // Do nothing if there are no cloned posts found.
    if ( empty( $cloned_posts ) ) {
      return;
    }

    // Remove post.
    $index = array_search( $post_id, $cloned_posts, true );
    if ( false !== $index ) {
      unset( $cloned_posts[ $index ] );
      $cloned_posts = array_values( $cloned_posts );
    }

    if ( empty( $cloned_posts ) ) {
      delete_post_meta( $main_article_id, META_KEY_INDEPENDENT_ARTICLES );
    } else {
      update_post_meta( $main_article_id, META_KEY_INDEPENDENT_ARTICLES, $cloned_posts );
    }
  } elseif ( ! empty( $cloned_ids ) ) {
    foreach ( $cloned_ids as $cloned_id ) {
      delete_post_meta( $cloned_id, META_KEY_MAIN_ARTICLE );
    }
  }
}

// 'set_parent_post_relationship' looks good as of 11:45 on 09/17!

/* Start migration of the preview link code from Public Post Preview plugin */

	/**
	 * Returns the public preview link.
	 *
	 * The link is the home link with these parameters:
	 *  - preview, always true (query var for core)
	 *  - page_id or p or p and post_type to specify the post.
	 *
	 * @since 2.0.0
	 *
	 * @param WP_Post $post The post object.
	 * @return string The generated public preview link.
	 */
	function get_preview_link( $post ) {
		if ( 'page' === $post->post_type ) {
			$args = array(
				'page_id' => $post->ID,
				'p' => $post->ID,
				'post_type' => $post->post_type,
			);
		} elseif ( 'post' === $post->post_type ) {
			$args = array(
				'p' => $post->ID,
			);
		} else {
			$args = array(
				'p'         => $post->ID,
				'post_type' => $post->post_type,
			);
		}

		$args['preview'] = true;
		$link = add_query_arg( $args, home_url( '/' ) );

		return apply_filters( 'ppp_preview_link', $link, $post->ID, $post );
	}


add_action( 'before_delete_post', __NAMESPACE__ . '\delete_clone_relationship' );
