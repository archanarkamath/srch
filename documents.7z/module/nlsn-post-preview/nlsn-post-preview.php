<?php
/*
Plugin Name: Nielsen Post Preview
Description: Allow shareable preview links for drafts and published posts.
Plugin URI: http://www.nielsen.com
Version: 1.0.0
Author: Nielsen Dev Team
Author URI: http://www.nielsen.com/
*/

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

// Add these files after initialization so user info is available
add_action( 'init', function() {
  require_once( plugin_dir_path( __FILE__ ) . 'class-post-preview-check.php' );
  require_once( plugin_dir_path( __FILE__ ) . 'post-preview-clone.php' );
  require_once( plugin_dir_path( __FILE__ ) . 'class-post-preview-block.php' );
} );

// Cron job to remove expired 'shareable-draft' posts
require_once( plugin_dir_path( __FILE__ ) . 'class-post-preview-cron.php' );

/**
 * Customize Admin Bar Menu
 *
 * For the Shareable posts disable admin bar items.
 * Add new menu option to move posts to trash from the front-end.
 */
add_action( 'admin_bar_menu', function () {

  global $wp_admin_bar;
  // Comment out below condition check, so non admins can delete shareable links
  // if ( ! is_super_admin() || ! is_admin_bar_showing() ) {
  //   return;
  // }

  $current_object = get_queried_object();
  if ( empty( $current_object ) ) {
    return;
  }

  // Check if it's a shareable post
  if ( 'shareable-draft' === get_post_status() ) {

    // Add Delete button
    $wp_admin_bar->add_menu(
      array( 'id' => 'delete-shareable',
             'title' => __( 'Delete Shareable Post' ),
             'href' => get_delete_post_link( $current_object->term_id )
      )
    );

    // Remove most menu items since we don't want these to display in shareable posts
    $wp_admin_bar->remove_node( 'customize' );
    $wp_admin_bar->remove_node( 'updates' );
    $wp_admin_bar->remove_node( 'comments' );
    $wp_admin_bar->remove_node( 'new-content' );
    $wp_admin_bar->remove_node( 'edit' );
    $wp_admin_bar->remove_node( 'nlsn-localize' );
  }
}, 999 );

/*
 * CSS Assets
 */
add_action( 'wp_enqueue_scripts', function () {

  if ( 'shareable-draft' === get_post_status() ) {
    wp_enqueue_style(
      'post-preview',
      plugin_dir_url( __FILE__ ) . 'post-preview-styles.css',
      false,
      filemtime( plugin_dir_path( __FILE__ ) . 'post-preview-styles.css' )
    );
  }
} );

// http://vip.nielsen.com/wp-json/nlsn/v1/post-preview/clonepost
add_action( 'rest_api_init' , function() {

  // Allow cloning of current post
  register_rest_route( 'nlsn/v1', '/post-preview/clonepost', array(
    'methods' => 'POST',
    'callback' => 'clone_post',
    'args' => array(
      'id' => array(
        'validate_callback' => function($param, $request, $key) {
          return is_numeric($param);
        }
      ),
    ),
  ));

  // Grab latest non-expired preview of current post
  register_rest_route( 'nlsn/v1', '/post-preview/latestpreview', array(

    'methods' => 'POST',
    'callback' => function($data) {

      // Validate input
      if (empty( $data['id'])) {
        return [];
      }

      // Store the ID and run a query
      $post_id = (int) $data['id'];
      $query = new WP_Query(array(
        'date_query' => array(array(
          'after' => '72 hours ago',
        )),
        'order'          => 'DESC',
        'orderby'        => 'ID',
        'post_parent'    => $post_id,
        'post_status'    => 'shareable-draft',
        'post_type'      => 'any',
        'posts_per_page' => 1,
      ));

      // Loop through values if they exist
      $previews = array();
      if ($query->have_posts()) {
        while ($query->have_posts()) : $query->the_post();
          $post_date = strtotime(get_the_date());
          $preview_id = (int) get_the_ID();
          $previews[] = array(
            'created'    => $post_date,
            'expires'    => $post_date + 72*60*60,
            'parentId'   => $post_id,
            'previewId'  => $preview_id,
            'previewUrl' => get_preview_link(get_post($preview_id)),
          );
        endwhile;
      }

      return [
        'previews' => $previews,
      ];

    },
    'args' => array(
      'id' => array(
        'validate_callback' => function($param, $request, $key) {
          return is_numeric($param);
        }
      ),
    ),
  ));
});
