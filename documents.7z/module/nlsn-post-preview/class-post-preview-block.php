<?php

class NLSN_Post_Preview_Block {

  static function init() {

    $current_page = '';
    if (isset($_SERVER['PHP_SELF'])) {
      $current_page = sanitize_text_field($_SERVER['PHP_SELF']);
    };

    // Load the minified version of the application. This will require
    // running "yarn build" inside the plugin directory prior to deployment
    wp_register_script(
      'nlsn-post-preview-js',
      plugin_dir_url(__FILE__) .'dist/app.js',
      [
        'wp-element',
        'wp-i18n',
        'wp-blocks',
        'wp-components',
        'wp-data',
        'wp-editor'
      ],
      filemtime( plugin_dir_path( __FILE__ ) . 'dist/app.js' ),
      true
    );

    // Only load this block while in Edit Post area to add to post sidebar
    function load_editor_block() {
      register_block_type(
        'nlsn/post-preview', [
          'editor_script' => 'nlsn-post-preview-js',
        ]
      );
    }

    // Limit this script to these pages
    $check_pages = array('/wp-admin/post.php', '/wp-admin/post-new.php');
    if (in_array($current_page, $check_pages, true) && is_admin()) {
      load_editor_block();
    }

  }

}

// Initialize JavaScript in admin areas
// 'load-post.php' makes it available on edit and not new
// while 'admin_init' is on all
add_action('admin_init', array('NLSN_Post_Preview_Block', 'init'));
