jQuery( document ).ready( function( $ ) {
    // $() will work as an alias for jQuery() inside of this function
    $("#loginform").hide();
} );
