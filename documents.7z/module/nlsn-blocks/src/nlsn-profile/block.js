/**
 * BLOCK: Profile
 */

 // Block dependencies
import classnames from 'classnames';
import defineClassNames from '../utilities/defineClasses';
import Inspector from './inspector';
import attributes from './attributes';
import icon from './icon';

// Import all of our Container Options requirements.
import ContainerOptions, {
	ContainerOptionsAttributes,
	HideSectionEdit,
	HideSectionSave,
	BlockIdEdit,
} from '../components/container-options';

import { gallery, cancelCircleFilled } from '@wordpress/icons';

// Components
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks

// Register editor components
const {
	MediaUpload,
	RichText,
	InspectorControls,
	BlockControls,
	AlignmentToolbar,
} = wp.blockEditor;

const {
	Button,
} = wp.components;


const blockClasses = classnames(
	`profile`,
);

// Register: Editor with Image
registerBlockType( 'nlsn-blocks/nlsn-profile', {
	title: __( 'Profile - NLSN', 'nlsn-blocks' ),
	description: __( 'Add text content with an image.', 'nlsn-blocks' ),
	icon: icon,
	category: 'nielsen-blocks',
	keywords: [
		__( 'editor', 'nlsn-blocks' ),
		__( 'image', 'nlsn-blocks' ),
		__( 'nielsen', 'nlsn-blocks' ),
	],
	attributes: {
		...attributes,
		...ContainerOptionsAttributes,
	},

	/**
	 * Determines what is displayed in the editor.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 */
	edit: props => {
		const { attributes: {
			imgSize,
			imageAlignment,
			imgID,
			imgURL,
			imgAlt,
			contentEditor,
			contentEditorTitle,
			containerSettings,
			align,
		},
			isSelected,
			className,
			setAttributes,
		} = props;

		const classes = defineClassNames( props, 'profile' );

		const onSelectImage = img => {
      setAttributes( {
        imgID: img.id,
        imgURL: img.url,
        imgAlt: img.alt,
      } );
    };
    const onRemoveImage = () => {
      setAttributes({
        imgID: null,
        imgURL: null,
        imgAlt: null,
      });
    }

		let imagePaddingClasses = '';
		if ( imageAlignment === 'left' ) {
			imagePaddingClasses = 'pr-md-3';
		} else if ( imageAlignment === 'right' ) {
			imagePaddingClasses = 'pl-md-3';
		}

		// Return the markup displayed in the editor.
		return (

			<div key="editor-display" className={ className }>
				{ isSelected &&
					<InspectorControls>
						<ContainerOptions
							{ ...props }
						/>
						<Inspector
							{ ...props }
						/>
					</InspectorControls>
				}


				{ containerSettings &&
					<div className="container-settings">
						<BlockIdEdit
							{ ...props }
						/>
						<HideSectionEdit
							{ ...props }
						/>
					</div>
				}

				<div className={ classes.container } id={ classes.id }>
					<div className='container'>
						<div className='row justify-content-center'>
							<div className={ classes.width }>

								<div className={ blockClasses }>

									{
										imgURL ? (
											<div className={ classnames( imgSize, imagePaddingClasses, 'col pb-3 px-0 pb-md-1', `float-${imageAlignment}` ) } style={ { zIndex: '9' } }>
												<img
													className={classnames('content-thumbnail', 'img-fluid', 'd-block', 'mx-auto')}
													src={ imgURL }
													alt={ imgAlt }
												/>


												{ isSelected ? (
													<Button
														className='remove-image'
														onClick={ onRemoveImage }
														icon={ cancelCircleFilled }
													/>
												) : null }
											</div>

										) : (
											<div className={ classnames( imgSize, imagePaddingClasses, 'col pb-3 px-0 pb-md-1', `float-${imageAlignment}` ) } style={ { zIndex: '9' } }>
												<MediaUpload
													onSelect={ onSelectImage }
													value={ imgID }
													render={ ( { open } ) => (
														<Button onClick={ open } icon={ gallery } > Add/Upload Image </Button>
													) }
												>
												</MediaUpload>
											</div>
										)
									}

									<RichText
										tagName='h3'
										className={ classnames(
											'content-editor-title',
											classes.align,
										) }
										placeholder={ __( 'Add your title', 'nlsn-blocks' ) }
										value={ contentEditorTitle }
										onChange={ contentEditorTitle => { setAttributes( { contentEditorTitle } ) } }
									/>

									<RichText
										tagName='div'
										multiline='p'
										className={ classnames(
											'content-editor'
										) }
										placeholder={ __( 'Add your message', 'nlsn-blocks' ) }
										value={ contentEditor }
										onChange={ contentEditor => { setAttributes( { contentEditor } ) } }
									/>

								</div>

							</div>
						</div>
					</div>
				</div>
			</div>
		)
	},

	/**
	 * Determines what is displayed on the front-end.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 */
	save: props => {
		const {
			attributes: {
				imageAlignment,
				imgURL,
				imgSize,
				imgAlt,
				contentEditor,
				contentEditorTitle,
				align,
			},
			className,
		} = props;

		const classes = defineClassNames( props, 'profile', 'save' );

		let imagePaddingClasses = '';
		if ( imageAlignment === 'left' ) {
			imagePaddingClasses = 'pr-md-3';
		} else if ( imageAlignment === 'right' ) {
			imagePaddingClasses = 'pl-md-3';
		}

		// Return the markup displayed on the front-end.
		return (
			<div className = { className }>
				<div
					id={ classes.id }
					className={ classes.container }
				>
					<div className='container'>
						<div className='row justify-content-center'>
							<div className={ classes.width }>

								<div className={ blockClasses }>
									<div className={ classnames( imgSize, imagePaddingClasses, 'col pb-3 px-0 pb-md-1', `float-${imageAlignment}` ) }>
										{
											imgURL ? (
												<img
													className={classnames('content-thumbnail', 'img-fluid', 'd-block', 'mx-auto')}
													src={ imgURL }
													alt={ imgAlt }
												/>
											) : (
													null
											)
										}
									</div>

									{ ( contentEditorTitle && contentEditorTitle.length > 0 ) ? (
										<RichText.Content
											tagName='h3'
											className={ classnames(
												'content-editor-title',
												classes.align,
											) }
											value={ contentEditorTitle }
										/>
									) : null }

									<div className='content-editor'>
										{ contentEditor }
									</div>

								</div>

							</div>
						</div>
					</div>
				</div>
			</div>
		);
	},

	deprecated: [
		{
			attributes: {
				imageAlignment: {
					type: 'string',
					default: 'left',
				},
				imgID: {
					type: 'number',
				},
				imgURL: {
					type: 'string',
					source: 'attribute',
					attribute: 'src',
					selector: '.content-thumbnail',
				},
				imgAlt: {
					type: 'string',
					source: 'attribute',
					attribute: 'alt',
					selector: '.content-thumbnail',
				},
				imgSize: {
					type: 'string',
					default: 'col-md-3',
				},
				contentEditor: {
					type: 'array',
					source: 'children',
					selector: '.content-editor',
				},
				contentEditorTitle: {
					source: 'text',
					selector: '.content-editor-title',
				},
				align: {
					type: 'string',
				},
				...ContainerOptionsAttributes,
			},
			save: props => {
				const {
					attributes: {
						imageAlignment,
						imgURL,
						imgSize,
						imgAlt,
						contentEditor,
						contentEditorTitle,
						align,
					},
					className,
				} = props;

				const classes = defineClassNames( props, 'profile', 'save' );

				let imagePaddingClasses = '';
				if ( imageAlignment === 'left' ) {
					imagePaddingClasses = 'pr-md-3';
				} else if ( imageAlignment === 'right' ) {
					imagePaddingClasses = 'pl-md-3';
				}

				// Return the markup displayed on the front-end.
				return (
					<div className = { className }>
						<div
							id={ classes.id }
							className={ classes.container }
						>
							<div className='container'>
								<div className='row justify-content-center'>
									<div className={ classes.width }>

										<div className={ blockClasses }>
											<div className={ classnames( imgSize, imagePaddingClasses, 'col pb-3 px-0 pb-md-1', `float-${imageAlignment}` ) }>
												{
													imgURL ? (
														<img
															className={classnames('content-thumbnail', 'img-fluid', 'd-block', 'mx-auto')}
															src={ imgURL }
															alt={ imgAlt }
														/>
													) : (
														null
													)
												}
											</div>

											{ ( contentEditorTitle && contentEditorTitle.length > 0 ) ? (
												<div className='content-editor-title'>
													<h3 className={ classes.align }>
														{ contentEditorTitle }
													</h3>
												</div>
											) : null }

											{ ( contentEditor && contentEditor.length > 0 ) ? (
												<div className='content-editor'>
													{ contentEditor }
												</div>
											) : null }

										</div>

									</div>
								</div>
							</div>
						</div>
					</div>
				);
			},
		},
		{
			attributes: {
				imageAlignment: {
					type: 'string',
					default: 'left',
				},
				imgID: {
					type: 'number',
				},
				imgURL: {
					type: 'string',
					source: 'attribute',
					attribute: 'src',
					selector: '.content-thumbnail',
				},
				imgAlt: {
					type: 'string',
					source: 'attribute',
					attribute: 'alt',
					selector: '.content-thumbnail',
				},
				imgSize: {
					type: 'string',
					default: 'col-md-3',
				},
				contentEditor: {
					type: 'array',
					source: 'children',
					selector: '.content-editor',
				},
				contentEditorTitle: {
					source: 'text',
					selector: '.content-editor-title',
				},
				align: {
					type: 'string',
				},
				...ContainerOptionsAttributes,
			},
			save: props => {
				const {
					attributes: {
						imageAlignment,
						imgURL,
						imgSize,
						imgAlt,
						contentEditor,
						contentEditorTitle,
						align,
					},
					className,
				} = props;

				const classes = defineClassNames( props, 'profile', 'save' );

				let imagePaddingClasses = '';
				if ( imageAlignment === 'left' ) {
					imagePaddingClasses = 'pr-md-3';
				} else if ( imageAlignment === 'right' ) {
					imagePaddingClasses = 'pl-md-3';
				}

				// Return the markup displayed on the front-end.
				return (
					<div className = { className }>
						<div
							id={ classes.id }
							className={ classes.container }
						>
							<div className='container'>
								<div className='row justify-content-center'>
									<div className={ classes.width }>

										<div className={ blockClasses }>
											<div className={ classnames( imgSize, imagePaddingClasses, 'col pb-3 px-0 pb-md-1', `float-${imageAlignment}` ) }>
												{
													imgURL ? (
														<img
															className={classnames('content-thumbnail', 'img-fluid', 'd-block', 'mx-auto')}
															src={ imgURL }
															alt={ imgAlt }
														/>
													) : (
														null
													)
												}
											</div>

											<div className='content-editor-title'>
												<h3 className={ classes.align }>
													{ contentEditorTitle }
												</h3>
											</div>

											{ ( contentEditor && contentEditor.length > 0 ) ? (
												<div className='content-editor'>
													{ contentEditor }
												</div>
											) : null }

										</div>

									</div>
								</div>
							</div>
						</div>
					</div>
				);
			},
		},
	]
} );
