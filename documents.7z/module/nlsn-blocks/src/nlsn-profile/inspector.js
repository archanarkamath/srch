/**
 * Internal block libraries
 */
const { __ } = wp.i18n;
const { Component } = wp.element;

const {
  AlignmentToolbar,
} = wp.blockEditor;

const {
  PanelBody,
	PanelRow,
  SelectControl,
} = wp.components;

/**
 * Create an Inspector Controls wrapper Component
 */
export default class Inspector extends Component {

  constructor() {
    super( ...arguments );
  }

  render() {
    const { attributes: { imgSize, containerSettings, imageAlignment, align, newWindow, buttonColor, disableSection, sectionId }, setAttributes } = this.props;

    return (
			<PanelBody
				title={ __( 'Image Settings', 'nlsn-blocks' ) }
				initialOpen={ true }
			>
				<PanelRow>
					<SelectControl
						label={ __( 'Image Alignment', 'nlsn-blocks' ) }
						value={ imageAlignment }
						options={ [
							{ value: 'left', label: __( 'Left', 'nlsn-blocks' ) },
							{ value: 'right', label: __( 'Right', 'nlsn-blocks' ) },
						] }
						onChange={ imageAlignment => setAttributes( { imageAlignment } ) }
					/>
				</PanelRow>
        <PanelRow>
          <SelectControl
            label={ __( 'Image Size', 'nlsn-blocks' ) }
            value={ imgSize }
            options={ [
              { value: 'col-md-3', label: __( 'Small', 'nlsn-blocks' ) },
              { value: 'col-md-5', label: __( 'Medium', 'nlsn-blocks' ) },
              { value: 'col-md-6', label: __( 'Large', 'nlsn-blocks' ) },
            ] }
            onChange={ imgSize => setAttributes( { imgSize } ) }
          />
        </PanelRow>
        <p>{ __( 'Profile Heading Alignment' ) }</p>
        <AlignmentToolbar
          label={ __( 'Profile Heading Alignment', 'nlsn-blocks' ) }
          value={ align }
          onChange={ align => setAttributes( { align } ) }
        />
    </PanelBody>
    );
  }
}
