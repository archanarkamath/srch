const attributes = {
	imageAlignment: {
		type: 'string',
		default: 'left',
	},
	imgID: {
		type: 'number',
	},
	imgURL: {
		type: 'string',
		source: 'attribute',
		attribute: 'src',
		selector: '.content-thumbnail',
	},
	imgAlt: {
		type: 'string',
		source: 'attribute',
		attribute: 'alt',
		selector: '.content-thumbnail',
	},
	imgSize: {
		type: 'string',
		default: 'col-md-3',
	},
	contentEditor: {
    type: 'array',
		source: 'children',
		selector: '.content-editor',
  },
	contentEditorTitle: {
		type: 'string',
		source: 'html',
		selector: '.content-editor-title',
	},
	align: {
		type: 'string',
	},
};

export default attributes;
