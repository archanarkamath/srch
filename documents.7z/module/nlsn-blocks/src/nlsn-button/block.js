/**
 * BLOCK: Button Block
 */

// Block dependencies
import classnames from 'classnames';
import defineClassNames from '../utilities/defineClasses';
import Inspector from './inspector';
import attributes from './attributes';
import icon from './icon';

import { Icon, link, keyboardReturn } from '@wordpress/icons';

// Import all of our Container Options requirements.
import ContainerOptions, {
	ContainerOptionsAttributes,
	HideSectionEdit,
	HideSectionSave,
	BlockIdEdit,
	BlockIdSave,
	BackgroundOptionsClasses,
	BlockPaddingClasses,
	BlockWidthClasses,
} from '../components/container-options';

import { colors } from '../components/colors/colorUtils';

// Components
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks

// Register editor components
const {
	InspectorControls,
	RichText,
	URLInput,
	getColorObjectByColorValue,
} = wp.blockEditor;

const {
	Button,
	Tooltip,
} = wp.components;

const buttonClasses = classnames(
	`content-body`,
);

// Register: Editor with Image
registerBlockType( 'nlsn-blocks/nlsn-button', {
	title: __( 'Button block - NLSN', 'nlsn-blocks' ),
	description: __( 'Add a customizable button.', 'nlsn-blocks' ),
	icon: icon,
	category: 'nielsen-blocks',
	keywords: [
		__( 'button', 'nlsn-blocks' ),
		__( 'link', 'nlsn-blocks' ),
		__( 'nielsen', 'nlsn-blocks' ),
	],
	attributes: {
		...attributes,
		...ContainerOptionsAttributes,
	},

	/**
	 * Determines what is displayed in the editor.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 */
	edit: props => {
		const {
			attributes: {
				buttonText,
				buttonUrl,
				buttonSize,
				buttonAlign,
				buttonColor,
				containerSettings,
			},
			isSelected,
			className,
			setAttributes,
		} = props;

		const classes = defineClassNames( props, 'button' );

		// get color object
		const buttonColorObject = getColorObjectByColorValue( colors, buttonColor );
		let buttonColorName = '';

		( buttonColorObject && buttonColorObject !== undefined ? (
			// get 'slug' value from color object
			buttonColorName = buttonColorObject.slug
		) : null )

		// Return the markup displayed in the editor.
		return (

			<div key="editor-display" className={ className }>

				{ isSelected &&
					<InspectorControls>
						<ContainerOptions
							{ ...props }
						/>
						<Inspector
							{ ...props }
						/>
					</InspectorControls>
				}

				{ containerSettings &&
					<div className="container-settings">
						<BlockIdEdit
							{ ...props }
						/>
						<HideSectionEdit
							{ ...props }
						/>
					</div>
				}

				<div className={ classes.container } id={ classes.id }>
					<div className='container'>
						<div className='row justify-content-center'>
							<div className={ classes.width }>

								<div className={ classnames( buttonClasses ) } style={{ textAlign:`${buttonAlign}`}}>
									<div
										style={ { display: 'inline-block' } }
										className={ buttonSize }
									>
										<RichText
											tagName='p'
											multiline='false'
											className={ classnames( 'content-button', 'btn', buttonSize, `btn-${buttonColorName}` ) }
											style={ { marginTop: '0px' } }
				              placeholder={ __( 'Button Text', 'nlsn-blocks' ) }
				              value={ buttonText }
				              onChange={ buttonText => setAttributes( { buttonText } ) }
				            />
									</div>

									{ isSelected && (
										<form
											className='button-url'
											onSubmit={ event => event.preventDefault() }
										>
											<Tooltip
												text='Add Link'
												children='url'
											>
												<Icon icon={ link } />
												<label>{ __( ' Add Link', 'nlsn-blocks' ) }</label>
											</Tooltip>

											<URLInput
												className='url'
												value={ buttonUrl }
												onChange={ buttonUrl => setAttributes( { buttonUrl } ) }
											/>
											<Button
												icon={ keyboardReturn }
												label={ __( 'Apply', 'nlsn-blocks' ) }
												type='submit'
											/>
										</form>
									) }
								</div>

							</div>
						</div>
					</div>
				</div>
			</div>
		)
	},

	/**
	 * Determines what is displayed on the front-end.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 */
	save: props => {
		const {
			attributes: {
				newWindow,
				buttonText,
				buttonSize,
				buttonUrl,
				buttonAlign,
				buttonColor,
			},
			className,
		} = props;

		const classes = defineClassNames( props, 'button', 'save' );

		let linkTarget = '';
		newWindow === true ? linkTarget = '_blank' : linkTarget = null;

		let relAttr = '';
		linkTarget && linkTarget !== undefined ? relAttr = 'noopener noreferrer' : relAttr = null;

		// get color object
		const buttonColorObject = getColorObjectByColorValue( colors, buttonColor );
		let buttonColorName = '';

		( buttonColorObject && buttonColorObject !== undefined ? (
			// get 'slug' value from color object
			buttonColorName = buttonColorObject.slug
		) : null )

		// Return the markup displayed on the front-end.
		return (
			<div className={ className }>
				<div
					id={ classes.id }
					className={ classes.container }
				>

					<div className='container'>
						<div className='row justify-content-center'>
							<div className={ classes.width }>

								<div className={ classnames( buttonClasses ) } style={ { textAlign: `${ buttonAlign }` } }>
									<a
										className={ classnames( 'content-button', 'btn', buttonSize, `btn-${ buttonColorName }` ) }
										href={ buttonUrl }
										target={ linkTarget }
										rel={ relAttr }
									>
										{ buttonText }
									</a>
								</div>

							</div>
						</div>
					</div>

				</div>
			</div>
		);
	},

	/**
	 * Provide a “deprecated” version of the block.
	 * This allows users opening these blocks in Gutenberg to edit them using the updated block.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/deprecated-blocks/
	 */
	deprecated: [
		{

		},
	]
} );
