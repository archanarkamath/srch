/**
 * Internal block libraries
 */
const { __ } = wp.i18n;
const { Component } = wp.element;

// Editor components
const {
	PanelColorSettings,
} = wp.blockEditor;

const {
  PanelBody,
	PanelRow,
  ToggleControl,
  SelectControl,
	BaseControl,
	ButtonGroup,
	Button,
} = wp.components;

/**
 * Create an Inspector Controls wrapper Component
 */
export default class Inspector extends Component {

  constructor() {
    super( ...arguments );
  }

  render() {
    const { attributes: { newWindow, buttonColor, buttonSize, buttonAlign }, setAttributes } = this.props;

		// Button Size Options
		const buttonSizeOptions = [
			{ value: '', label: __( 'Regular' ) },
			{ value: 'btn-block', label: __( 'Full Width' ) },
		];

		// Button Alignment Options
		const buttonAlignment = {};
		buttonAlignment.buttonAlign = [
		  { value: 'left',   label: 'Left',   icon: 'editor-alignleft' },
		  { value: 'center', label: 'Center', icon: 'editor-aligncenter' },
		  { value: 'right',  label: 'Right',  icon: 'editor-alignright' },
		];

    return (
			<PanelBody
				title={ __( 'Button Settings', 'nlsn-blocks' ) }
				initialOpen={ true }
			>
				<PanelRow>
					<BaseControl
						id={ 'button-alignment' }
						className={ 'alignment-button-group' }
						label={ `Align ${buttonAlign}` }
					>
						<ButtonGroup
							id="button-alignment"
							aria-label={ `Align ${buttonAlign}` }
							className="alignment-button-group"
							style={ { display: 'block' } }
						>
							{ buttonAlignment.buttonAlign.map( ( type ) => {
								return (
									<Button
										key={ type.label }
										icon={ type.icon }
										label={ __( type.label, 'nlsn-blocks' ) }
										style={ { display: 'd-inline', float: 'left' } }
										isPrimary={ buttonAlign === type.value }
										aria-pressed={ buttonAlign === type.value }
										onClick={ () => { setAttributes({ buttonAlign: type.value } ) } }
									/>
								);
							} ) }
						</ButtonGroup>
					</BaseControl>
				</PanelRow>

				<PanelRow>
					<ToggleControl
						label={ __( 'New Window', 'nlsn-blocks' ) }
						checked={ newWindow }
						help={ __( 'Open button link in new window?', 'nlsn-blocks' ) }
						onChange={ newWindow => setAttributes( { newWindow } ) }
					/>
				</PanelRow>

				<PanelRow>
					<SelectControl
						label={ __( 'Button Width', 'nlsn-blocks' ) }
						value={ buttonSize }
						options={ buttonSizeOptions.map( ({ value, label }) => ( {
							value: value,
							label: label,
						} ) ) }
						onChange={ ( buttonSize ) => setAttributes( { buttonSize } ) }
					/>
				</PanelRow>

				<PanelRow>
					<PanelColorSettings
						title={ __( 'Color Settings', 'nlsn-blocks' ) }
						colorSettings={ [
							{
								value: buttonColor,
								onChange: ( buttonColor ) => setAttributes( { buttonColor } ),
								label: __( 'Button Color', 'nlsn-blocks' ),
							},
						] }
					>
					</PanelColorSettings>
				</PanelRow>

			</PanelBody>
    );
  }
}
