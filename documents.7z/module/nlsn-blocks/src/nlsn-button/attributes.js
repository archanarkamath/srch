const attributes = {
	newWindow: {
		type: 'boolean',
		default: false,
	},
	buttonText: {
		type: 'array',
		source: 'children',
		selector: '.content-button',
	},
	buttonUrl: {
		type: 'string',
		source: 'attribute',
		selector: 'a',
		attribute: 'href',
	},
	buttonColor: {
    type: 'string',
	},
	buttonAlign: {
		type: 'string',
		default: 'left',
	},
	buttonSize: {
		type: 'string',
	}
};

export default attributes;
