/**
 * External Dependencies
 * Reference - https://www.liip.ch/en/blog/how-to-extend-existing-gutenberg-blocks-in-wordpress
 */
import assign from 'lodash.assign';
import { colors } from '../components/colors/colorUtils';

/**
 * WordPress Dependencies
 */
const { __ } = wp.i18n;
const { addFilter } = wp.hooks;
const { Fragment } = wp.element;
const { createHigherOrderComponent } = wp.compose;
const {
	InspectorControls,
	getColorObjectByColorValue,
	PanelColorSettings,
} = wp.blockEditor;

// Enable Highlight-Color control on the following blocks only
const allowedHighlightBlocks = [
	'core/paragraph',
];

/**
 * Add highlight color control attribute to block.
 *
 * @param {Object} settings Settings for the block.
 *
 * @return {Object} settings Modified settings.
 */
function addHighlightAttributes( settings ) {

	// Check if object exists for old Gutenberg version compatibility
	// Do nothing if it's another block than our defined ones.
	if ( typeof settings.attributes !== 'undefined' && allowedHighlightBlocks.includes( settings.name ) ) {

		settings.attributes = assign( settings.attributes, {
			highlightColor: {
				type: 'string',
			},
		} );
	}
	return settings;
}

/**
 * Add highlight color controls in the inspector panel.
 *
 * @param {function} BlockEdit Block edit component.
 *
 * @return {function} BlockEdit Modified block edit component.
 */
const withHighlightColorControls = createHigherOrderComponent( ( BlockEdit ) => {

	return ( props ) => {

		// Do nothing if it's another block than our defined ones.
		if ( ! allowedHighlightBlocks.includes( props.name ) ) {
			return (
				<BlockEdit { ...props } />
			);
		}

		const { highlightColor } = props.attributes;

		const highlightColorObject = getColorObjectByColorValue( colors, highlightColor );

		let highlightColorName = '';

		( highlightColorObject && highlightColorObject !== undefined ? (
			highlightColorName = highlightColorObject.slug
		) : null );

		/*
		Add text-bg-highlightColorName class to block if color is defined.
		If color is not defined, reset/remove text-bg-highlightColorName class.
		This is happening for both Edit(Editor) and Save(Front-End).
		 */

		(
			highlightColor ? props.attributes.className = '' : ''
		);

		return (
			<Fragment>

				<div className={`text-bg-${ highlightColorName }`}>
					<BlockEdit { ...props } />
				</div>

				<InspectorControls>
					<PanelColorSettings
						title={ __( 'Highlight Color Settings', 'nlsn-blocks' ) }
						colorSettings={ [
							{
								value: highlightColor,
								onChange: ( highlightColor ) => props.setAttributes( { highlightColor } ),
								label: __( 'Highlight Paragraph Text', 'nlsn-blocks' ),
							},
						] }
					>
					</PanelColorSettings>
				</InspectorControls>

			</Fragment>
		)
	};
}, 'withHighlightColorControls' );

/**
 * Add custom element class in save element.
 *
 * @param {Object} extraProps     Block element.
 * @param {Object} blockType      Blocks object.
 * @param {Object} attributes     Blocks attributes.
 *
 * @return {Object} extraProps Modified block element.
 */
function applyExtraClass( extraProps, blockType, attributes ) {

	const { highlightColor } = attributes;

	const highlightColorObject = getColorObjectByColorValue( colors, highlightColor );

	let highlightColorName = '';

	( highlightColorObject && highlightColorObject !== undefined ? (
		highlightColorName = highlightColorObject.slug
	) : null );


	/* Do nothing if it's another block than our defined ones.
	 * Check if highlightColorName not empty to prevent block validation error.
	 */
	if ( allowedHighlightBlocks.includes( blockType.name ) && highlightColorName !== '' ) {
		return Object.assign(extraProps, {className: `text-bg-${ highlightColorName }`});
	}

	/*
	The new classname needed is already added on save element in withHighlightColorControls function
	 */
	return extraProps;
}

// Add filters
addFilter(
	'blocks.registerBlockType',
	'nlsn-extend-core/custom-attributes',
	addHighlightAttributes
);

addFilter(
	'editor.BlockEdit',
	'nlsn-extend-core/custom-inspector-controls',
	withHighlightColorControls
);

addFilter(
	'blocks.getSaveContent.extraProps',
	'nlsn-extend-core/applyExtraClass',
	applyExtraClass
);
