/**
 * Internal block libraries
 */
const { __ } = wp.i18n;
const { Component, Fragment } = wp.element;

// Block dependencies
import icons from './icons';

const {
  PanelBody,
	PanelRow,
	BaseControl,
	ButtonGroup,
	Button,
  RangeControl,
	TextControl
} = wp.components;

/**
 * Create an Inspector Controls wrapper Component
 */
export default class Inspector extends Component {

  constructor() {
    super( ...arguments );
  }

  render() {
    const { attributes: { columns, columnLayout, overlapType, overlapRange }, setAttributes } = this.props;

		// Column Layout Icons
		const layouts = {};
		layouts.columnLayout = [
		  { columns: 2, label: '50%-50%', value: '50-50', icon: icons.fifty_fifty },
		  { columns: 2, label: '75%-25%', value: '75-25', icon: icons.seventyfive_twentyfive },
		  { columns: 2, label: '25%-75%', value: '25-75', icon: icons.twentyfive_seventyfive },
		  { columns: 2, label: '33%-66%', value: '33-66', icon: icons.thirtythree_sixtysix },
		  { columns: 2, label: '66%-33%', value: '66-33', icon: icons.sixtysix_thirtythree },
		  { columns: 3, label: '33%-33%-33%', value: '33-33-33', icon: icons.thirtythree_thirtythree_thirtythree },
		  { columns: 3, label: '50%-25%-25%', value: '50-25-25', icon: icons.fifty_twentyfive_twentyfive },
		  { columns: 3, label: '25%-50%-25%', value: '25-50-25', icon: icons.twentyfive_fifty_twentyfive },
		  { columns: 3, label: '25%-25%-50%', value: '25-25-50', icon: icons.twentyfive_twentyfive_fifty },
		  { columns: 4, label: '25%-25%-25%-25%', value: '25-25-25-25', icon: icons.twentyfive_twentyfive_twentyfive_twentyfive },
		];

		const overlaps = {
			colOverlapType: [
				{ label: 'None', value: 'none' },
				{ label: 'Left', value: 'left' },
				{ label: 'Right', value: 'right' },
			],
		};

		// METHODS
		const updateAttribute = ( element, updatedValue ) => {
			setAttributes( { [ element ]: updatedValue } );
		};

		const setOverlapRangeControl = () => {
			return (
				<RangeControl
					label={ __( 'Overlap Pixels', 'nlsn-blocks' ) }
					value={ overlapRange }
					onChange={ overlapRange => setAttributes( { overlapRange } ) }
					min={ 0 }
					max={ 300 }
					beforeIcon={ 'image-flip-horizontal' }
					help={ __( 'Number of pixels to overlap the column.', 'nlsn-blocks' ) }
				/>
			)
		};

    return (
			<PanelBody
				title={ __( 'Column Layouts', 'nlsn-blocks' ) }
				className='nlsn-column-layouts'
				initialOpen={ true }
			>
				<PanelRow>
					<BaseControl
						id={ 'column-layout' }
						label={ columnLayout }
					>
						<ButtonGroup
							id="column-layout"
							aria-label={ columnLayout }
							className="button-group"
							style={ { display: 'block' } }
						>
							{ layouts.columnLayout.map( ( type ) => {
								return (
									<Button
										key={ type.label }
										icon={ type.icon }
										label={ type.label }
										// isLarge
										isPrimary={ columnLayout === type.value }
										aria-pressed={ columnLayout === type.value }
										onClick={ () => { setAttributes({ columns: type.columns, columnLayout: type.value } ) } }
									/>
								);
							} ) }
						</ButtonGroup>
					</BaseControl>
				</PanelRow>

				{ '50-50' === columnLayout &&
					<Fragment>
						<PanelBody>
							<BaseControl
								id="overlap-type"
								label={ __( 'Overlap Type', 'nlsn-blocks' ) }
							>
								<ButtonGroup
									id="overlap-type"
									aria-label={ __( 'Overlap Type', 'nlsn-blocks' ) }
									className="overlap-type"
									style={ { display: 'block' } }
									>
									{ overlaps.colOverlapType.map( ( type ) => {
										return (
											<Button
												key={ type.label }
												// isLarge
												isPrimary={ overlapType === type.value }
												aria-pressed={ overlapType === type.value }
												onClick={ () => updateAttribute( 'overlapType', type.value ) }
											>
												{ type.label }
											</Button>
										);
									} ) }
								</ButtonGroup>
							</BaseControl>
							{ ( 'left' === overlapType || 'right' === overlapType ) &&
									setOverlapRangeControl()
							}
						</PanelBody>
					</Fragment>
				}

			</PanelBody>
    );
  }
}
