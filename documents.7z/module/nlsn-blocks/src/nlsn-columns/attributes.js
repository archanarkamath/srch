const attributes = {
	columns: {
		type: 'number',
		default: 2,
	},
	columnLayout: {
		type: 'string',
		default: '50-50',
	},
	hideInspector: {
		type: 'boolean',
		default: false,
	},
	overlapType:{
		type: 'string',
		default: 'none',
	},
	overlapRange: {
		type: 'number',
		default: 0,
	},
};

export default attributes;
