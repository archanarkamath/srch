/**
 * BLOCK: Columns
 */

// Block dependencies
import classnames from 'classnames';
import defineClassNames from '../utilities/defineClasses';
import { times } from 'lodash-es';
import Inspector from './inspector';
import attributes from './attributes';

// Import all of our Container Options requirements.
import ContainerOptions, {
	ContainerOptionsAttributes,
	HideSectionEdit,
	BlockIdEdit,

} from '../components/container-options';

import { columns } from '@wordpress/icons';

/**
 * WordPress dependencies
 */
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks

// Register editor components
const {
	InspectorControls,
	InnerBlocks,
} = wp.blockEditor;

const { createBlock } = wp.blocks;
const { useDispatch, useSelect } = wp.data;

const defineBlockClasses = ( props ) => {

	/*
	Pass the overlapType value only if it's not equal to 'none', and if the layout selected is 50-50,
	otherwise don't change existing 'save' function, which would need deprecated value and can create validation error.
	 */
	let overlapTypeSelected = ( 'none' !== props.attributes.overlapType && '50-50' === props.attributes.columnLayout ) ? `overlap-${props.attributes.overlapType}` : null;

	// setup layout classes
	const blockClasses = classnames(
		'column-layout',
		`has-${ props.attributes.columnLayout }-layout`,
		overlapTypeSelected,
	);
	return {
		blockClasses,
	};
};

/*
Create new <div> to hold our overlapRange value and only add it if the overlapType is not equal to 'none', and if the layout selected is 50-50,
otherwise don't change existing 'save' function, which would need deprecated value and can create validation error.
 */
const dataOverlapRange = ( props ) => {
	if ( 'none' !== props.attributes.overlapType && '50-50' === props.attributes.columnLayout ) {
		let rangeValue = props.attributes.overlapRange;
		return ( <div className="overlap-range" data-overlap-range={ rangeValue} /> );
	}
};

/**
 * Allowed blocks constant is passed to InnerBlocks precisely as specified here.
 * The contents of the array should never change.
 * The array should contain the name of each block that is allowed.
 * In columns block, the only block we allow is 'core/column'.
 *
 * @constant
 * @type {string[]}
*/
const ALLOWED_BLOCKS = [ 'core/column' ];

/**
 * Returns the layouts configuration for a given number of columns.
 *
 * @param {number} columns Number of columns.
 *
 * @return {Object[]} Columns layout configuration.
 */

registerBlockType( 'nlsn-blocks/nlsn-columns', {
	title: __( 'Columns - NLSN', 'nlsn-blocks' ),
	description: __( 'Create columns layout', 'nlsn-blocks' ),
	icon: columns,
	category: 'nielsen-blocks',
	keywords: [
		__( 'columns', 'nlsn-blocks' ),
		__( 'template', 'nlsn-blocks' ),
		__( 'nielsen', 'nlsn-blocks' ),
	],
	attributes: {
		...ContainerOptionsAttributes,
		...attributes,
	},

	edit: props => {
		const {
			attributes: {
				columns,
				containerSettings,
				hideInspector,
				overlapType,
				overlapRange,
			},
			isSelected,
			className,
			clientId
		} = props;

		const classes = defineClassNames( props, 'columns' );
		const blockClassesObject = defineBlockClasses( props );
		const dataOverlapRangeObject = dataOverlapRange( props );
		
		//modify the innerBlocks using the replaceInnerBlocks function. This function takes the block clientId 
		const { replaceInnerBlocks } = useDispatch("core/block-editor");
		const { inner_columns } = useSelect(select => ({
            inner_columns: select("core/block-editor").getBlocks(clientId)
		}));
		
		let inner_blocks = inner_columns;
		if (inner_columns.length < columns) {
				inner_blocks = [
					...inner_columns,
					...times(columns - inner_columns.length, () =>
						createBlock('core/column')
					)
				];
				replaceInnerBlocks(clientId, inner_blocks, false);
			}
		else if (inner_columns.length > columns) {
				inner_blocks = inner_blocks.slice(0, columns);
				replaceInnerBlocks(clientId, inner_blocks, false);
			}

		const getColumnTemplate = ( columns ) => {			
			return times( columns, () => [ 'core/column' ] );			
		};

	
		/*
		Set overlap help-text and editor arrows
		 */
		let overlapHelpText = '';
		if ( overlapType === 'left' ) {
			overlapHelpText = 'Left column overlap: ' + overlapRange + ' pixels';
		} else if ( overlapType === 'right' ) {
			overlapHelpText = 'Right column overlap: ' + overlapRange + ' pixels';
		}
		const overlapArrowRight = () => {
			if ( 'left' === overlapType ) {
				return ( <i className="fa fa-long-arrow-right fa-2x d-block"/> );
			}
		};
		const overlapArrowLeft = () => {
			if ( 'right' === overlapType ) {
				return ( <i className="fa fa-long-arrow-left fa-2x d-block" /> );
			}
		};

		return (
			
			<div key="editor-display" className={ className }>

				{ ( isSelected && ! hideInspector ) &&
					<InspectorControls>
						<ContainerOptions
							{ ...props }
						/>
						<Inspector
							{ ...props }
						/>
					</InspectorControls>
				}

				{ containerSettings &&
					<div className="container-settings">
						<BlockIdEdit
							{ ...props }
						/>
						<HideSectionEdit
							{ ...props }
						/>
					</div>
				}

				<div className={ classes.container } id={ classes.id }>
					<div className="container">
						<div className="row justify-content-center">
							<div className={ classes.width }>

								<div className={ blockClassesObject.blockClasses } >
									{ dataOverlapRangeObject }

									<div className={ classnames( `overlap-help-text text-${overlapType}` ) } style={ { fontSize: '12px' } }>
										{ overlapArrowLeft() }
										{ overlapArrowRight() }
										{ overlapHelpText }
									</div>
									<InnerBlocks
										template={ getColumnTemplate( columns ) }
										templateLock="all"
										allowedBlocks={ ALLOWED_BLOCKS }
									/>

								</div>

							</div>
						</div>
					</div>
				</div>
			</div>
		)
	},

	save: props => {
		const {
			className,
		} = props;

		const classes = defineClassNames( props, 'columns', 'save' );

		const blockClassesObject = defineBlockClasses( props );
		const dataOverlapRangeObject = dataOverlapRange( props );

		// Return the markup displayed on the front-end.
		return (
			<div className={ className }>
				<div
					id={ classes.id }
					className={ classes.container }
				>

					<div className="container">
						<div className="row justify-content-center">
							<div className={ classes.width }>

								<div className={ classnames( blockClassesObject.blockClasses, 'row' ) }>
									<InnerBlocks.Content />
									{ dataOverlapRangeObject }
								</div>

							</div>
						</div>
					</div>

				</div>
			</div>
		);
	},

	deprecated: [
		{
			attributes: {
				...ContainerOptionsAttributes,
				...attributes,
			},
			save: props => {
				const {
					className,
				} = props;

				const classes = defineClassNames( props, 'columns', 'save' );

				const blockClassesObject = defineBlockClasses( props );

				// Return the markup displayed on the front-end.
				return (
					<div className={ className }>
						<div
							id={ classes.id }
							className={ classes.container }
						>

							<div className="container">
								<div className="row justify-content-center">
									<div className={ classes.width }>

										<div className={ classnames( blockClassesObject.blockClasses, 'row' ) }>
											<InnerBlocks.Content />
										</div>

									</div>
								</div>
							</div>

						</div>
					</div>
				);
			},
		},
	],
} );
