wp.i18n.setLocaleData( { '': {} }, 'nlsn-blocks' );
