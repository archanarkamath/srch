/**
 * BLOCK: Slide Editor with Image
 */

// Block dependencies
import classnames from 'classnames';
import Inspector from './inspector';
import attributes from './attributes';
import icon from './icon';

import { Icon, link, cancelCircleFilled, keyboardReturn, gallery } from '@wordpress/icons';

// Components
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks

// Register editor components
const {
	InspectorControls,
	MediaUpload,
	RichText,
	URLInput,
} = wp.blockEditor;

const {
	Button,
	Tooltip,
} = wp.components;

const blockClasses = classnames(
	`carousel-item`,
);

const imageClasses = classnames(
	`post-thumbnail`,
	`col-md-5`,
);
const editorClasses = classnames(
	`post-content`,
	`col-md-7`,
	`align-self-center`,
);

// Register: Slide Editor with Image
registerBlockType( 'nlsn-blocks/nlsn-slide-editor-with-image', {
	title: __( 'Slide Editor with Image - NLSN', 'nlsn-blocks' ),
	description: __( 'Add text content with an image and button to a Slider.', 'nlsn-blocks' ),
	icon,
	category: 'nielsen-blocks',
	parent: [ 'nlsn-blocks/nlsn-slider' ],
	keywords: [
		__( 'slider', 'nlsn-blocks' ),
		__( 'editor', 'nlsn-blocks' ),
		__( 'nielsen', 'nlsn-blocks' ),
	],
	attributes: {
		...attributes,
	},

	/**
	 * Determines what is displayed in the editor.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 */
	edit: props => {
		const {
			attributes: {
				imageAlignment,
				imgID,
				imgURL,
				imgAlt,
				contentTitle,
				contentEditor,
				buttonText,
				buttonUrl,
			},
			isSelected,
			className,
			setAttributes,
		} = props;

		const onSelectImage = img => {
      setAttributes( {
        imgID: img.id,
        imgURL: img.url,
        imgAlt: img.alt,
      } );
    };
    const onRemoveImage = () => {
      setAttributes({
        imgID: null,
        imgURL: null,
        imgAlt: null,
      });
    }

		let imageAlign = '';
		let editorAlign = '';
		if ( imageAlignment === 'right' ) {
			imageAlign = 'push-md-7';
			editorAlign = 'pull-md-5';
		}

		// Return the markup displayed in the editor.
		return (
			<>
				<InspectorControls>
					<Inspector
						{ ...props }
					/>
				</InspectorControls>

				<div className={ className }>
						
					<div className={ classnames( blockClasses ) } style={ { display: 'block' } }>
						<div className='row'>

							{ ! imgID ? (
								<div className={ classnames( imageClasses, imageAlign ) }>
									<MediaUpload
										onSelect={ onSelectImage }
										value={ imgID }
										render={ ( { open } ) => (
											<Button onClick={ open } icon={ gallery } > Add/Upload Image </Button>
										) }
									/>
								</div>
							) : (
								<div className={ classnames( imageClasses, imageAlign ) }>
					<img
					src={ imgURL }
					alt={ imgAlt }
					/>

									{ isSelected ? (
					<Button
						className='remove-image'
						onClick={ onRemoveImage }
						icon={ cancelCircleFilled }
					/>
					) : null }

								</div>
							)}

							<div className={ classnames( editorClasses, editorAlign ) }>
								<RichText
									tagName='h3'
									multiline='false'
									className={ classnames(
										'post-title'
									) }
									placeholder={ __( 'Add your title', 'nlsn-blocks' ) }
									value={ contentTitle }
									onChange={ contentTitle => { setAttributes( { contentTitle } ) } }
								/>

								<RichText
									tagName='div'
									multiline='p'
									className={ classnames(
										'content-editor'
									) }
									placeholder={ __( 'Add your message', 'nlsn-blocks' ) }
									value={ contentEditor }
									onChange={ contentEditor => { setAttributes( { contentEditor } ) } }
								/>

								{ ( ( buttonText && buttonText.length > 0 ) || isSelected ) && (
									<div
										style={ { display: 'inline-block' } }
									>
										<RichText
											tagName='p'
											multiline='false'
											className={ classnames( 'more-link', 'btn' ) }
											placeholder={ __( 'Button Text', 'nlsn-blocks' ) }
											value={ buttonText }
											onChange={ buttonText => setAttributes( { buttonText } ) }
											/>
									</div>
								) }

								{ isSelected && (
									<form
										className='button-url'
										onSubmit={ event => event.preventDefault() }
									>
										<Tooltip
											text='Add Link'
											children='url'
										>
											<Icon icon={ link } />
											<label>{ __( ' Add Link', 'nlsn-blocks' ) }</label>
										</Tooltip>

										<URLInput
											className='url'
											value={ buttonUrl }
											onChange={ buttonUrl => setAttributes( { buttonUrl } ) }
										/>
										<Button
											icon={ keyboardReturn }
											label={ __( 'Apply', 'nlsn-blocks' ) }
											type='submit'
										/>
									</form>
								) }

							</div>

						</div>
					</div>
				</div>
			</>
		)
	},

	/**
	 * Determines what is displayed on the front-end.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 */
	save: props => {
		const {
			attributes: {
				imageAlignment,
				imgURL,
				imgAlt,
				contentTitle,
				contentEditor,
				newWindow,
				buttonText,
				buttonUrl,
			},
			className,
		} = props;

		let imageAlign = '';
		let editorAlign = '';
		if ( imageAlignment === 'right' ) {
			imageAlign = 'push-md-7';
			editorAlign = 'pull-md-5';
		}

		let linkTarget = '';
		newWindow === true ? linkTarget = '_blank' : linkTarget = null;

		let relAttr = '';
		linkTarget && linkTarget !== undefined ? relAttr = 'noopener noreferrer' : relAttr = null;

		// Return the markup displayed on the front-end.
		return (
			<div className={ classnames( className, blockClasses ) }>
				<div className={ classnames( 'row', 'justify-content-center' ) }>

					{ imgURL ? (
						<div className={ classnames( imageClasses, imageAlign ) }>
							<img
								className='content-thumbnail'
								src={ imgURL }
								alt={ imgAlt }
							/>
						</div>
					) : null }

					<div className={ classnames( editorClasses, editorAlign ) }>

						{ ( contentTitle && contentTitle.length > 0 ) ? (
							<RichText.Content
								tagName='h3'
								className={ 'post-title' }
								value={ contentTitle }
							/>
						) : null }

						<div className='content-editor'>
							{ contentEditor }
						</div>

						{ ( buttonText && buttonText.length > 0 ) ? (
							<RichText.Content
								tagName='a'
								className={ classnames( 'more-link', 'btn' ) }
								href={ buttonUrl }
								target={ linkTarget }
								rel={ relAttr }
								value={ buttonText }
							/>
						) : null }
					</div>
				</div>
			</div>
		);
	},

	/**
	 * Provide a “deprecated” version of the block.
	 * This allows users opening these blocks in Gutenberg to edit them using the updated block.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/deprecated-blocks/
	 */
	deprecated: [
		{

		},
	]
} );
