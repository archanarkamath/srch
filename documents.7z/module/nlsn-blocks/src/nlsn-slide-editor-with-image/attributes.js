const attributes = {
	imageAlignment: {
		type: 'string',
		default: 'left',
	},
	imgID: {
		type: 'number',
	},
	imgURL: {
		type: 'string',
		source: 'attribute',
		attribute: 'src',
		selector: '.content-thumbnail',
	},
	imgAlt: {
		type: 'string',
		source: 'attribute',
		attribute: 'alt',
		selector: '.content-thumbnail',
	},
	contentTitle: {
		type: 'string',
		source: 'html',
		selector: '.post-title',
	},
	contentEditor: {
		type: 'array',
		source: 'children',
		selector: '.content-editor',
	},
	newWindow: {
		type: 'boolean',
		default: false,
	},
	buttonText: {
		type: 'string',
		source: 'html',
		selector: '.more-link',
	},
	buttonUrl: {
		type: 'string',
		source: 'attribute',
		selector: 'a',
		attribute: 'href',
	},
};

export default attributes;
