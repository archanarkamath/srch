/**
 * Internal block libraries
 */
const { __ } = wp.i18n;
const { Component, Fragment } = wp.element;

const {
  PanelBody,
	PanelRow,
  ToggleControl,
	BaseControl,
	ButtonGroup,
	Button,
} = wp.components;

/**
 * Create an Inspector Controls wrapper Component
 */
export default class Inspector extends Component {

  constructor() {
    super( ...arguments );
  }

  render() {
    const { attributes: { imageAlignment, newWindow }, setAttributes } = this.props;

		// Button Alignment Options
		const buttonAlignment = {};
		buttonAlignment.imageAlignment = [
		  { value: 'left',   label: 'Left',   icon: 'editor-alignleft' },
		  { value: 'right',  label: 'Right',  icon: 'editor-alignright' },
		];

    return (
			<Fragment>
				<PanelBody
					title={ __( 'Image Settings', 'nlsn-blocks' ) }
					initialOpen={ true }
				>

					<PanelRow>
						<BaseControl
							id={ 'image-alignment' }
							className={ 'alignment-button-group' }
							label={ `Image Align ${imageAlignment}` }
						>
							<ButtonGroup
								id="image-alignment"
								aria-label={ `Image Align ${imageAlignment}` }
								className="alignment-button-group"
								style={ { display: 'block' } }
							>
								{ buttonAlignment.imageAlignment.map( ( type ) => {
									return (
										<Button
											key={ type.label }
											icon={ type.icon }
											label={ __( type.label, 'nlsn-blocks' ) }
											style={ { display: 'd-inline', float: 'left' } }
											isPrimary={ imageAlignment === type.value }
											aria-pressed={ imageAlignment === type.value }
											onClick={ () => { setAttributes({ imageAlignment: type.value } ) } }
										/>
									);
								} ) }
							</ButtonGroup>
						</BaseControl>
					</PanelRow>
				</PanelBody>

				<PanelBody
					title={ __( 'Button Settings', 'nlsn-blocks' ) }
					initialOpen={ true }
				>
					<PanelRow>
						<ToggleControl
							label={ __( 'New Window', 'nlsn-blocks' ) }
							checked={ newWindow }
							help={ __( 'Open button link in new window?', 'nlsn-blocks' ) }
							onChange={ newWindow => setAttributes( { newWindow } ) }
						/>
					</PanelRow>

				</PanelBody>
			</Fragment>
    );
  }
}
