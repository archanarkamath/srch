/**
 * BLOCK: Blockquote
 */

// Block dependencies
import classnames from 'classnames';
import defineClassNames from '../utilities/defineClasses';
import Inspector from './inspector';
import attributes from './attributes';
import icon from './icon';
import { colors } from '../components/colors/colorUtils';


// Import all of our Container Options requirements.
import ContainerOptions, {
	ContainerOptionsAttributes,
	HideSectionEdit,
	BlockIdEdit,
} from '../components/container-options';

// Components
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks

// Register editor components
const {
	InspectorControls,
	RichText,
	BlockControls,
	AlignmentToolbar,
	PanelColorSettings,
	getColorObjectByColorValue,
} = wp.blockEditor;

const blockClasses = classnames(
	'blockquote',
);

// Register: Blockquote
registerBlockType( 'nlsn-blocks/nlsn-blockquote', {
	title: __( 'Blockquote - NLSN', 'nlsn-blocks' ),
	description: __( 'Highlight a quote from your post or page. Tweet quote if needed.', 'nlsn-blocks' ),
	icon: icon,
	category: 'nielsen-blocks',
	keywords: [
		__( 'blockquote', 'nlsn-blocks' ),
		__( 'tweet', 'nlsn-blocks' ),
		__( 'nielsen', 'nlsn-blocks' ),
	],
	attributes: {
		...attributes,
		...ContainerOptionsAttributes,
	},

	edit: props => {
		const {
			attributes: {
				tweetQuote,
				verticalLine,
				align,
				quoteBody,
				quoteCitation,
				containerSettings,
				lineColor,
				highlightColor,
			},
			isSelected,
			className,
			setAttributes,
		} = props;

		const classes = defineClassNames( props, 'blockquote' );

		const colorPaletteOption = () => {
			return (
				<PanelColorSettings
					title={ __( 'Color Settings', 'nlsn-blocks' ) }
					colorSettings={ [
						verticalLine && {
							value: lineColor,
							onChange: ( lineColor ) => setAttributes( { lineColor } ),
							label: __( 'Vertical Line Color', 'nlsn-blocks' ),
						},
						{
							value: highlightColor,
							onChange: ( highlightColor ) => setAttributes( { highlightColor } ),
							label: __( 'Highlight Color', 'nlsn-blocks' ),
						},
					] }
				>

				</PanelColorSettings>
			);
		};
		// get color object
		const lineColorObject = getColorObjectByColorValue( colors, lineColor );
		const highlightColorObject = getColorObjectByColorValue( colors, highlightColor );
		let lineColorName = '';
		let highlightColorName = '';

		( lineColorObject && lineColorObject !== undefined ? (
			// get 'slug' value from color object
			lineColorName = lineColorObject.slug
		) : null );

		( highlightColorObject && highlightColorObject !== undefined ? (
			// get 'slug' value from highlight color object
			highlightColorName = highlightColorObject.slug
		) : null );

		return (

			<div key="editor-display" className={ className }>

				{ containerSettings &&
					<div className="container-settings">
						<BlockIdEdit
							{ ...props }
						/>
						<HideSectionEdit
							{ ...props }
						/>
					</div>
				}
				{ isSelected &&
					<InspectorControls>
						<ContainerOptions
							{ ...props }
						/>
						<Inspector
							{ ...props }
						/>
						{ colorPaletteOption() }
					</InspectorControls>
				}

				{ isSelected &&
					<BlockControls>
						<AlignmentToolbar
							value={ align }
							onChange={ value => setAttributes( { align: value } ) }
						/>
					</BlockControls>
				}

				<div className={ classes.container } id={ classes.id }>
					<div className="container">
						<div className="row justify-content-center">
							<div className={ `${ classes.width }` }>
								<div className={ classnames( verticalLine ? `blockquote vertical-line vertical-line-${lineColorName}` : 'blockquote no-vertical-line', classes.align ) }>
									<RichText
										tagName="h3"
										multiline="false"
										className={ `quote-body text-bg-${ highlightColorName }`}
										placeholder={ __( 'Add quote', 'nlsn-blocks' ) }
										value={ quoteBody }
										onChange={ value => setAttributes( { quoteBody: value } ) }
									/>

									{ ( ( quoteCitation && quoteCitation.length > 0 ) || isSelected ) && (
										<RichText
											tagName="h5"
											multiline="false"
											className={ `quote-citation text-bg-${ highlightColorName }`}
											placeholder={ __( 'Add citation', 'nlsn-blocks' ) }
											value={ quoteCitation }
											onChange={ value => setAttributes( { quoteCitation: value } ) }
										/>
									) }

									{ tweetQuote &&
										<div className="quote-tweet">
											<span
												className={ classnames( 'btn', 'tweet-button', 'twitter-share-button' ) }
											>
												<i className="fa fa-twitter"></i>
												{ __( 'Tweet', 'nlsn-blocks' ) }
											</span>

											{ isSelected && (
												<p
													className="quote-tweet-count"
													style={ { fontSize: '15px' } }
												>
													{ quoteBody && quoteBody.length > 0 ? 256 - quoteBody[ 0 ].length : 256 }/256
												</p>
											) }

										</div>
									}

								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		)
	},

	save: props => {
		const {
			attributes: {
				tweetQuote,
				quoteBody,
				verticalLine,
				quoteCitation,
				lineColor,
				highlightColor,
			},
			className,
		} = props;

		// Tweet Button URL
		const tweetUrl = `http://twitter.com/share?&text=${ encodeURIComponent( quoteBody ) }`;

		const classes = defineClassNames( props, 'blockquote', 'save' );

		const lineColorObject = getColorObjectByColorValue( colors, lineColor );
		const highlightColorObject = getColorObjectByColorValue( colors, highlightColor );
		let lineColorName = null;
		let highlightColorName = null;
		if (lineColorObject !== undefined) {
			lineColorName = getColorObjectByColorValue( colors, lineColor ).slug;
		}
		if (highlightColorObject !== undefined) {
			highlightColorName = getColorObjectByColorValue( colors, highlightColor ).slug;
		}

		// Return the markup displayed on the front-end.
		return (
			<div className={ className }>
				<div
					id={ classes.id }
					className={ classes.container }
				>
					<div className="container">
						<div className="row justify-content-center">
							<div className={ classes.width }>

								<div className={ classnames( verticalLine ? `blockquote vertical-line vertical-line-${lineColorName} text-highlight text-bg-${ highlightColorName }` : `blockquote no-vertical-line text-highlight text-bg-${ highlightColorName }`, classes.align ) }>

									<h3 className="quote-body">
										{ quoteBody }
									</h3>

									{ ( quoteCitation && quoteCitation.length > 0 ) &&
										<RichText.Content
											tagName="h5"
											className={ 'quote-citation' }
											value={ quoteCitation }
										/>
									}

									{ tweetQuote &&
										<div className="quote-tweet">
											<a
												className={ classnames( 'tweet-button', 'twitter-share-button' ) }
												href={ tweetUrl }
												target="_blank"
												rel="noopener noreferrer"
												data-size="large"
												data-show-count="false"
											>
												{ __( 'Tweet', 'nlsn-blocks' ) }
											</a>
										</div>
									}

								</div>

							</div>
						</div>
					</div>

				</div>
			</div>
		);
	},

	/**
	 * Provide a “deprecated” version of the block.
	 * This allows users opening these blocks in Gutenberg to edit them using the updated block.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/deprecated-blocks/
	 */
	deprecated: [
		{	attributes: {
				...attributes,
				...ContainerOptionsAttributes,
			},
			save: props => {
				const {
					attributes: {
						tweetQuote,
						quoteBody,
						verticalLine,
						quoteCitation,
						lineColor,
						highlightColor,
					},
					className,
				} = props;

				// Tweet Button URL
				const tweetUrl = `http://twitter.com/share?&text=${ encodeURIComponent( quoteBody ) }`;

				const classes = defineClassNames( props, 'blockquote', 'save' );

				const lineColorObject = getColorObjectByColorValue( colors, lineColor );
				const highlightColorObject = getColorObjectByColorValue( colors, highlightColor );
				let lineColorName = null;
				let highlightColorName = null;
				if (lineColorObject !== undefined) {
					lineColorName = getColorObjectByColorValue( colors, lineColor ).slug;
				}
				if (highlightColorObject !== undefined) {
					highlightColorName = getColorObjectByColorValue( colors, highlightColor ).slug;
				}

				// Return the markup displayed on the front-end.
				return (
					<div className={ className }>
						<div
							id={ classes.id }
							className={ classes.container }
						>
							<div className="container">
								<div className="row justify-content-center">
									<div className={ classes.width }>

										<div className={ classnames( verticalLine ? `blockquote vertical-line vertical-line-${lineColorName} text-highlight text-bg-${ highlightColorName }` : `blockquote text-highlight text-bg-${ highlightColorName }`, classes.align ) }>

											<h3 className="quote-body">
												{ quoteBody }
											</h3>

											{ ( quoteCitation && quoteCitation.length > 0 ) &&
											<RichText.Content
												tagName="h5"
												className={ 'quote-citation' }
												value={ quoteCitation }
											/>
											}

											{ tweetQuote &&
											<div className="quote-tweet">
												<a
													className={ classnames( 'tweet-button', 'twitter-share-button' ) }
													href={ tweetUrl }
													target="_blank"
													rel="noopener noreferrer"
													data-size="large"
													data-show-count="false"
												>
													{ __( 'Tweet', 'nlsn-blocks' ) }
												</a>
											</div>
											}

										</div>

									</div>
								</div>
							</div>

						</div>
					</div>
				);
			},
		},
		{	attributes: {
				...attributes,
				...ContainerOptionsAttributes,
			},
			save: props => {
				const {
					attributes: {
						tweetQuote,
						quoteBody,
						quoteCitation,
					},
					className,
				} = props;

				// Tweet Button URL
				const tweetUrl = `http://twitter.com/share?&text=${ encodeURIComponent( quoteBody ) }`;

				const classes = defineClassNames( props, 'blockquote', 'save' );

				// Return the markup displayed on the front-end.
				return (
					<div className={ className }>
						<div
							id={ classes.id }
							className={ classes.container }
						>
							<div className="container">
								<div className="row justify-content-center">
									<div className={ classes.width }>

										<div className={ classnames( blockClasses, classes.align ) }>

											<h3 className="quote-body">
												{ quoteBody }
											</h3>

											{ ( quoteCitation && quoteCitation.length > 0 ) &&
												<RichText.Content
													tagName="h5"
													className={ 'quote-citation' }
													value={ quoteCitation }
												/>
											}

											{ tweetQuote &&
												<div className="quote-tweet">
													<a
														className={ classnames( 'tweet-button', 'twitter-share-button' ) }
														href={ tweetUrl }
														target="_blank"
														rel="noopener noreferrer"
														data-size="large"
														data-show-count="false"
													>
														{ __( 'Tweet', 'nlsn-blocks' ) }
													</a>
												</div>
											}

										</div>

									</div>
								</div>
							</div>

						</div>
					</div>
				);
			},
		},
		{
			attributes: {
				...attributes,
				...ContainerOptionsAttributes,
			},
			save: props => {
				const {
					attributes: {
						tweetQuote,
						quoteBody,
						quoteCitation,
					},
					className,
				} = props;

				// Tweet Button URL
				const tweetUrl = `http://twitter.com/share?&text=${ encodeURIComponent( quoteBody ) }`;

				const classes = defineClassNames( props, 'blockquote', 'save' );

				// Return the markup displayed on the front-end.
				return (
					<div className={ className }>
						<div
							id={ classes.id }
							className={ classes.container }
						>
							<div className="container">
								<div className="row justify-content-center">
									<div className={ classes.width }>

										<div className={ classnames( blockClasses, classes.align ) }>

											<h3 className="quote-body">
												{ quoteBody }
											</h3>

											{ ( quoteCitation && quoteCitation.length > 0 ) &&
												<RichText.Content
													tagName="h5"
													className={ 'quote-citation' }
													value={ quoteCitation }
												/>
											}

											{ tweetQuote &&
												<div className="quote-tweet">
													<a
														className={ classnames( 'tweet-button', 'twitter-share-button' ) }
														href={ tweetUrl }
														target="_blank"
														rel="noopener noreferrer"
														data-size="large"
														data-show-count="false"
													>
														{ __( 'Tweet', 'nlsn-blocks' ) }
													</a>
													<script async src="https://platform.twitter.com/widgets.js" charSet="utf-8"></script>
												</div>
											}

										</div>

									</div>
								</div>
							</div>

						</div>
					</div>
				);
			},
		},
		{
			attributes: {
				tweetQuote: {
					type: 'boolean',
					default: false,
				},
				verticalLine: {
					type: 'boolean',
					default: true,
				},
				align: {
					type: 'string',
				},
				quoteBody: {
					type: 'array',
					source: 'children',
					selector: '.quote-body',
				},
				quoteCitation: {
					type: 'string',
					source: 'html',
					selector: '.quote-citation',
				},
				lineColor: {
					type: 'string',
				},
				highlightColor: {
					type: 'string',
				},
				...ContainerOptionsAttributes,
			},
			save: props => {
				const {
					attributes: {
						tweetQuote,
						quoteBody,
						verticalLine,
						quoteCitation,
						lineColor,
						highlightColor,
					},
					className,
				} = props;

				// Tweet Button URL
				const tweetUrl = `http://twitter.com/share?&text=${ encodeURIComponent( quoteBody ) }`;

				const classes = defineClassNames( props, 'blockquote', 'save' );

				const lineColorObject = getColorObjectByColorValue( colors, lineColor );
				const highlightColorObject = getColorObjectByColorValue( colors, highlightColor );
				let lineColorName = null;
				let highlightColorName = null;
				if (lineColorObject !== undefined) {
					lineColorName = getColorObjectByColorValue( colors, lineColor ).slug;
				};
				if (highlightColorObject !== undefined) {
					highlightColorName = getColorObjectByColorValue( colors, highlightColor ).slug;
				}

				// Return the markup displayed on the front-end.
				return (
					<div className={ className }>
						<div
							id={ classes.id }
							className={ classes.container }
						>
							<div className="container">
								<div className="row justify-content-center">
									<div className={ classes.width }>

										<div className={ classnames( verticalLine ? `blockquote vertical-line vertical-line-${lineColorName} text-highlight text-bg-${ highlightColorName }` : `blockquote text-highlight text-bg-${ highlightColorName }`, classes.align ) }>

											<h3 className="quote-body">
												{ quoteBody }
											</h3>

											{ ( quoteCitation && quoteCitation.length > 0 ) &&
												<RichText.Content
													tagName="h5"
													className={ 'quote-citation' }
													value={ quoteCitation }
												/>
											}

											{ tweetQuote &&
												<div className="quote-tweet">
													<a
														className={ classnames( 'tweet-button', 'twitter-share-button' ) }
														href={ tweetUrl }
														target="_blank"
														rel="noopener noreferrer"
														data-size="large"
														data-show-count="false"
													>
														{ __( 'Tweet', 'nlsn-blocks' ) }
													</a>
												</div>
											}

										</div>

									</div>
								</div>
							</div>

						</div>
					</div>
				);
			},

		},
	],
} );
