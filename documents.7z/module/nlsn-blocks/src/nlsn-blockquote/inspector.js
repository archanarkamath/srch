/**
 * Internal block libraries
 */
const { __ } = wp.i18n;
const { Component } = wp.element;

const {
  PanelBody,
	PanelRow,
  ToggleControl,
} = wp.components;

/**
 * Create an Inspector Controls wrapper Component
 */
export default class Inspector extends Component {

  constructor() {
    super( ...arguments );
  }

  render() {
    const { attributes: { tweetQuote, verticalLine }, setAttributes } = this.props;

    return (
			<PanelBody
				title={ __( 'Blockquote Settings', 'nlsn-blocks' ) }
				initialOpen={ true }
			>

				<PanelRow>
					<ToggleControl
						label={ __( 'Tweet', 'nlsn-blocks' ) }
						checked={ tweetQuote }
						help={ __( 'Tweet quote?', 'nlsn-blocks' ) }
						onChange={ tweetQuote => setAttributes( { tweetQuote } ) }
					/>
				</PanelRow>
				<PanelRow>
					<ToggleControl
						label={ __( 'Vertical Line', 'nlsn-blocks' ) }
						checked={ verticalLine }
						help={ verticalLine ? __( 'Vertical Line Enabled', 'nlsn-blocks' ) : __( 'Vertical Line Disabled', 'nlsn-blocks' )  }
						onChange={ verticalLine => setAttributes( { verticalLine } ) }
					/>
				</PanelRow>

			</PanelBody>
    );
  }
}
