const attributes = {
	tweetQuote: {
		type: 'boolean',
		default: false,
	},
	verticalLine: {
		type: 'boolean',
		default: true,
	},
	align: {
		type: 'string',
	},
	quoteBody: {
		type: 'array',
		source: 'children',
		selector: '.quote-body',
	},
	quoteCitation: {
		type: 'string',
		source: 'html',
		selector: '.quote-citation',
	},
	lineColor: {
		type: 'string',
	},
	highlightColor: {
		type: 'string',
	},
};

export default attributes;
