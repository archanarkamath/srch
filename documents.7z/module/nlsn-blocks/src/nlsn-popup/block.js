/**
 * BLOCK: Pop-Up
 */

// Block dependencies
import classnames from 'classnames';
import defineClassNames from '../utilities/defineClasses';
import Inspector from './inspector';
import attributes from './attributes';

// Import all of our Container Options requirements.
import ContainerOptions, {
	ContainerOptionsAttributes,
	HideSectionEdit,
	BlockIdEdit,
} from '../components/container-options';

import { colors } from "../components/colors/colorUtils";

import { expand } from '@wordpress/icons';

// Components
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks
const { withInstanceId } = wp.compose;

// Register editor components
const {
	InspectorControls,
	RichText,
	getColorObjectByColorValue,
	InnerBlocks,
} = wp.blockEditor;

const blockClasses = classnames(
	'popup-container',
);

// Register the block
registerBlockType( 'nlsn-blocks/nlsn-popup', {
	title: __( 'Popup - NLSN', 'nlsn-blocks' ),
	description: __( 'Popup container block. Insert a button that displays the content added to this block inside of a popup window.', 'nlsn-blocks' ),
	icon: expand,
	category: 'nielsen-blocks',
	keywords: [
		__( 'popup', 'nlsn-blocks' ),
		__( 'container', 'nlsn-blocks' ),
		__( 'Nielsen', 'nlsn-blocks' ),
	],
	attributes: {
		...attributes,
		...ContainerOptionsAttributes,
	},

	/**
	 * Determines what is displayed in the editor.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 */
	edit: withInstanceId (
		props => {

		// Setup the attributes
		const {
			attributes: {
				buttonText,
				buttonColor,
				buttonAlign,
				containerSettings,
			},
			isSelected,
			className,
			setAttributes,
			instanceId,
		} = props;

		const classes = defineClassNames( props, 'popup' );

		// get color object
		const buttonColorObject = getColorObjectByColorValue( colors, buttonColor );
		let buttonColorName = '';

		( buttonColorObject && buttonColorObject !== undefined ? (
			// get 'slug' value from color object
			buttonColorName = buttonColorObject.slug
		) : null )

		props.attributes.popupItemId = 'popup-item-' + instanceId;

		return (
			<div key="editor-display" className={ className }>

				{ isSelected &&
					<InspectorControls>
						<ContainerOptions
							{ ...props }
						/>
						<Inspector
							{ ...props }
						/>
					</InspectorControls>
				}

				{ containerSettings &&
					<div className="container-settings">
						<BlockIdEdit
							{ ...props }
						/>
						<HideSectionEdit
							{ ...props }
						/>
					</div>
				}

				<div className={ classes.container } id={ classes.id }>
					<div className="container">
						<div className="row justify-content-center">
							<div className={ classes.width }>
								<div className={ classnames( blockClasses ) }>

									<div
										className="popup-button"
										style={ { textAlign:`${ buttonAlign }`,
										} }
									>

										<div
											style={ { display: 'inline-block' } }
										>
											<RichText
												tagName='p'
												multiline='false'
												className={ classnames( 'content-button', 'btn', 'btn-popup', `btn-${ buttonColorName }` ) }
												placeholder={ __( 'Button Text', 'nlsn-blocks' ) }
												value={ buttonText }
												onChange={ buttonText => setAttributes( { buttonText } ) }
											/>
										</div>
									</div>

									<div className="popup-content">
										<InnerBlocks />
									</div>

								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		)
	} ),

	// Save the attributes and markup
	save: function( props ) {
		// Setup the attributes
		const {
			attributes: {
				buttonText,
				buttonColor,
				buttonAlign,
				popupItemId,
			},
			className,
		} = props;

		const classes = defineClassNames( props, 'popup', 'save' );

		// get color object
		const buttonColorObject = getColorObjectByColorValue( colors, buttonColor );
		let buttonColorName = '';

		( buttonColorObject && buttonColorObject !== undefined ? (
			// get 'slug' value from color object
			buttonColorName = buttonColorObject.slug
		) : null )

		return (
			<div className={ className }>
				<div
					id={ classes.id }
					className={ classes.container }
				>
					<div className="container">
						<div className="row justify-content-center">
							<div className={ classes.width }>
								<div className={ classnames( blockClasses ) }>

									<div className="popup-button" style={ { textAlign:`${ buttonAlign }` } }>
										{ ( buttonText && buttonText.length > 0 ) ? (
											<RichText.Content
												tagName='a'
												className={ classnames( 'content-button', 'btn', 'btn-popup', `btn-${ buttonColorName }` ) }
												href={ '#' + popupItemId }
												value={ buttonText }
											/>
										) : null }
									</div>

									<div
										id={ popupItemId }
										className="popup-content container mfp-hide"
									>
										<div className="module alignfull not-alignfull bg-white">
											<div className="container">
												<div className="row">
													<div className="col">
														<InnerBlocks.Content />
													</div>
												</div>
											</div>
										</div>
									</div>

								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		);
	},

} );
