const attributes = {
	buttonText: {
		type: 'string',
		source: 'html',
		selector: '.content-button',
	},
	buttonColor: {
		type: 'string',
	},
	buttonAlign: {
		type: 'string',
		default: 'left',
	},
	popupItemId: {
		type: 'string',
	},
};

export default attributes;
