/**
 * Declare the blocks you'd like to style.
 * Customize the arrays below for each style variation.
 */

wp.blocks.registerBlockStyle( 'nlsn-blocks/nlsn-button', [
	{
		name: 'btn-outline',
		label: 'Transparent Button with Outline',
	},
	{
		name: 'btn-outline-inactive',
		label: 'Transparent Button with no Outline',
	},
] );

wp.blocks.registerBlockStyle( 'nlsn-blocks/nlsn-columns', [
	{
		name: 'hero-bar',
		label: 'Split Hero Full Width',
	},
] );

wp.blocks.registerBlockStyle( 'nlsn-blocks/nlsn-blockquote', [
	{
		name: 'font-large',
		label: 'Large Font',
	},
	{
		name: 'font-larger',
		label: 'Larger Font',
	},
] );
