// Dependencies
import classNames from 'classnames';
import {
	BackgroundOptionsClasses,
	BlockPaddingClasses,
	BlockWidthClasses,
	HideSectionSave,
	TextOptionsClasses,
	MarginOptionsClasses,
	BorderOptionsClasses,
	HeroOptionsClasses,
	DirectionalArrowClasses,
} from '../components/container-options';
import { colors } from '../components/colors/colorUtils';
const { getColorObjectByColorValue } = wp.blockEditor;

// Configuration
const defaults = {
	container: [
		'module',
		'alignfull',
	],
};

// This checks if the block requires an alignment class, then returns the classname based on the active attributes.
const applyTextAlignmentClassNames = ( props, block ) => {
	const { align } = props.attributes;

	const blocksThatNeedAlignmentClass = [
		'blockquote',
		'pop-up-video',
		'pop-up-block',
		'profile',
	];

	if ( blocksThatNeedAlignmentClass.indexOf( block ) !== -1 ) {
		return (
			classNames( {
				[ `text-${ align }` ]: ( align === 'left' || align === 'center' || align === 'right' ),
			} )
		);
	}

	return null;
};

// Check if this block uses a custom color palette in their attributes.
const applyColorClassNames = ( props, block ) => {
	const { attributes } = props;

	const blocksThatUseColorClasses = [
		'info-box',
		'banner',
	];

	const attributeToCheck = ( block === 'info-box' ) ? 'border' : 'highlight';

	if ( blocksThatUseColorClasses.indexOf( block ) !== -1 ) {
		return (
			classNames(
				( undefined !== getColorObjectByColorValue( colors, attributes[ attributeToCheck ].color ) ? (
				    `theme-${ getColorObjectByColorValue( colors, attributes[ attributeToCheck ].color).slug }`
				  ) : null ),
			)
		);
	}
};

// Some blocks have a class of 'col-md-12' if none is set by container settings, and some do not. This determines whether or not it should be added since the logic is shared across many blocks.
const checkIfDefaultWidthClassIsNeeded = ( classObject, block ) => {
	const blocksThatDontNeedDefaultWidthClass = [
		'info-box',
	];

	// If the block does need the 'col-md-12' class by default AND the classes that are already assigned do NOT include anu Bootstrap 'col' classes, return true. Otherwise, return false.
	return (
		blocksThatDontNeedDefaultWidthClass.indexOf( block ) === -1 &&
		classObject.width.split( ' ' ).every( existingClass => {
			return ( existingClass.indexOf( 'col' ) === -1 );
		} )
	);
};

// This is the last function to be executed. If you want to make changes to the classes for a specific block this is the place to do it. If you want to add a new block just add it to the conditional chain.
const addBlockSpecificClasses = ( classObject, props, block ) => {
	const { attributes } = props;

	classObject.highlight = applyColorClassNames( props, block );

	if ( block === 'info-box' ) {
		classObject.width = classNames(
			'd-flex',
			'align-items-center',
			'box-container',
			classObject.width,
		);
		classObject.infoBox = classNames(
			'info-box',
			classObject.highlight,
		);
		classObject.iconBox = classNames(
			'icon',
			{
				lightbulb: ( 'fact' === attributes.type ),
				quotes: ( 'blockquote' === attributes.type ),
			}
		);
	} else if ( block === 'container' ) {
		classObject.container = classNames(
			...HeroOptionsClasses( props ),
			...BorderOptionsClasses( props ),
			...MarginOptionsClasses( props ),
			classObject.container,
		);
	}

	classObject.width = classNames(
		classObject.width,
		{
			'col-md-12': checkIfDefaultWidthClassIsNeeded( classObject, block ),
		}
	);

	classObject.align = applyTextAlignmentClassNames( props, block );

	return classObject;
};

// This is the function that is called from each block's Javascript code. This will set the default classes and container option classes that are shared between all blocks before intiating the addBlockSpecificClasses function.
const defineClassNames = ( props, block, view = 'edit' ) => {
	const { attributes } = props;
	const frontEndView = ( view === 'save' );
	const custom = {
		container: [],
		width: [],
	};

	// If containerSettings is enabled, use the following classes...
	if ( attributes.containerSettings ) {
		if ( frontEndView ) {
			custom.container = classNames(
				...HideSectionSave( props ),
				...BackgroundOptionsClasses( props ),
				...BlockPaddingClasses( props ),
				...TextOptionsClasses( props ),
				...DirectionalArrowClasses ( props ),
			);
		} else {
			custom.container = classNames(
				...BackgroundOptionsClasses( props ),
				...BlockPaddingClasses( props ),
				...TextOptionsClasses( props ),
				...DirectionalArrowClasses ( props ),
			);
		}
		custom.width = classNames(
			...BlockWidthClasses( props ),
		);
	}

	// Combine our default classes with any custom classes.
	const final = {
		id: classNames( {
			[ attributes.blockId ]: ( attributes.blockId ),
			'': ( ! attributes.blockId ),
		} ),
	};

	const margin = attributes.marginBottom;

	final.container = classNames(
		defaults.container,
		custom.container,
	);

	final.width = classNames(
		custom.width,
	);

	final.styles = {
		minHeight: ( attributes.minHeight ? attributes.minHeight : '0' ),
		...( attributes.marginBottom !== 75 && attributes.negativeMargin !== false && { marginBottom : -Math.abs(margin) } ),
	};

	return addBlockSpecificClasses( final, props, block );
};

export default defineClassNames;
