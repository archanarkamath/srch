/**
 * BLOCK: Embed
 */

// Block dependencies
import classnames from 'classnames';
import defineClassNames from '../utilities/defineClasses';
import Inspector from './inspector';
import attributes from './attributes';
import icon from './icon';

// Import all of our Container Options requirements.
import ContainerOptions, {
	ContainerOptionsAttributes,
	HideSectionEdit,
	HideSectionSave,
	BlockIdEdit,
	BlockIdSave,
	BackgroundOptionsClasses,
	BlockPaddingClasses,
	BlockWidthClasses,
} from '../components/container-options';

//  Import CSS.
// import './editor.scss';

// Components
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks

// Register editor components
const {
	InspectorControls,
	PlainText,
} = wp.blockEditor;

const blockClasses = classnames(
	'embed-shortcode',
);

// Register: Embed
registerBlockType( 'nlsn-blocks/nlsn-embed', {
	title: __( 'Embed Shortcode - NLSN', 'nlsn-blocks' ),
	description: __( 'Embed content pulled from other sites using shortcodes.', 'nlsn-blocks' ),
	icon: icon,
	category: 'nielsen-blocks',
	keywords: [
		__( 'embed', 'nlsn-blocks' ),
		__( 'iframe', 'nlsn-blocks' ),
		__( 'nielsen', 'nlsn-blocks' ),
	],
	attributes: {
		...attributes,
		...ContainerOptionsAttributes,
	},

	/**
	 * Determines what is displayed in the editor.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 */
	edit: props => {
		const {
			attributes: {
				embedType,
				embedURL,
				embedHeight,
				embedWidth,
				containerSettings,
			},
			isSelected,
			className,
			setAttributes,
		} = props;

		const classes = defineClassNames( props, 'embed-shortcode' );

		// Return the markup displayed in the editor.
		return (
			<div key="editor-display" className={ className }>

				{ isSelected &&
					<InspectorControls>
						<ContainerOptions
							{ ...props }
						/>
						<Inspector
							{ ...props }
						/>
					</InspectorControls>
				}

				{ containerSettings &&
					<div className="container-settings">
						<BlockIdEdit
							{ ...props }
						/>
						<HideSectionEdit
							{ ...props }
						/>
					</div>
				}

				<div className={ classes.container } id={ classes.id }>
					<div className='container'>
						<div className='row justify-content-center'>
							<div className={ classes.width }>

								<div className={ classnames( blockClasses ) }>
									<label>
										{( `[embed_${ embedType }]` ) }
									</label>
									<PlainText
										className={ classnames(
											'embed-url'
										) }
										placeholder={ __( 'Add Embed URL', 'nlsn-blocks' ) }
										value={ unescape( embedURL ) }
										onChange={ ( embedURL ) => setAttributes( { embedURL: escape( embedURL ) } ) }
									/>
								</div>

							</div>
						</div>
					</div>
				</div>
			</div>
		)
	},

	/**
	 * Determines what is displayed on the front-end.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 */
	save: props => {
		const {
			attributes: {
				embedType,
				embedURL,
				embedHeight,
				embedWidth,
			},
			className,
		} = props;

		const classes = defineClassNames( props, 'embed-shortcode', 'save' );

		const embedMediaSelect = () => {
			if ( 'media' !== embedType ) {
				return '';
			}

			return (
				<div className='embed-responsive embed-responsive-16by9'>
					<div className='embed-iframe embed-responsive-item'>
						[embed]{ unescape( embedURL ) }[/embed]
					</div>
				</div>
			);
		};

		const embedIframeSelect = () => {
			if ( 'iframe' !== embedType ) {
				return '';
			}

			return (
				<iframe
					className='embed-iframe'
					src={ unescape( embedURL ) }
					width='100%'
					height={ embedHeight ? embedHeight : '' }
					allow='autoplay; encrypted-media'
					allowfullscreen='true'
					frameborder='0'
				>
				</iframe>
			);
		};

		// Return the markup displayed on the front-end.
		return (
			<div className={ className }>
				<div
					id={ classes.id }
					className={ classes.container }
				>

					<div className='container'>
						<div className='row justify-content-center'>
							<div className={ embedWidth }>

								<div className={ classnames( blockClasses ) }>
										{ embedIframeSelect() }
										{ embedMediaSelect() }
								</div>

							</div>
						</div>
					</div>

				</div>
			</div>
		);
	},

	/**
	 * Provide a “deprecated” version of the block.
	 * This allows users opening these blocks in Gutenberg to edit them using the updated block.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/deprecated-blocks/
	 */
	deprecated: [
		{
			attributes: {
				...attributes,
				...ContainerOptionsAttributes,
			},
			save: props => {
				const {
					attributes: {
						embedType,
						embedURL,
						embedHeight,
						embedWidth,
					},
					className,
				} = props;

				const classes = defineClassNames( props, 'embed-shortcode', 'save' );

				const embedMediaSelect = () => {
					if ( 'media' !== embedType ) {
						return '';
					}

					return (
						<div className='embed-responsive embed-responsive-16by9'>
							<div className='embed-iframe embed-responsive-item'>
								[embed]{ embedURL }[/embed]
							</div>
						</div>
					);
				};

				const embedIframeSelect = () => {
					if ( 'iframe' !== embedType ) {
						return '';
					}

					return (
						<iframe
							className='embed-iframe'
							src={ embedURL }
							width='100%'
							height={ embedHeight ? embedHeight : '' }
							allow='autoplay; encrypted-media'
							allowfullscreen='true'
							frameborder='0'
						>
						</iframe>
					);
				};

				// Return the markup displayed on the front-end.
				return (
					<div className={ className }>
						<div
							id={ classes.id }
							className={ classes.container }
						>

							<div className='container'>
								<div className='row justify-content-center'>
									<div className={ embedWidth }>

										<div className={ classnames( blockClasses ) }>
											{ embedIframeSelect() }
											{ embedMediaSelect() }
										</div>

									</div>
								</div>
							</div>

						</div>
					</div>
				);
			},
		},
	],
} );
