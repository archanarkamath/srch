const attributes = {
	embedType: {
		type: 'string',
		default: 'media',
	},
	embedURL: {
		type: 'string',
		default: '',
	},
	embedHeight: {
		type: 'number',
		default: 0,
	},
	embedWidth: {
		type: 'string',
		default: 'col-md-12'
	},
};

export default attributes;
