/**
 * Internal block libraries
 */
const { __ } = wp.i18n;
const { Component } = wp.element;

const {
  PanelBody,
	PanelRow,
  SelectControl,
	RangeControl,
} = wp.components;

/**
 * Create an Inspector Controls wrapper Component
 */
export default class Inspector extends Component {

  constructor() {
    super( ...arguments );
  }

  render() {
    const { attributes: { embedType, embedHeight, embedWidth }, setAttributes } = this.props;

    return (
			<PanelBody
				title={ __( 'Embed Settings', 'nlsn-blocks' ) }
				initialOpen={ true }
			>

				<PanelRow>
					<SelectControl
						key="embed-type"
						label={ __( 'Embed Type', 'nlsn-blocks' ) }
						value={ embedType }
						options={ [
							{
								label: __( 'Media', 'nlsn-blocks' ),
								value: 'media',
							},
							{
								label: __( 'Other', 'nlsn-blocks' ),
								value: 'iframe',
							},
						] }
						onChange={ embedType => setAttributes( { embedType } ) }
					/>
				</PanelRow>

				{ 'iframe' === embedType ? (
					<div>
						<RangeControl
							label='iFrame Height in pixels'
							value={ embedHeight }
							onChange={ embedHeight => setAttributes( { embedHeight } ) }
							min={ 0 }
							max={ 3000 }
						/>
						<SelectControl
							label={ __( 'iFrame Width', 'nlsn-blocks' ) }
							value={ embedWidth }
							options={ [
								{
									label: __( 'Full-Width (100%)', 'nlsn-blocks' ),
									value: 'col-md-12',
								},
								{
									label: __( 'Medium (75%)', 'nlsn-blocks' ),
									value: 'col-md-8',
								},
								{
									label: __( 'Small ( 50%)', 'nlsn-blocks' ),
									value: 'col-md-6',
								},
							] }
							onChange={ embedWidth => setAttributes( { embedWidth } ) }
						/>
					</div>
				) : null }

			</PanelBody>
    );
  }
}
