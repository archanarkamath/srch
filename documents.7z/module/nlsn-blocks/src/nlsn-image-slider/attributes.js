const attributes = {
	images: {
		type: 'array',
		default: [],
	},
	blockInstanceId: {
		type: 'text',
	},
};

export default attributes;
