/**
 * BLOCK: Slider
 */

// Block dependencies
import classnames from 'classnames';
import defineClassNames from '../utilities/defineClasses';
import tabsBlockIcon from './icon';
import attributes from './attributes';

// Import all of our Container Options requirements.
import ContainerOptions, {
	ContainerOptionsAttributes,
	HideSectionEdit,
	HideSectionSave,
	BlockIdEdit,
	BlockIdSave,
	BackgroundOptionsClasses,
	BlockPaddingClasses,
	BlockWidthClasses,
} from '../components/container-options';

//  Import CSS.
// import './editor.scss';

// Components
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks
const { withInstanceId } = wp.compose;

// Register editor components
const {
  InspectorControls,
  InnerBlocks,
} = wp.blockEditor;

const BLOCK_TEMPLATE = [
	[ 'nlsn-blocks/nlsn-tab', {} ],
];

const ALLOWED_BLOCKS = [
	'nlsn-blocks/nlsn-tab',
];

const blockClasses = classnames(
	`tab-panel`,
	`tabbed-navigation`
);

// Register: Container Block.
registerBlockType( 'nlsn-blocks/nlsn-tabs-container', {
  title: __( 'Tabs Container - NLSN', 'nlsn-blocks' ),
  description: __( 'Tabs Container - A tabs container block. Tab blocks are added inside this container and they should all be the same.', 'nlsn-blocks' ),
  tabsBlockIcon,
  category: 'nielsen-blocks',
  keywords: [
    __( 'tabs', 'nlsn-blocks' ),
    __( 'container', 'nlsn-blocks' ),
    __( 'nielsen', 'nlsn-blocks' ),
  ],
  attributes: {
    ...attributes,
    ...ContainerOptionsAttributes,
  },

  /**
   * Determines what is displayed in the editor.
   * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
   */
  edit: withInstanceId(
  	props => {

    const {
      attributes: {
        containerSettings,
        tabsContainerId,
      },
      isSelected,
      className,
      setAttributes,
      instanceId,
    } = props;

		const classes = defineClassNames( props, 'tabs-container' );

		setAttributes( { tabsContainerId: `tab-content-${ instanceId }` } )

    // Return the markup displayed in the editor.
    return [
      isSelected && (
        <InspectorControls>
          <ContainerOptions
            { ...props }
          />
        </InspectorControls>
      ),

			<div key="editor-display" className={ className }>

				{ containerSettings &&
					<div className="container-settings">
						<BlockIdEdit
							{ ...props }
						/>
						<HideSectionEdit
							{ ...props }
						/>
					</div>
				}

				<div className={ classes.container } id={ classes.id }>
          <div className='container'>
            <div className='row justify-content-center'>
							<div className={ classes.width }>

								<div className={ classnames( blockClasses ) } >
									<div className={ classnames('nav-tabs justify-content-center')}>
										<InnerBlocks
											template={ BLOCK_TEMPLATE }
										  allowedBlocks={ ALLOWED_BLOCKS }
										/>
									</div>
								</div>

              </div>
            </div>
          </div>

        </div>
      </div>
    ];
  }),

  /**
   * Determines what is displayed on the front-end.
   * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
   */
  save: props => {
    const {
      attributes: {
        tabsContainerId,
      },
      className,
    } = props;

		const classes = defineClassNames( props, 'tabs-container', 'save' );

    // Return the markup displayed on the front-end.
    return (
      <div className={ className }>

        <div
					id={ classes.id }
					className={ classes.container }
        >
          <div className='container'>
            <div className='row justify-content-center'>
							<div className={ classes.width }>

                <div id={tabsContainerId} className={ classnames( blockClasses ) } role='tabpanel'>

                  <ul className={ classnames('nav nav-tabs justify-content-center')} role='tablist'>
                    <InnerBlocks.Content/>
                  </ul>

                  <div id={tabsContainerId} className={ classnames('tab-content')}>
                  </div>

                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    );
  },

  deprecated: [
		{

		},
  ]
} );
