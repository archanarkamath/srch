const attributes = {
  tabsContainerId: {
    type: 'text', 
  }
};

export default attributes;
