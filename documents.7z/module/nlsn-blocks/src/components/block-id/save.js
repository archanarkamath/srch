/**
 * Set 'save' inline ID attribute
 * @param {object} props - The block object.
 * @return {array} The inline CSS class.
 */

// Value to be used on 'Save'
function BlockIdSave( props ) {
	return[
		props.attributes.blockId
	];
}
export default BlockIdSave;
