/**
 * Set the attributes for the Block Id panel.
 * @type {Object}
 */
const BlockIdAttributes = {
	blockId: {
		type: 'string',
	},
};

export default BlockIdAttributes;
