/**
 * WordPress dependencies
 */
const { __ } = wp.i18n;

const {
} = wp.editor;

const {
	PanelBody,
	PanelRow,
	TextControl,
} = wp.components;

/**
 * Internal dependencies
 */
import BlockIdAttributes from './attributes';
import BlockIdEdit from './edit';
import BlockIdSave from './save';

// Export for ease of importing in individual blocks.
export {
	BlockIdAttributes,
	BlockIdEdit,
	BlockIdSave,
};

// Component Options for export
function BlockIdOptions( props ) {

	const setBlockId = value => props.setAttributes( { blockId: value } );

	return (
		<PanelBody>
			<PanelRow>
				<TextControl
					label={ __( 'Block ID', 'nlsn-blocks' ) }
					help={ __( 'Must be unique. Use lowercase letters, no spaces. eg: section-1, main-section', 'nlsn-blocks' ) }
					value={ props.attributes.blockId }
					onChange={ setBlockId }
				/>
			</PanelRow>
		</PanelBody>
	);
}
export default BlockIdOptions;
