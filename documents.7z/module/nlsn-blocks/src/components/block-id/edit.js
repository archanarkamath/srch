/**
 * Set 'edit' blockId output.
 * @param {object} props - The block object.
 * @return {string} The markup.
 */

// Edit Options for export
function BlockIdEdit( props ) {
	return(
		<div className='block-section-id'>
			{ props.attributes.blockId }
		</div>
	);
}
export default BlockIdEdit;
