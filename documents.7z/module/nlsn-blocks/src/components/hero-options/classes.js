/**
 * Set the CSS classes used for the Hero Class settings in the Inspector Controls
 * @param {object} props - The block object.
 * @return {array} The inline CSS class.
 */

function HeroOptionsClasses( props ) {
	const {
		attributes: {
			heroClass,
		},
	} = props;

	return [
		{
			'hero-container': ( heroClass ),
		},
	];
}

export default HeroOptionsClasses;
