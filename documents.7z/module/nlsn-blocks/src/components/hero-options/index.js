/**
 * WordPress dependencies
 */
const { __ } = wp.i18n;

// const {
//   ColorPalette,
// } = wp.editor;

const {
	PanelBody,
	PanelRow,
	// PanelColor,
	ToggleControl,
} = wp.components;

/**
 * Internal dependencies
 */
import HeroOptionsAttributes from './attributes';
import HeroOptionsClasses from './classes';

// Export for ease of importing in individual blocks.
export {
	HeroOptionsAttributes,
	HeroOptionsClasses,
};

// Component Options for export
function HeroOptions( props ) {
	const {
		attributes: {
			heroClass,
		},
		setAttributes,
	} = props;

	// METHODS
	const updateAttribute = ( element, updatedValue ) => {
		setAttributes( { [ element ]: updatedValue } );
	};

	return (
		<PanelBody
			title={ __( 'Hero Class Options', 'nlsn-blocks' ) }
			className="nlsn-hero-class-options"
			initialOpen={ true }
		>
			<PanelRow>
				<ToggleControl
					label={ __( 'Add Hero class to the container block', 'nlsn-blocks' ) }
					checked={ heroClass }
					onChange={ ( value ) => updateAttribute( 'heroClass', value ) }
					help={ ( checked ) => checked ? __( 'Hero Class Enabled.', 'nlsn-blocks' ) : __( 'Hero Class Disabled.', 'nlsn-blocks' ) }
				/>
			</PanelRow>
		</PanelBody>
	);
}

export default HeroOptions;
