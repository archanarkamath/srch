const HeroOptionsAttributes = {
	heroClass: {
		type: 'boolean',
		default: false,
	},
};

export default HeroOptionsAttributes;
