/**
 * WordPress dependencies
 */
const { __ } = wp.i18n;

const {
	PanelColorSettings,
} = wp.blockEditor;

const {
	Button,
	ButtonGroup,
	PanelBody,
	PanelRow,
	SelectControl,
	BaseControl,
	ToggleControl,
} = wp.components;

/**
 * Internal dependencies
 */
 import DirectionalArrowAttributes from './attributes';
import DirectionalArrowClasses from './classes';

// Export for ease of importing in individual blocks.
export {
	DirectionalArrowAttributes,
	DirectionalArrowClasses
};

// Component Options for export
function DirectionalArrowOptions( props ) {

	const {
		attributes: {
			horizontalAlignType,
			verticalAlignType,
			arrowColor,
			arrowSize,
	},
		setAttributes,
	} = props;

	// METHODS

	const updateAttribute = ( element, updatedValue ) => {
		setAttributes( { [ element ]: updatedValue } );
	};

	// Background options
	const options = {
		horizontalAlignOptions: [
			{ label: 'None',   value: 'none' },
			{ label: 'Left',   value: 'left' },
			{ label: 'Right',  value: 'right' },
			{ label: 'Top',    value: 'top' },
			{ label: 'Bottom', value: 'bottom' },
		],
		verticalAlignOptions: [
			{ label: 'Initial',    value: 'initial' },
			{ label: 'Middle',     value: 'middle' },
			{ label: 'End',        value: 'end' },
		],
		arrowSizeOptions:[
			{ label: __( 'Arrow Thin (5px)', 'nlsn-blocks' ),	value: 'thin', },
			{ label: __( 'Arrow Slender (10px)', 'nlsn-blocks' ), value: 'slender', },
			{ label: __( 'Arrow Slim (15px)', 'nlsn-blocks' ), value: 'slim', },
			{ label: __( 'Arrow Small (20px)', 'nlsn-blocks' ),	value: 'small', },
			{ label: __( 'Arrow Normal (25px)', 'nlsn-blocks' ),	value: 'normal', },
			{ label: __( 'Arrow Thick (50px)', 'nlsn-blocks' ),	value: 'thick', },
		],
	};

	//Arrow color Options
	const arrowBackgroundColorSelectionPanel = () => {
		return (
			<PanelRow>
				<PanelColorSettings
					title={ __( 'Arrow Color Settings', 'nlsn-blocks' ) }
					colorSettings={ [
						{
							value: arrowColor,
							onChange: ( value ) => setAttributes( { arrowColor: value } ),
							label: __( 'Arrow Color', 'nlsn-blocks' ),
						},
					] }
				>
				</PanelColorSettings>
			</PanelRow>
		);
	};

	//Arrow size Options
	const setArrowSize = value => props.setAttributes( { arrowSize: value } );

	const arrowSizeOption = () => {
		return (
			<PanelRow>
				<SelectControl
					label={ __( 'Arrow Size', 'nlsn-blocks' ) }
					value={ props.attributes.arrowSize ? props.attributes.arrowSize : '' }
					options={ options.arrowSizeOptions }
					onChange={ setArrowSize }
				/>
			</PanelRow>
		);
	};

  //Arrow position options
	const verticalAlignmentSelectionPanel = () => {
		return (
			<PanelRow>
					<div>
					 <BaseControl id="vertical-type" label={ __( 'Arrow Position' ) }>
						 <ButtonGroup
							 id="vertical-type"
							 aria-label={ __( 'Vertical Alignment', 'nlsn-blocks' ) }
							 className="vertical-type"
							 style={ { display: 'block' } }
						 >
							 { options.verticalAlignOptions.map( ( type ) => {
								 return (
									 <Button
										 key={ type.label }
										 isPrimary={ verticalAlignType === type.value }
										 aria-pressed={ verticalAlignType === type.value }
										 onClick={ () => updateAttribute( 'verticalAlignType', type.value ) }
									 >
										 { type.label }
									 </Button>
								 );
							 } ) }
						 </ButtonGroup>
					 </BaseControl>
				 </div>
			</PanelRow>
		);
	};

  //Arrow direction options
	return (
		<PanelBody
			title={ __( 'Directional Arrow Options', 'nlsn-blocks' ) }
			className="nlsn-direction-options"
			initialOpen={ true }
		>
			<PanelRow>
				<BaseControl id="direction-type" label={ __( 'Arrow Direction' ) }>
					<ButtonGroup
						id="direction-type"
						aria-label={ __( 'Horizontal Alignment', 'nlsn-blocks' ) }
						className="direction-type"
						style={ { display: 'block' } }
					>
						{ options.horizontalAlignOptions.map( ( type ) => {
							return (
								<Button
									key={ type.label }
									isPrimary={ horizontalAlignType === type.value }
									aria-pressed={ horizontalAlignType === type.value }
									onClick={ () => updateAttribute( 'horizontalAlignType', type.value ) }
								>
									{ type.label }
								</Button>
							);
						} ) }
					</ButtonGroup>
				</BaseControl>
			</PanelRow>
			<PanelRow>
				{ ( 'none' !== horizontalAlignType ) &&
					verticalAlignmentSelectionPanel()
				}
			</PanelRow>

			{ ( 'none' !== horizontalAlignType ) &&
				arrowSizeOption()
			}
			{ ( 'none' !== horizontalAlignType ) &&
				arrowBackgroundColorSelectionPanel()
			}
		</PanelBody>
	);
}
export default DirectionalArrowOptions;
