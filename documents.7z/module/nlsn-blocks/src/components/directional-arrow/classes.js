/**
 * Set the CSS classes used for the Directional arrow settings in the Inspector Controls
 * @param {object} props - The block object.
 * @return {array} The inline CSS class.
 */

 // Dependencies
 import { colors } from '../colors/colorUtils';

 // Register editor components
 const { getColorObjectByColorValue } = wp.blockEditor;

function DirectionalArrowClasses( props ) {
	const {
		attributes: {
			horizontalAlignType,
			verticalAlignType,
			arrowSize,
			arrowColor,
		},
	} = props;

	const arrowColorName = getColorObjectByColorValue( colors, props.attributes.arrowColor );

	let hArrowAlignType = ( 'none' !== props.attributes.horizontalAlignType ) ? `arrow-${props.attributes.horizontalAlignType}` : null;

	let vArrowAlignType = ( 'none' !== props.attributes.horizontalAlignType ) ? hArrowAlignType + `-${props.attributes.verticalAlignType}` : null;

	let arrowThickness = ( 'none' !== props.attributes.horizontalAlignType ) ? hArrowAlignType + `-${props.attributes.arrowSize}` : null;

	let arrowHexCode = ( 'none' !== props.attributes.horizontalAlignType && undefined !== arrowColorName ) ? hArrowAlignType + `-${ arrowColorName.slug }-${props.attributes.arrowSize}` : null;

	return [
		hArrowAlignType,
		vArrowAlignType,
		arrowThickness,
		arrowHexCode,
	];
}

export default DirectionalArrowClasses;
