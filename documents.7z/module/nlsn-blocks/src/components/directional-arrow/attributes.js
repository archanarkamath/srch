/**
 * Set the attributes for the Block Padding panel.
 * @type {Object}
 */
 const DirectionalArrowAttributes = {

 	horizontalAlignType: {
 		type: 'string',
 		default: 'none',
 	},
 	verticalAlignType: {
 		type: 'string',
    default:'middle',
 	},
 	arrowSize: {
 		type: 'string',
    default: 'thick',
 	},
	arrowColor: {
 		type: 'string',

 	},
 };

 export default DirectionalArrowAttributes;
