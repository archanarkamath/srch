/**
 * Set inline CSS style.
 * @param {object} props - The block object.
 * @return {array} The inline CSS style.
 */

function MinHeightStyles( props ) {
	return [
		// returns classes
		props.attributes.minHeight,
	];
}

export default MinHeightStyles;
