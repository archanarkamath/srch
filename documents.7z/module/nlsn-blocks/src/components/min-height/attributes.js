/**
 * Set the attributes for the Minimum Height panel.
 * @type {Object}
 */
const MinHeightAttributes = {
	minHeight: {
		type: 'number',
		default: 0,
	},
};

export default MinHeightAttributes;
