/**
 * WordPress dependencies
 */
const { __ } = wp.i18n;

const {
	PanelBody,
	PanelRow,
	BaseControl,
} = wp.components;

/**
 * Internal dependencies
 */
import MinHeightAttributes from './attributes';
import MinHeightStyles from './styles';

// Export for ease of importing in individual blocks.
export {
	MinHeightAttributes,
	MinHeightStyles,
};

// Component Options for export
function MinHeightOptions( props ) {
	const setMinHeight = value => props.setAttributes( { minHeight: value } );

	return (
		<PanelBody
			title={ __( 'Minimum Height Options', 'nlsn-blocks' ) }
			className="nlsn-height-options"
			initialOpen={ true }
		>
			<PanelRow>
				<BaseControl label={ __( 'Minimum Height in Pixels' ) }>
					<input
						type="number"
						onChange={ ( event ) => {
							props.setAttributes( { minHeight: parseInt( event.target.value, 10 ), } );
						} }
						value={ props.attributes.minHeight }
						min="0"
						step="10"
					/>
				</BaseControl>
			</PanelRow>
		</PanelBody>
	);
}
export default MinHeightOptions;
