/**
 * Set the CSS classes used for the Negative Margin settings in the Inspector Controls
 * @param {object} props - The block object.
 * @return {array} The inline CSS class.
 */

function MarginOptionsClasses( props ) {
	const {
		attributes: {
			negativeMargin,
		},
	} = props;

	return [
		{
			'container-negative-margin': ( negativeMargin ),
		},
	];
}

export default MarginOptionsClasses;