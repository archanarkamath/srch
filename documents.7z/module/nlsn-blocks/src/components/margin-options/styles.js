/**
 * Set inline CSS style.
 * @param {object} props - The block object.
 * @return {array} The inline CSS style.
 */

function MarginOptionsStyles( props ) {
	return [
		// returns inline styles
		props.attributes.marginBottom,
	];
}

export default MarginOptionsStyles;
