/**
 * WordPress dependencies
 */
const { __ } = wp.i18n;

const {
	PanelBody,
	PanelRow,
	ToggleControl,
	RangeControl,
} = wp.components;

const {
	withState,
} = wp.compose;

/**
 * Internal dependencies
 */
import MarginOptionsAttributes from './attributes';
import MarginOptionsClasses from './classes';
import MarginOptionsEdit from './edit';
import MarginOptionsStyles from './styles';

// Export for ease of importing in individual blocks.
export {
	MarginOptionsAttributes,
	MarginOptionsClasses,
	MarginOptionsEdit,
	MarginOptionsStyles,
};

// Component Options for export
function MarginOptions( props ) {
	const {
		attributes: {
			negativeMargin,
			marginBottom,
		},
		setAttributes,
	} = props;

	// METHODS
	const updateAttribute = ( element, updatedValue ) => {
		setAttributes( { [ element ]: updatedValue } );
	};

	const setRangeControl = () => {

		if(negativeMargin){
			return (

				<RangeControl
			        label={ __( 'Negative Margin', 'nlsn-blocks' ) }
			        value={ marginBottom }
			        onChange={ marginBottom => setAttributes( { marginBottom } ) }
			        min={ 0 }
			        max={ 300 }
			        beforeIcon={ 'image-flip-vertical' }
			        help={ __( 'This will be displayed on the site view.', 'nlsn-blocks' ) }
			    />

			)
		}

	};

	return (
		<PanelBody
			title={ __( 'Margin Options', 'nlsn-blocks' ) }
			className="nlsn-negative-margin-options"
			initialOpen={ true }
		>

			<PanelRow>
				<ToggleControl
					label={ __( 'Toggle Negative Margin', 'nlsn-blocks' ) }
					checked={ negativeMargin }
					onChange={ ( value ) => updateAttribute( 'negativeMargin', value ) }
					help={ ( checked ) => checked ? __( 'Negative Margin Enabled.', 'nlsn-blocks' ) : __( 'Negative Margin Disabled.', 'nlsn-blocks' ) }
				/>
			</PanelRow>

			{ setRangeControl() }

		</PanelBody>
	);
}

export default MarginOptions;
