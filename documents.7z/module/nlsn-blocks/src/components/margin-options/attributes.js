const MarginOptionsAttributes = {
	negativeMargin: {
		type: 'boolean',
		default: false,
	},
	marginBottom: {
		type: 'number',
		default: 75,
	},
};

export default MarginOptionsAttributes;
