function MarginOptionsEdit( props ) {
	const marginOptionsCopy = ( props.attributes.negativeMargin ) ? 'Overlap with below block.' : null;

	return (
		<div className="block-margin-options">
			{ marginOptionsCopy }
		</div>
	);
}
export default MarginOptionsEdit;
