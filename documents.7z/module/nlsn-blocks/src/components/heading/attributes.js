const HeadingAttributes = {
	headingContent: {
		type: 'array',
		source: 'children',
		selector: '.heading-content',
	},
	headingLevel: {
		type: 'number',
		default: 3,
	},
	formattingControls: {
		type: 'array',
		default: [ 'bold', 'italic' ]
	}
};

export default HeadingAttributes;
