// Block dependencies
import classNames from 'classnames';

// WordPress dependencies
const { __ } = wp.i18n; // Import __() from wp.i18n

// Editor components
const {
	RichText,
	BlockControls,
} = wp.blockEditor;

// WordPress components
const {
	Toolbar,
} = wp.components;
const {
	Fragment,
} = wp.element;

/**
 * Internal dependencies
 */
import HeadingAttributes from './attributes';
import HeadingLevelDropdown from './heading-level-dropdown';

// Export for ease of importing in individual blocks.
export { HeadingAttributes };

// This object is simply so this component can be referred to in an easy-to-use manner. If it is included in the editor it is "NLSNHeading.edit", and in the front-end it is "NLSNHeading.save".
const NLSNHeading = {
	edit: ( props ) => {
		return headingComponent( props, 'edit' );
	},
	save: ( props ) => {
		return headingComponent( props, 'save' );
	},
};

const headingComponent = ( props, view ) => {
	const {
		attributes: {
			headingContent,
			headingLevel,
		},
		setAttributes,
		headingPlaceholder,
		formattingControls,
		predefinedClasses,
	} = props;

	const tagName = `h${ headingLevel }`;

	if ( view === 'save' ) {
		return (
			<RichText.Content
				className={ classNames( 'heading-content', predefinedClasses ) }
				tagName={ tagName }
				value={ headingContent }
			/>
		);
	}

	return (
		<Fragment>
			<BlockControls>
			<HeadingLevelDropdown
				selectedLevel={ headingLevel }
				onChange={ ( newLevel ) =>
					setAttributes( { headingLevel: newLevel } )
				}
			/>
			</BlockControls>
			<RichText
				className={ classNames( 'heading-content', predefinedClasses ) }
				multiline="false"
				tagName={ tagName }
				value={ headingContent }
				formattingControls={ formattingControls || [ 'bold', 'italic', 'link' ] }
				onChange={ ( value ) => setAttributes( { headingContent: value } ) }
				placeholder={ headingPlaceholder || __( 'Add Title' ) }
			/>
		</Fragment>
	);
};

export default NLSNHeading;
