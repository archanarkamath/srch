/**
 * WordPress dependencies
 */
const { __ } = wp.i18n;

const {
	PanelBody,
	PanelRow,
	SelectControl,
} = wp.components;

/**
 * Internal dependencies
 */
import BlockWidthAttributes from './attributes';
import BlockWidthClasses from './classes';

// Export for ease of importing in individual blocks.
export {
	BlockWidthAttributes,
	BlockWidthClasses,
};

// Component Options for export
function BlockWidthOptions( props ) {
	const setBlockWidth = value => props.setAttributes( { blockWidth: value } );

	return (
		<PanelBody
			title={ __( 'Block Width Options', 'nlsn-blocks' ) }
			className="nlsn-width-options"
			initialOpen={ true }
		>
			<PanelRow>
				<SelectControl
					label={ __( 'Block Width', 'nlsn-blocks' ) }
					value={ props.attributes.blockWidth ? props.attributes.blockWidth : '' }
					options={ [
						{
							label: __( 'Full-Width (100%)', 'nlsn-blocks' ),
							value: 'col-md-12',
						},
						{
							label: __( 'Medium (75%)', 'nlsn-blocks' ),
							value: 'col-md-8',
						},
						{
							label: __( 'Small ( 50%)', 'nlsn-blocks' ),
							value: 'col-md-6',
						},
					] }
					onChange={ setBlockWidth }
				/>
			</PanelRow>
		</PanelBody>
	);
}
export default BlockWidthOptions;
