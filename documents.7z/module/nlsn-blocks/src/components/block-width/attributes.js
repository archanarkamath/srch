/**
 * Set the attributes for the Block Width Options panel.
 * @type {Object}
 */
const BlockWidthAttributes = {
	blockWidth: {
		type: 'string',
	},
};

export default BlockWidthAttributes;
