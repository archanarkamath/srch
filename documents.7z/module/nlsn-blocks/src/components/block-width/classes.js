/**
 * Set inline CSS class.
 * @param {object} props - The block object.
 * @return {array} The inline CSS class.
 */

function BlockWidthClasses( props ) {
	return [
		// returns classes
		props.attributes.blockWidth,
	];
}

export default BlockWidthClasses;
