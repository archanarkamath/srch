const BorderOptionsAttributes = {
	borderTop: {
		type: 'boolean',
		default: false,
	},
};

export default BorderOptionsAttributes;
