/**
 * WordPress dependencies
 */
const { __ } = wp.i18n;

// const {
//   ColorPalette,
// } = wp.editor;

const {
	PanelBody,
	PanelRow,
	// PanelColor,
	ToggleControl,
} = wp.components;

/**
 * Internal dependencies
 */
import BorderOptionsAttributes from './attributes';
import BorderOptionsClasses from './classes';

// Export for ease of importing in individual blocks.
export {
	BorderOptionsAttributes,
	BorderOptionsClasses,
};

// Component Options for export
function BorderOptions( props ) {
	const {
		attributes: {
			borderTop,
		},
		setAttributes,
	} = props;

	// METHODS
	const updateAttribute = ( element, updatedValue ) => {
		setAttributes( { [ element ]: updatedValue } );
	};

	return (
		<PanelBody
			title={ __( 'Border Options', 'nlsn-blocks' ) }
			className="nlsn-border-options"
			initialOpen={ true }
		>
			<PanelRow>
				<ToggleControl
					label={ __( 'Toggle Top Border', 'nlsn-blocks' ) }
					checked={ borderTop }
					onChange={ ( value ) => updateAttribute( 'borderTop', value ) }
					help={ ( checked ) => checked ? __( 'Top Border Enabled.', 'nlsn-blocks' ) : __( 'Top Border Disabled.', 'nlsn-blocks' ) }
				/>
			</PanelRow>
		</PanelBody>
	);
}

export default BorderOptions;
