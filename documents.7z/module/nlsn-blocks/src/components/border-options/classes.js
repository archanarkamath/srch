/**
 * Set the CSS classes used for the Negative Margin settings in the Inspector Controls
 * @param {object} props - The block object.
 * @return {array} The inline CSS class.
 */

function BorderOptionsClasses( props ) {
	const {
		attributes: {
			borderTop,
		},
	} = props;

	return [
		{
			'border-top-blue': ( borderTop ),
		},
	];
}

export default BorderOptionsClasses;
