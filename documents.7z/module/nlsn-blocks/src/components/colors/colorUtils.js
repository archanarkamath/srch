/**
 * Nielsen branding colors
 *
 */

 export const colors = [
	 {
		 name: 'blue',
		 slug: 'blue',
		 color: '#00aeef'
	 },
   {
		 name: 'red',
		 slug: 'red',
		 color: '#dd0014'
	 },
   {
		 name: 'purple',
		 slug: 'purple',
		 color: '#b21dac'
	 },
   {
		 name: 'green',
		 slug: 'green',
		 color: '#8dc63f'
	 },
   {
		 name: 'orange',
		 slug: 'orange',
		 color: '#ffb100'
	 },
   {
		 name: 'dark-gray',
		 slug: 'dark-gray',
		 color: '#3e484e'
	 },
   {
		 name: 'gray',
		 slug: 'gray',
		 color: '#8b959b'
	 },
   {
		 name: 'light-gray',
		 slug: 'light-gray',
		 color: '#e4e8eb'
	 },
   {
		 name: 'lighter-gray',
		 slug: 'lighter-gray',
		 color: '#f8f9fa'
	 },
   {
		 name: 'white',
		 slug: 'white',
		 color: '#ffffff'
	 },
]

/**
 * Returns a color name based on the nielsen branding colors array
 *
 *
 * @param {string} colors
    The nielsen colors array
 * @param {string} colorHex
    The hex value of the color. Could be stored into a variable. (i.e., backgroundColor = '#00aeef')
 *
 * @return {string}
    Actual name of the corresponding hex value provided
    getColorObjectByColorValue( colors, '#f8f9fa' ).slug returns 'lighter-gray'
 */

export const getNielsenColorName = ( colors, colorHex ) => {
  console.log("colors")
  console.log(colors)
	console.log('colorHex: ' + colorHex );
	if ( colorHex === undefined ) {
		colorHex = '#ffffff'
	}
  var color = colors.filter(color => color.color === colorHex )
  console.log("color in getNielsenColorName: " + color)
  return color ? color[0].name : undefined
};

/**
 * Returns an array of hex values based on the nielsen branding colors array. This is primarily used for the ColorPalette component which only receives an array of hex values.
 *
 *
 * @param {string} colors
    The nielsen colors array
 *
 * @return {string}
    Array of hex values:
    ["#00aeef", "#dd0014", "#b21dac", "#8dc63f", "#ffb100", "#3e484e", "#8b959b", "#e4e8eb", "#f8f9fa"]
 */

export const getNielsenColors = () => {
  var nielsenHexColorsArray = colors.map( color => {
    return color.color
  })
  return nielsenHexColorsArray
};
