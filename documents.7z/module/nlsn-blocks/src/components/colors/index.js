const theme_colors =  [
{
	'name'  : 'blue',
	'color' : '#00aeef',
},
{
	'name'  : 'red',
	'color' : '#dd0014',
},
{
	'name'  : 'purple',
	'color' : '#b21dac',
},
{
	'name'  : 'green',
	'color' : '#8dc63f',
},
{
	'name'  : 'orange',
	'color' : '#ffb100',
},
{
	'name'  : 'dark-gray',
	'color' : '#3e484e',
},
{
	'name'  : 'gray',
	'color' : '#8b959b',
},
{
	'name'  : 'light-gray',
	'color' : '#e4e8eb',
},
{
	'name'  : 'lighter-gray',
	'color' : '#f8f9fa',
},
];

export default theme_colors;
