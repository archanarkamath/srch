/**
 * Set the attributes for the Block Padding panel.
 * @type {Object}
 */
const BlockPaddingAttributes = {
	blockPadding: {
		type: 'string',
	},
	blockPaddingHorizontal: {
		type: 'string',
	},
};

export default BlockPaddingAttributes;
