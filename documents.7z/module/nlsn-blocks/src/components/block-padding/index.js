/**
 * WordPress dependencies
 */
const { __ } = wp.i18n;

const {
	PanelBody,
	PanelRow,
	SelectControl,
} = wp.components;

/**
 * Internal dependencies
 */
import BlockPaddingAttributes from './attributes';
import BlockPaddingClasses from './classes';

// Export for ease of importing in individual blocks.
export {
	BlockPaddingAttributes,
	BlockPaddingClasses,
};

// Component Options for export
function BlockPaddingOptions( props ) {
	const setBlockPadding = value => props.setAttributes( { blockPadding: value } );
	const setHorizontalPadding = value => props.setAttributes( { blockPaddingHorizontal: value } );

	return (
		<PanelBody
			title={ __( 'Block Padding Options', 'nlsn-blocks' ) }
			className="nlsn-padding-options"
			initialOpen={ true }
		>
			<PanelRow>
				<SelectControl
					label={ __( 'Vertical Padding', 'nlsn-blocks' ) }
					value={ props.attributes.blockPadding ? props.attributes.blockPadding : '' }
					options={ [
						{
							label: __( 'None (0px)', 'nlsn-blocks' ),
							value: 'module-no-padding',
						},
						{
							label: __( 'Slim (25px)', 'nlsn-blocks' ),
							value: 'module-slim',
						},
						{
							label: __( 'Normal (50px)', 'nlsn-blocks' ),
							value: 'module-normal',
						},
						{
							label: __( 'Thick (75px)', 'nlsn-blocks' ),
							value: 'module-thick',
						},
					] }
					onChange={ setBlockPadding }
				/>
			</PanelRow>

			<PanelRow>
				<SelectControl
					label={ __( 'Horizontal Padding', 'nlsn-blocks' ) }
					value={ props.attributes.blockPaddingHorizontal ? props.attributes.blockPaddingHorizontal : '' }
					options={ [
						{
							label: __( 'None (0px)', 'nlsn-blocks' ),
							value: 'module-no-horizontal',
						},
						{
							label: __( 'Thin (5px)', 'nlsn-blocks' ),
							value: 'module-thin-horizontal',
						},
						{
							label: __( 'Slender (10px)', 'nlsn-blocks' ),
							value: 'module-slender-horizontal',
						},
						{
							label: __( 'Slim (15px)', 'nlsn-blocks' ),
							value: 'module-slim-horizontal',
						},
						{
							label: __( 'Small (20px)', 'nlsn-blocks' ),
							value: 'module-small-horizontal',
						},
						{
							label: __( 'Normal (25px)', 'nlsn-blocks' ),
							value: 'module-normal-horizontal',
						},
						{
							label: __( 'Thick (50px)', 'nlsn-blocks' ),
							value: 'module-thick-horizontal',
						},
					] }
					onChange={ setHorizontalPadding }
				/>
			</PanelRow>
		</PanelBody>
	);
}
export default BlockPaddingOptions;
