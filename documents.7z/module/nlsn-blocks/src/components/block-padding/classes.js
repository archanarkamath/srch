/**
 * Set inline CSS class.
 * @param {object} props - The block object.
 * @return {array} The inline CSS class.
 */

function BlockPaddingClasses( props ) {
	return [
		// returns classes
		props.attributes.blockPadding,
		props.attributes.blockPaddingHorizontal,
		{
			'module-no-padding': ( props.attributes.blockPadding === undefined ),
		},		
	];
}

export default BlockPaddingClasses;
