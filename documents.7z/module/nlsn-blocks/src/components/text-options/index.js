/**
 * WordPress dependencies
 */
const { __ } = wp.i18n;

const {
	Button,
	ButtonGroup,
	BaseControl,
	PanelBody,
	PanelRow,
	ToggleControl,
} = wp.components;

/**
 * Internal dependencies
 */
import TextOptionsAttributes from './attributes';
import TextOptionsClasses from './classes';

// Export for ease of importing in individual blocks.
export {
	TextOptionsAttributes,
	TextOptionsClasses,
};

// Component Options for export
function TextOptions( props ) {
	const {
		attributes: {
			verticalAlignment,
			contrast,
		},
		setAttributes,
	} = props;

	// METHODS
	const updateAttribute = ( element, updatedValue ) => {
		setAttributes( { [ element ]: updatedValue } );
	};

	// Background options
	const options = {
		verticalAlignment: [
			{ label: 'Top', value: 'top' },
			{ label: 'Middle', value: 'middle' },
			{ label: 'Bottom', value: 'bottom' },
		],
	};

	return (
		<PanelBody
			title={ __( 'Text Options', 'nlsn-blocks' ) }
			className="nlsn-text-options"
			initialOpen={ true }
		>
			<PanelRow>
				<BaseControl
					id="vertical-alignment"
					label={ __( 'Vertical Alignment', 'nlsn-blocks' ) }
				>
					<ButtonGroup
						aria-label={ __( 'Vertical Alignment', 'nlsn-blocks' ) }
					>
						{ options.verticalAlignment.map( ( type ) => {
							return (
								<Button
									key={ type.label }
									isPrimary={ verticalAlignment === type.value }
									aria-pressed={ verticalAlignment === type.value }
									onClick={ () => updateAttribute( 'verticalAlignment', type.value ) }
								>
									{ type.label }
								</Button>
							);
						} ) }
					</ButtonGroup>
				</BaseControl>
			</PanelRow>
			<PanelRow>
				<ToggleControl
					label={ __( 'Toggle Contrast', 'nlsn-blocks' ) }
					checked={ contrast }
					onChange={ ( value ) => updateAttribute( 'contrast', value ) }
					help={ ( checked ) => checked ? __( 'Contrast Enabled.', 'nlsn-blocks' ) : __( 'Contrast Disabled.', 'nlsn-blocks' ) }
				/>
			</PanelRow>
		</PanelBody>
	);
}

export default TextOptions;
