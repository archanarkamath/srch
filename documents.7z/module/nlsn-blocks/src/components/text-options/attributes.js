/**
 * Set the attributes for the Slider Options panel.
 * @type {Object}
 */
const TextOptionsAttributes = {
	verticalAlignment: {
		type: 'string',
	},
	contrast: {
		type: 'boolean',
		default: false,
	},
};

export default TextOptionsAttributes;
