/**
 * Set the CSS classes used for the Text Options settings in the Inspector Controls
 * @param {object} props - The block object.
 * @return {array} The inline CSS class.
 */

function TextOptionsClasses( props ) {
	const {
		attributes: {
			verticalAlignment,
			contrast,
		},
	} = props;

	return [
		{
			'd-flex': ( verticalAlignment !== undefined ),
			'align-items-start': ( verticalAlignment === 'top' || verticalAlignment === undefined ),
			'align-items-center': ( verticalAlignment === 'middle' ),
			'align-items-end': ( verticalAlignment === 'bottom' ),
			'text-contrast': ( contrast ),
		},
	];
}

export default TextOptionsClasses;
