/**
 * WordPress dependencies
 */
const { __ } = wp.i18n;

const {
} = wp.editor;

const {
	PanelBody,
	PanelRow,
	ToggleControl,
} = wp.components;
const { Fragment } = wp.element;

/**
 * Internal dependencies
 */
import ContainerOptionsAttributes from './attributes';

// Import all of our Inspector Options requirements.
import HideSectionOptions, { HideSectionEdit, HideSectionSave } from '../hiding';
import BlockIdOptions, { BlockIdEdit, BlockIdSave } from '../block-id';
import BackgroundOptions, { BackgroundOptionsClasses, BackgroundImages, BackgroundVideos, BackgroundVideosImages } from '../background-options';
import MinHeightOptions, { MinHeightStyles } from '../min-height';
import BlockPaddingOptions, { BlockPaddingClasses } from '../block-padding';
import BlockWidthOptions, { BlockWidthClasses } from '../block-width';
import TextOptions, { TextOptionsClasses } from '../text-options';
import { MarginOptionsEdit, MarginOptionsClasses, MarginOptionsStyles } from '../margin-options';
import BorderOptions, { BorderOptionsClasses } from '../border-options';
import HeroOptions, { HeroOptionsClasses } from '../hero-options';
import NLSNHeading from '../heading';
import DirectionalArrowOptions, { DirectionalArrowClasses } from '../directional-arrow';

// Export for ease of importing in individual blocks.
export {
	ContainerOptionsAttributes,
	HideSectionEdit,
	HideSectionSave,
	BlockIdEdit,
	BlockIdSave,
	BackgroundOptionsClasses,
	BackgroundImages,
	BackgroundVideos,
	BackgroundVideosImages,
	MinHeightStyles,
	BlockPaddingClasses,
	BlockWidthClasses,
	TextOptionsClasses,
	MarginOptionsClasses,
	MarginOptionsEdit,
	MarginOptionsStyles,
	BorderOptionsClasses,
	HeroOptionsClasses,
	NLSNHeading,
	DirectionalArrowClasses,
};

// Component Options for export
function ContainerOptions( props ) {
	const {
		attributes: {
			containerSettings,
		},
		fullFunctionality,
		negativeMarginFunctionality,
		setAttributes,
	} = props;

	const setContainerSettings = value => setAttributes( { containerSettings: value } );

	const containerSettingsToggle = () => {
		return (
			// If enabled, the inspector options below will become available
			containerSettings && (
				<Fragment>
					<PanelBody
						title={ __( 'Block Options', 'nlsn-blocks' ) }
						className="nlsn-block-options"
						initialOpen={ false }
					>
						<HideSectionOptions
							{ ...props }
						/>
						<BlockIdOptions
							{ ...props }
						/>
						<BackgroundOptions
							{ ...props }
							fullFunctionality={ fullFunctionality }
							negativeMarginFunctionality={ negativeMarginFunctionality }
						/>
						{ fullFunctionality &&
							<Fragment>
								<MinHeightOptions
									{ ...props }
								/>
								<TextOptions
									{ ...props }
								/>
								<BorderOptions
									{ ...props }
								/>
								<HeroOptions
									{ ...props }
								/>
							</Fragment>
						}
						<BlockPaddingOptions
							{ ...props }
						/>
						<BlockWidthOptions
							{ ...props }
						/>
						{ fullFunctionality &&
							<DirectionalArrowOptions
								 { ...props }
							 />
						}
					</PanelBody>
				</Fragment>
			)
		);
	};

	return (
		<Fragment>
			<PanelBody
				className='nlsn-enable-block-options'
			>
				<PanelRow>
					<ToggleControl
						label={ __( 'Enable Block Settings', 'nlsn-blocks' ) }
						checked={ containerSettings }
						help={ ( checked ) => checked ? __( 'Settings Enabled.', 'nlsn-blocks' ) : __( 'Settings Disabled.', 'nlsn-blocks' ) }
						onChange={ setContainerSettings }
					/>
				</PanelRow>
			</PanelBody>
			{ containerSettingsToggle() }
		</Fragment>

	);
}
export default ContainerOptions;