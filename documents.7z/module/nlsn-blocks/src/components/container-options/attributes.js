/**
 * Set the attributes for the Container Options panel.
 * @type {Object}
 */

// Import all of our Attribute requirements.
import { HideSectionAttributes } from '../hiding';
import { BlockIdAttributes } from '../block-id';
import { BackgroundOptionsAttributes } from '../background-options';
import { MinHeightAttributes } from '../min-height';
import { BlockPaddingAttributes } from '../block-padding';
import { BlockWidthAttributes } from '../block-width';
import { TextOptionsAttributes } from '../text-options';
import { MarginOptionsAttributes } from '../margin-options';
import { BorderOptionsAttributes } from '../border-options';
import { HeadingAttributes } from '../heading';
import { HeroOptionsAttributes } from '../hero-options';
import { DirectionalArrowAttributes } from '../directional-arrow';

const ContainerOptionsAttributes = {
	// If enabled, the attributes imported below will become available
	containerSettings: {
		type: 'boolean',
		default: false,
	},

	// Imported attributes
	...HideSectionAttributes,
	...BlockIdAttributes,
	...BackgroundOptionsAttributes,
	...MinHeightAttributes,
	...BlockPaddingAttributes,
	...BlockWidthAttributes,
	...TextOptionsAttributes,
	...MarginOptionsAttributes,
	...BorderOptionsAttributes,
	...HeadingAttributes,
	...HeroOptionsAttributes,
	...DirectionalArrowAttributes,
};

export default ContainerOptionsAttributes;
