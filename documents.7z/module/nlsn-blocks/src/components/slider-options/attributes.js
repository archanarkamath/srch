/**
 * Set the attributes for the Slider Options panel.
 * @type {Object}
 */
const SliderOptionsAttributes = {
	sliderSettings: {
		type: 'boolean',
		default: false,
	},
	sliderId: {
		type: 'string',
		default: 'add-custom-id',
	},
	lightbox:{
		type: 'boolean',
		default: false,
	},
	loop: {
		type: 'boolean',
		default: true,
	},
	pauseOnHover: {
		type: 'boolean',
		default: true,
	},
	autoplay: {
		type: 'boolean',
		default: true,
	},
	timeInterval: {
		type: 'number',
		default: 5,
	},
	animation: {
		type: 'string',
		default: 'slide',
	},
	colorHighlight: {
		type: 'string',
	},
};

export default SliderOptionsAttributes;
