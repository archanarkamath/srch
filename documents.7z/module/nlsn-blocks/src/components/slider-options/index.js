/**
 * WordPress dependencies
 */
const { __ } = wp.i18n;

const {
	PanelColorSettings,
} = wp.blockEditor;

const {
	PanelBody,
	PanelRow,
	TextControl,
	ToggleControl,
	RangeControl,
	SelectControl,
} = wp.components;

const { Fragment } = wp.element;

/**
 * Internal dependencies
 */
import SliderOptionsAttributes from './attributes';
import ColorHighlightClasses from './classes';
import SliderIdEdit from './edit-slider-id';


// Export for ease of importing in individual blocks.
export {
	SliderOptionsAttributes,
	ColorHighlightClasses,
	SliderIdEdit,
};

// Component Options for export
function SliderOptions( props ) {

	const {
		attributes: {
			sliderSettings,
			sliderId,
			lightbox,
			loop,
			pauseOnHover,
			autoplay,
			timeInterval,
			animation,
			colorHighlight,
		},
		setAttributes,
		fullFunctionality,
	} = props;

	const setSliderSettings = value => setAttributes( { sliderSettings: value } );
	const setSliderId = value => setAttributes( { sliderId: value } );
	const setLightbox = value => setAttributes( { lightbox: value } );
	const setLoop = value => setAttributes( { loop: value } );
	const setPauseOnHover = value => setAttributes( { pauseOnHover: value } );
	const setAutoplay = value => setAttributes( { autoplay: value } );
	const setTimeInterval = value => setAttributes( { timeInterval: value } );
	const setAnimation = value => setAttributes( { animation: value } );
	const setColorHighlight = value => setAttributes( { colorHighlight: value } );

	const sliderLightbox = () => {
		if ( fullFunctionality ) {
			return (
				<PanelRow>
					<ToggleControl
						label={ __( 'Enable Lightbox', 'nlsn-blocks' ) }
						checked={ lightbox }
						help={ ( checked ) => checked ? __( 'Lightbox Enabled.', 'nlsn-blocks' ) : __( 'Lightbox Disabled.', 'nlsn-blocks' ) }
						onChange={ setLightbox }
					/>
				</PanelRow>
			);
		}
	}

	const sliderSettingsToggle = () => {
		return (
			// If enabled, the inspector options below will become available
			sliderSettings ? (
				<PanelBody
					title={ __( 'Slider Options', 'nlsn-blocks' ) }
					className='nlsn-slider-options'
					initialOpen={ true }
				>

					{ sliderLightbox() }

					<PanelRow>
						<ToggleControl
							label={ __( 'Loop', 'nlsn-blocks' ) }
							checked={ loop }
							help={ ( checked ) => checked ? __( 'Looping Enabled.', 'nlsn-blocks' ) : __( 'Looping Disabled.', 'nlsn-blocks' ) }
							onChange={ setLoop }
						/>
					</PanelRow>

					<PanelRow>
						<ToggleControl
							label={ __( 'Pause On Hover', 'nlsn-blocks' ) }
							checked={ pauseOnHover }
							help={ ( checked ) => checked ? __( 'Pausing Enabled.', 'nlsn-blocks' ) : __( 'Pausing Disabled.', 'nlsn-blocks' ) }
							onChange={ setPauseOnHover }
						/>
					</PanelRow>

					<PanelRow>
						<ToggleControl
							label={ __( 'Autoplay', 'nlsn-blocks' ) }
							checked={ autoplay }
							help={ ( checked ) => checked ? __( 'Autoplay Enabled.', 'nlsn-blocks' ) : __( 'Autoplay Disabled.', 'nlsn-blocks' ) }
							onChange={ setAutoplay }
						/>
					</PanelRow>

					<PanelRow>
						{ autoplay ? (
	            <RangeControl
	              label='Time Interval'
	              value={ timeInterval }
	              onChange={ setTimeInterval }
	              min={ 1 }
	              max={ 10 }
	              beforeIcon='minus'
	              afterIcon='plus'
	            />
	          ) : null }
					</PanelRow>

					<PanelRow>
						<SelectControl
							label={ __( 'Animation', 'nlsn-blocks' ) }
							value={ animation }
							options={ [
								{
									label: __( 'Slide', 'nlsn-blocks' ),
									value: 'slide',
								},
								{
									label: __( 'Fade', 'nlsn-blocks' ),
									value: 'fade',
								},
							] }
							onChange={ setAnimation }
						/>
					</PanelRow>

					<PanelRow>
						<PanelColorSettings
							title={ __( 'Color Settings', 'nlsn-blocks' ) }
							colorSettings={ [
								{
									value: colorHighlight,
									onChange: setColorHighlight,
									label: __( 'Color Highlight', 'nlsn-blocks' ),
								},
							] }
						>
							<p>
								{ __( 'This color will affect headlines, buttons, and other slider components.', 'nlsn-blocks' ) }
							</p>
						</PanelColorSettings>
					</PanelRow>

				</PanelBody>
			) : null
		);
	};

	return (
		<Fragment>
			<PanelBody>
				<PanelRow>
					<ToggleControl
						label={ __( 'Enable Slider Settings', 'nlsn-blocks' ) }
						checked={ sliderSettings }
						help={ ( checked ) => checked ? __( 'Settings Enabled.', 'nlsn-blocks' ) : __( 'Settings Disabled.', 'nlsn-blocks' ) }
						onChange={ setSliderSettings }
					/>
				</PanelRow>
			</PanelBody>
			{ sliderSettingsToggle() }
		</Fragment>

	);
}
export default SliderOptions;
