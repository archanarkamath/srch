/**
 * Set 'edit' sliderId output.
 * @param {object} props - The block object.
 * @return {string} The markup.
 */

// Edit Options for export
function SliderIdEdit( props ) {
	return(
		<div className='block-slider-id'>
			{ props.attributes.sliderId }
		</div>
	);
}
export default SliderIdEdit;
