/**
 * Set inline CSS class.
 * @param {object} props - The block object.
 * @return {array} The inline CSS class.
 */

 // Dependencies
 import { colors } from '../colors/colorUtils';
 // Register editor components
 const { getColorObjectByColorValue } = wp.blockEditor;

function ColorHighlightClasses( props ) {
  const ColorHighlightName = getColorObjectByColorValue( colors, props.attributes.colorHighlight );
	return [
		// returns classes with component theme-colors
		( undefined !== ColorHighlightName ? (
			`theme-${ ColorHighlightName.slug }`
		) : null ),
		{ 'popup-gallery': props.attributes.lightbox },
	];
}

export default ColorHighlightClasses;
