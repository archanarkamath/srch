/**
 * Set the attributes for the Maximum Height panel.
 * @type {Object}
 */
const MaxHeightAttributes = {
	maxHeight: {
		type: 'number',
		default: 1000,
	},
};

export default MaxHeightAttributes;
