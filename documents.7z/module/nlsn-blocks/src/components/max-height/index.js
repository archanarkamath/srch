/**
 * WordPress dependencies
 */
const { __ } = wp.i18n;

const {
	PanelBody,
	PanelRow,
	BaseControl,
} = wp.components;

/**
 * Internal dependencies
 */
import MaxHeightAttributes from './attributes';
import MaxHeightStyles from './styles';

// Export for ease of importing in individual blocks.
export {
	MaxHeightAttributes,
	MaxHeightStyles,
};

// Component Options for export
function MaxHeightOptions( props ) {
	const setMaxHeight = value => props.setAttributes( { maxHeight: value } );

	return (
		<PanelBody
			title={ __( 'Maximum Height Options', 'nlsn-blocks' ) }
			className="nlsn-height-options"
			initialOpen={ true }
		>
			<PanelRow>
				<BaseControl label={ __( 'Maximum Height in Pixels' ) }>
					<input
						type="number"
						onChange={ ( event ) => {
							props.setAttributes( { maxHeight: parseInt( event.target.value, 10 ), } );
						} }
						value={ props.attributes.maxHeight }
						min="0"
						step="10"
					/>
				</BaseControl>
			</PanelRow>
		</PanelBody>
	);
}
export default MaxHeightOptions;
