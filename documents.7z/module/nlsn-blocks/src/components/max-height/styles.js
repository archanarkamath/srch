/**
 * Set inline CSS style.
 * @param {object} props - The block object.
 * @return {array} The inline CSS style.
 */

function MaxHeightStyles( props ) {
	return [
		// returns classes for max height
		props.attributes.maxHeight,
	];
}

export default MaxHeightStyles;
