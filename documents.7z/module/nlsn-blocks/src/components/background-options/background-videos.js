/**
 * Set Background Videos output.
 * @param {object} props - The block object.
 * @return {string} The markup.
 */

 // Dependencies
 import classnames from 'classnames';

// Options for export
function BackgroundVideos( props ) {

	const backgroundVideoClass = classnames(
		'video-background',
	);
	return(
		<div>

			{props.attributes.backgroundVideo ? (
				<div className='embed-responsive embed-responsive-16by9'>
					<div className='embed-iframe embed-responsive-item'>
						[embed]{ props.attributes.backgroundVideo }&autoplay=true&endVideoBehavior=loop&fullscreenButton=false&playbar=false&playButton=false&settingsControl=false&smallPlayButton=false&videoFoam=false&volumeControl=false&muted=true[/embed]
					</div>
				</div>
			):null}
		</div>

	);
}
export default BackgroundVideos;
