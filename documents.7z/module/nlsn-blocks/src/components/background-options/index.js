/**
 * WordPress dependencies
 */
const { __ } = wp.i18n;

const {
	MediaUpload,
	PanelColorSettings,
} = wp.blockEditor;

const {
	Button,
	ButtonGroup,
	BaseControl,
	PanelBody,
	PanelRow,
	TextControl,
	ToggleControl,
} = wp.components;

import { cancelCircleFilled, gallery } from '@wordpress/icons';

/**
 * Internal dependencies
 */
import BackgroundOptionsAttributes from './attributes';
import BackgroundOptionsClasses from './classes';
import BackgroundImages from './background-images';
import BackgroundVideos from './background-videos';
import BackgroundVideosImages from './background-videos-images';

// Export for ease of importing in individual blocks.
export {
	BackgroundOptionsAttributes,
	BackgroundOptionsClasses,
	BackgroundImages,
	BackgroundVideos,
	BackgroundVideosImages,
};

// Other dependencies
import MarginOptions from '../margin-options';

// Component Options for export
function BackgroundOptions( props ) {
	const {
		attributes: {
			backgroundType,
			backgroundColor,
			backgroundVideo,
			backgroundVideoImage,
			backgroundImage,
			backgroundImageMobile,
			backgroundImageXL,
			imagePosition,
			imageSize,
			makeParallax,
			hideParallaxMobile,
		},
		setAttributes,
		isSelected,
		fullFunctionality,
		negativeMarginFunctionality,
	} = props;

	// METHODS
	const updateAttribute = ( element, updatedValue ) => {
		setAttributes( { [ element ]: updatedValue } );
	};

	// Background options
	const options = {
		backgroundType: [
			{ label: 'None', value: 'none' },
			{ label: 'Color', value: 'color' },
		],
		imagePosition: [
			{ label: 'Top', value: 'top center' },
			{ label: 'Middle', value: 'center' },
			{ label: 'Bottom', value: 'bottom center' },
		],
		imageSize: [
			{ label: 'Default', value: 'default' },
			{ label: 'Mobile', value: 'mobile' },
			{ label: 'XL', value: 'xl' },
		],
	};

	if ( fullFunctionality ) {
		options.backgroundType.push(
			{
				label: 'Image',
				value: 'image',
			}, {
				label: 'Video',
				value: 'video',
			}
		);
	}

	// Background color selection panel
	const backgroundColorSelectionPanel = () => {
		return (
			<PanelColorSettings
				title={ __( 'Color Settings', 'nlsn-blocks' ) }
				colorSettings={ [
					{
						value: backgroundColor,
						onChange: ( value ) => setAttributes( { backgroundColor: value } ),
						label: __( 'Background Color', 'nlsn-blocks' ),
					},
				] }
			>
			</PanelColorSettings>
		);
	};

	const imageAddRemoveTool = () => {
		let imageSizeCheck, imageSizeString;
		if ( 'mobile' === imageSize ) {
			imageSizeCheck = backgroundImageMobile;
			imageSizeString = 'backgroundImageMobile';
		} else if ( 'xl' === imageSize ) {
			imageSizeCheck = backgroundImageXL;
			imageSizeString = 'backgroundImageXL';
		} else {
			imageSizeCheck = backgroundImage;
			imageSizeString = 'backgroundImage';
		}

		if ( ! imageSizeCheck ) {
			return (
			<MediaUpload
				onSelect={ ( value ) => updateAttribute( imageSizeString, value ) }
				value=""
				render={ ( { open } ) => (
					<Button isSecondary onClick={ open } icon={ gallery } > Add/Upload Image </Button>
				) }
			/>
			);
		}

		return (
			<div className="image-wrapper">
				<p>
					<img
						src={ imageSizeCheck.url }
						alt={ imageSizeCheck.alt }
					/>
				</p>
				{ isSelected &&
					<div className="media-button-wrapper">
						<p>
							<Button
								onClick={ () => updateAttribute( imageSizeString, undefined ) }
								icon={ cancelCircleFilled }
							> Remove Image
							</Button>
						</p>
					</div>
				}
			</div>
		);
	};

	// Make Parallax class
	const setMakeParallaxClass = () => {

		if( backgroundImage ){
			return (
				<div>
					<BaseControl
						id="make-parallax"
						label={ __( 'Background Parallax Effect', 'nlsn-blocks' ) }
					>
						<ToggleControl
							label={ __( 'Toggle Parallax', 'nlsn-blocks' ) }
							checked={ makeParallax }
							onChange={ ( value ) => updateAttribute( 'makeParallax', value ) }
							help={ ( checked ) => checked ? __( 'Parallax Enabled.', 'nlsn-blocks' ) : __( 'Parallax Disabled.', 'nlsn-blocks' ) }
						/>
					</BaseControl>
				</div>
			);
		}

	};

	// Background image selection panel
	const backgroundImageSelectionPanel = () => {
		return (
			<div>
				<BaseControl
					id="image-position"
					label={ __( 'Image Position', 'nlsn-blocks' ) }
				>
					<ButtonGroup
						id="image-position"
						aria-label={ __( 'Image Position', 'nlsn-blocks' ) }
						className="image-position"
					>
						{ options.imagePosition.map( position => {
							return (
								<Button
									key={ position.label }
									isPrimary={ imagePosition === position.value }
									aria-pressed={ imagePosition === position.value }
									onClick={ () => updateAttribute( 'imagePosition', position.value ) }
								>
									{ position.label }
								</Button>
							);
						} ) }
					</ButtonGroup>
				</BaseControl>

				<BaseControl
					id="image-size"
					label={ __( 'Image Size', 'nlsn-blocks' ) }
				>
					<ButtonGroup
						id="image-size"
						aria-label={ __( 'Image Size', 'nlsn-blocks' ) }
						className="image-size"
					>
						{ options.imageSize.map( size => {
							return (
								<Button
									key={ size.label }
									isPrimary={ imageSize === size.value }
									aria-pressed={ imageSize === size.value }
									onClick={ () => updateAttribute( 'imageSize', size.value ) }
								>
									{ size.label }
								</Button>
							);
						} ) }
					</ButtonGroup>
				</BaseControl>
				{ imageAddRemoveTool() }
				{ setMakeParallaxClass() }
			</div>
		);
	};

	//Background video selection Panel
	const backgroundVideoSelectionPanel = () => {
		return(
			<div>
				<PanelRow>
					<TextControl
					label={ __( 'Insert video URL', 'nlsn-blocks' ) }
					value={ backgroundVideo }
					onChange={ ( value ) => updateAttribute( 'backgroundVideo', value ) }
					/>
				</PanelRow>

				<PanelRow>
					<BaseControl label={ __( 'Mobile Background Image' ) }>

						{ ! backgroundVideoImage ? (
							<MediaUpload
								buttonProps={ {
									className: 'components-button button',
								} }
								onSelect={ backgroundVideoImage => setAttributes( { backgroundVideoImage } ) }
								value=''
								render={ ( { open } ) => (
									<Button isSecondary onClick={ open } icon={ gallery } > Add/Upload Image </Button>
								) }
							/>
						) : (
							<div className="image-wrapper">
								<p>
									<img
									src={ backgroundVideoImage.url }
									alt={ backgroundVideoImage.alt }
								/>
								</p>
								<div className="media-button-wrapper">
									<Button
										className="remove-image button"
										onClick={ backgroundVideoImage => setAttributes( { backgroundVideoImage: undefined } ) }
										icon={ cancelCircleFilled }
										>
										Remove Image
									</Button>
								</div>
							</div>
						) }
					</BaseControl>
				</PanelRow>
			</div>
		)
	};

	return (
		<PanelBody
			title={ __( 'Background Options', 'nlsn-blocks' ) }
			className="nlsn-background-options"
			initialOpen={ true }
		>
			<PanelRow>
				<BaseControl
					id="background-type"
					label={ __( 'Background Type', 'nlsn-blocks' ) }
				>
					<ButtonGroup
						id="background-type"
						aria-label={ __( 'Background Type', 'nlsn-blocks' ) }
						className="background-type"
						style={ { display: 'block' } }
					>
						{ options.backgroundType.map( ( type ) => {
							return (
								<Button
									key={ type.label }
									isPrimary={ backgroundType === type.value }
									aria-pressed={ backgroundType === type.value }
									onClick={ () => updateAttribute( 'backgroundType', type.value ) }
								>
									{ type.label }
								</Button>
							);
						} ) }
					</ButtonGroup>
				</BaseControl>
			</PanelRow>
			<PanelRow>
				{ ( 'color' === backgroundType ) &&
					backgroundColorSelectionPanel()
				}
				{ ( 'image' === backgroundType ) &&
					backgroundImageSelectionPanel()
				}
				{ ( 'video' === backgroundType ) &&
					backgroundVideoSelectionPanel()
				}
			</PanelRow>
			{ ( 'none' !== backgroundType && negativeMarginFunctionality ) &&
				<MarginOptions
					{ ...props }
				/>
			}
		</PanelBody>
	);
}

export default BackgroundOptions;