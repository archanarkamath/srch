/**
 * Set Background Videos Mobile Images output.
 * @param {object} props - The block object.
 * @return {string} The markup.
 */

 // Dependencies
 import classnames from 'classnames';

// Options for export
function BackgroundVideosImages( props ) {

	return(
		<div>

			{props.attributes.backgroundVideoImage ? (
				<div
					className={ classnames( 'image-background background-video-image-mobile' ) }
					style={ {
						backgroundImage: `url(${ props.attributes.backgroundVideoImage.url })`,
						backgroundPosition: `center`,
					} }
				>
				</div>
			) : null}

		</div>
	);
}
export default BackgroundVideosImages;
