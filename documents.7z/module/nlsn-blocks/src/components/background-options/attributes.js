/**
 * Set the attributes for the Background Options panel.
 * @type {Object}
 */
const BackgroundOptionsAttributes = {
	backgroundType: {
		type: 'string',
		default: 'none',
	},
	imageSize: {
		type: 'string',
		default: 'default',
	},
	imagePosition: {
		type: 'string',
		default: 'center',
	},
	backgroundColor: {
		type: 'string',
	},
	backgroundVideo: {
		type: 'string',
	},
	backgroundVideoImage: {
		type: 'object',
	},
	backgroundImage: {
		type: 'object',
	},
	backgroundImageMobile: {
		type: 'object',
	},
	backgroundImageXL: {
		type: 'object',
	},
	makeParallax: {
		type: 'boolean',
		default: false,
	},
	hideParallaxMobile: {
		type: 'boolean',
		default: false,
	},
};

export default BackgroundOptionsAttributes;
