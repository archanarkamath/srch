/**
 * Set Background Images output.
 * @param {object} props - The block object.
 * @return {string} The markup.
 */

 // Dependencies
 import classnames from 'classnames';

// Options for export
function BackgroundImages( props ) {

	const backgroundImageClass = classnames(
		'image-background',
	);

	return(
		<div>
			{props.attributes.backgroundImage ? (
				<div
					className={ classnames( backgroundImageClass, 'background-image-default' ) }
					style={ {
						backgroundImage: `url(${ props.attributes.backgroundImage.url })`,
						backgroundPosition: props.attributes.imagePosition,
					}}
				>
      	</div>
			) : null}

			{props.attributes.backgroundImageMobile ? (
				<div
					className={ classnames( backgroundImageClass, 'background-image-mobile hidden-sm-up' ) }
					style={ {
						backgroundImage: `url(${ props.attributes.backgroundImageMobile.url })`,
						backgroundPosition: props.attributes.imagePosition,
					} }
				>
				</div>
			) : null}

			{props.attributes.backgroundImageXL ? (
				<div
					className={ classnames( backgroundImageClass, 'background-image-xl hidden-lg-down' ) }
					style={ {
						backgroundImage: `url(${ props.attributes.backgroundImageXL.url })`,
						backgroundPosition: props.attributes.imagePosition,
					} }
				>
				</div>
			) : null}
		</div>

	);
}
export default BackgroundImages;
