/**
 * Set inline CSS class.
 * @param {object} props - The block object.
 * @return {array} The inline CSS class.
 */

 // Dependencies
 import { colors } from '../colors/colorUtils';
 // Register editor components
 const { getColorObjectByColorValue } = wp.blockEditor;

function BackgroundOptionsClasses( props ) {
	const backgroundColorName = getColorObjectByColorValue( colors, props.attributes.backgroundColor );

	return [
		// returns classes with background type and background color
		{ 'has-color-background': 'color' === props.attributes.backgroundType },
		( undefined !== backgroundColorName && 'color' === props.attributes.backgroundType ? (
			`bg-${ backgroundColorName.slug }`
		) : null ),
		{ 'has-image-background': 'image' === props.attributes.backgroundType },
		{ 'make-parallax': true === props.attributes.makeParallax },
    { 'has-video-background': 'video' === props.attributes.backgroundType },
	];
}

export default BackgroundOptionsClasses;
