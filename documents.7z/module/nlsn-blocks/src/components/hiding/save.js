/**
 * Set 'save' inline CSS class
 * @param {object} props - The block object.
 * @return {array} The inline CSS class.
 */

// Class to be used on 'Save' if condition is true
function HideSectionSave( props ) {
	return[
		{ 'hidden-xs-up': true === props.attributes.hideSection },
		{ 'hidden-xs-down': true === props.attributes.hideMobileSection }
	];
}
export default HideSectionSave;
