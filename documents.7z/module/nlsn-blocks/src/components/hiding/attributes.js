/**
 * Set the attributes for the Hide Section panel.
 * @type {Object}
 */
const HideSectionAttributes = {
	hideSection: {
		type: 'boolean',
		default: false,
	},
	hideMobileSection: {
		type: 'boolean',
		default: false,
	},
	popupExpire: {
		type: 'boolean',
		default: false,
	},
	popupDate: {
		type: 'string',
		default: new Date(),
	},
	popupDateZoned: {
		type: 'string',
		default: new Date(),
	},
	timezone: {
		type: 'string',
		source: 'meta',
		meta: 'post_meta_timezone',
	},
};

export default HideSectionAttributes;
