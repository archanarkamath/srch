/**
 * WordPress dependencies
 */
const { __ } = wp.i18n;

const {
} = wp.editor;

const {
	PanelBody,
	PanelRow,
	ToggleControl,
} = wp.components;

/**
 * Internal dependencies
 */
import HideSectionAttributes from './attributes';
import HideSectionEdit from './edit';
import HideSectionSave from './save';
import { DateTimePicker } from '@wordpress/components';
import { __experimentalGetSettings, date } from '@wordpress/date';

// Export for ease of importing in individual blocks.
export {
	HideSectionAttributes,
	HideSectionEdit,
	HideSectionSave,
};

// Component Options for export
function HideSectionOptions( props ) {	
	const setHidingSetting = value => props.setAttributes( { hideSection: value } );
	const setHidingMobileSetting = value => props.setAttributes( { hideMobileSection: value } );
	
	// for animated callout block start
	const isAnimatedCallout = ( props.name === "nlsn-blocks/nlsn-animated-callout" ? true : false );
	const theDate = props.attributes.popupDate;
	const theTimezone = props.attributes.timezone;
	const settings = __experimentalGetSettings();
	const is12HourTime = /a(?!\\)/i.test(
        settings.formats.time
            .toLowerCase()
            .replace( /\\\\/g, '' )
            .split( '' ).reverse().join( '' )
    );    
    const setPopupExpire = value => props.setAttributes( { popupExpire: value } );    
	const setPopupDate = value => value === null ? props.setAttributes( { popupDate: new Date() } ) : props.setAttributes( { popupDate: value } );
	const setPopupDateZoned = value => value === null ? props.setAttributes( { popupDateZoned: moment.tz( moment().format(), theTimezone ).format() } ) : props.setAttributes( { popupDateZoned: moment.tz( value, theTimezone ).format() } );
	const setExpiration = function(value){
		setPopupDate(value);
		setPopupDateZoned(value);
	}
    // for animated callout block end
	
	return (
		<PanelBody>
			<PanelRow>
				<ToggleControl
					label={ __( 'Disable Block', 'nlsn-blocks' ) }
					checked={ props.attributes.hideSection }
					help={ ( checked ) => checked ? __( 'Block Disabled.', 'nlsn-blocks' ) : __( 'Block Enabled.', 'nlsn-blocks' ) }
					onChange={ setHidingSetting }
				/>
			</PanelRow>
			<PanelRow>
				<ToggleControl
					label={ __( 'Disable Block in Mobile', 'nlsn-blocks' ) }
					checked={ props.attributes.hideMobileSection }
					help={ ( checked ) => checked ? __( 'Block Disabled in Mobile.', 'nlsn-blocks' ) : __( 'Block Enabled in Mobile.', 'nlsn-blocks' ) }
					onChange={ setHidingMobileSetting }
				/>
			</PanelRow>

		{	isAnimatedCallout &&
			<PanelRow>
				<ToggleControl
					label={ __( 'Disable Block as of the Date', 'nlsn-blocks' ) }
					checked={ props.attributes.popupExpire }
					onChange={ setPopupExpire }
					help={ ( checked ) => checked ? __( 'Block Expiration Enabled.', 'nlsn-blocks' ) : __( 'Block Expiration Disabled.', 'nlsn-blocks' ) }
				/>
			</PanelRow>
		}

		{	props.attributes.popupExpire &&	
			<PanelRow>
				<DateTimePicker
					currentDate={ theDate } 
					onChange={ setExpiration } 
					is12Hour={ is12HourTime }
		        />
			</PanelRow>
		}		
		</PanelBody>
		
	);
}
export default HideSectionOptions;
