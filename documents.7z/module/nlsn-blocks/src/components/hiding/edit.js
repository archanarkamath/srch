/**
 * Set 'edit' hiding output.
 * @param {object} props - The block object.
 * @return {string} The markup.
 */

// Edit Options for export
function HideSectionEdit( props ) {
	const sectionDisabled = ( props.attributes.hideSection ) ? 'Block disabled!' : null;

	let message ='';
	if(sectionDisabled){
		message = ''
	}else{
		message = 'Block disabled in mobile'
	}

	const sectionMobileDisabled = ( props.attributes.hideMobileSection ) ?  message  : null;	

	return (
		<div className="block-disabled">
			{ sectionDisabled }
			{ sectionMobileDisabled }
		</div>
	);	
}
export default HideSectionEdit;
