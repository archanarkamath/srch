const attributes = {
	columns: {
		type: 'number',
		default: 2,
	},
	columnLayout: {
		type: 'string',
		default: '50-50',
	}
};

export default attributes;
