/**
 * BLOCK: Inner Columns
 */

// Block dependencies
import classnames from 'classnames';
import { times } from 'lodash-es';
import memoize from 'memize';
import Inspector from './inspector';
import attributes from './attributes';

//  Import CSS.
// import './editor.scss';

/**
 * WordPress dependencies
 */
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks

// Register editor components
const {
	InspectorControls,
	InnerBlocks,
} = wp.blockEditor;

const defineBlockClasses = ( props ) => {
	// setup layout classes
	const blockClasses = classnames(
		'column-layout',
		`has-${ props.attributes.columnLayout }-layout`,
	);
	return {
		blockClasses,
	};
};

/**
 * Allowed blocks constant is passed to InnerBlocks precisely as specified here.
 * The contents of the array should never change.
 * The array should contain the name of each block that is allowed.
 * In columns block, the only block we allow is 'core/column'.
 *
 * @constant
 * @type {string[]}
*/
const ALLOWED_BLOCKS = [ 'core/column' ];

/**
 * Returns the layouts configuration for a given number of columns.
 *
 * @param {number} columns Number of columns.
 *
 * @return {Object[]} Columns layout configuration.
 */
const getColumnTemplate = memoize( ( columns ) => {
	return times( columns, () => [ 'core/column' ] );
} );

registerBlockType( 'nlsn-blocks/nlsn-columns-inner', {
	title: __( 'Inner Columns - NLSN', 'nlsn-blocks' ),
	description: __( 'Create inner-columns layout', 'nlsn-blocks' ),
	icon: 'columns',
	category: 'nielsen-blocks',
	parent: [ 'core/column' ],
	keywords: [
		__( 'columns', 'nlsn-blocks' ),
		__( 'template', 'nlsn-blocks' ),
		__( 'nielsen', 'nlsn-blocks' ),
	],
	attributes: {
		...attributes,
	},

	edit: props => {
		const {
			attributes: {
				columns,
			},
			isSelected,
			className,
			setAttributes,
		} = props;

		const blockClassesObject = defineBlockClasses( props );

		return (
			
			<div key="editor-display" className={ className }>

				{ isSelected &&
					<InspectorControls>
						<Inspector
							{ ...props }
						/>
					</InspectorControls>
				}

				<div className={ blockClassesObject.blockClasses }>
					<InnerBlocks
						template={ getColumnTemplate( columns ) }
						templateLock="all"
						allowedBlocks={ ALLOWED_BLOCKS }
					/>
				</div>

			</div>
		)
	},

	save: props => {
		const {
			attributes: {

			},
			className,
		} = props;

		const blockClassesObject = defineBlockClasses( props );

		// Return the markup displayed on the front-end.
		return (
			<div className={ className }>

				<div className={ classnames( blockClassesObject.blockClasses, 'row' ) }>
					<InnerBlocks.Content />
				</div>

			</div>
		);
	},

	deprecated: [
		{

		},
	],
} );
