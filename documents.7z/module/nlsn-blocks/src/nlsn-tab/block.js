/**
 * BLOCK: tab
 */

 // Block dependencies
import classnames from 'classnames';
import Inspector from './inspector';
import attributes from './attributes';
import icons from './icons';

//  Import CSS.
// import './editor.scss';

// Components
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks
const { withInstanceId } = wp.compose;

// Register editor components
const {
	RichText,
	InspectorControls,
	InnerBlocks,
} = wp.blockEditor;

const blockClasses = classnames (
	`nav-item`
);

// Register the block
registerBlockType( 'nlsn-blocks/nlsn-tab', {
	title: __( 'Tab - NLSN' ),
	description: __( 'Add tabs for this section' ),
	icon: icons.tab,
	category: 'nielsen-blocks',
	keywords: [
	  __( 'tab', 'nlsn-blocks' ),
	  __( 'nielsen', 'nlsn-blocks' ),
	],
	parent: [ 'nlsn-blocks/nlsn-tabs-container' ],
	attributes: {
		...attributes
	},

	// Render the block components
	edit: withInstanceId(
		props => {

		// Setup the attributes
		const {
			attributes: {
				tabTitle,
				tabOpen,
				tabInstanceId,
			},
			isSelected,
			className,
			setAttributes,
			instanceId,
		} = props;

		props.attributes.tabInstanceId = 'nlsn-tab-' + instanceId;

		return [

			isSelected && (
				<InspectorControls>
					<Inspector
						{ ...props }
					/>
				</InspectorControls>
			),

			<div className={ className }>

				{ tabOpen ? (
					<div className='tab-open'>
						`Open by Default`
					</div>
				) : null }

				<div className={ classnames( 'tab-title', blockClasses) }>
					<a className= { classnames( 'nav-link', 'text-center' ) }>
							<RichText
								multiline='false'
								style={ { lineHeight: "normal" } }
								placeholder={ __( 'Tab Title' ) }
								value={ tabTitle }
								formattingControls={ [] }
								onChange={ ( value ) => setAttributes(
									{
										tabTitle: value
									}
								)}
							/>
					</a>

					<div className="card-block">
						<InnerBlocks templateLock={ false }/>
					</div>

				</div>
			</div>

		]
	}),

	// Save the attributes and markup
	save: props => {

		// Setup the attributes
		const {
			attributes: {
				tabTitle,
				tabOpen,
				tabInstanceId,
			},
			className,
		} = props;

		let selectTabOpen = {'active': tabOpen}
		let selectTabContentOpen = {'show': tabOpen}

		return (

			<li className={ classnames( 'tab-title', blockClasses ) }>
				{ tabTitle ? (
					<a className= { classnames( 'tab', 'nav-link', selectTabOpen) } role="tab" data-toggle="tab" aria-controls={"#" +  tabInstanceId } href={ "#" +  tabInstanceId }  >
						{ tabTitle }
					</a>
				):(
					null
				) }
				{ tabTitle ? (
					<div id={ tabInstanceId } className={ classnames( 'tab-pane fade', selectTabOpen, selectTabContentOpen) } role="tabpanel">
						<InnerBlocks.Content/>
					</div>
				):(
					null
				)}

			</li>

		);
	},

	deprecated : [
		{

		},
	]
} );
