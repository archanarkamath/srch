/**
 * Internal block libraries
 */
const { __ } = wp.i18n;
const { Component } = wp.element;

const {
  PanelBody,
	PanelRow,
  ToggleControl,
} = wp.components;


/**
 * Create an Inspector Controls wrapper Component
 */
export default class Inspector extends Component {

	constructor( props ) {
		super( ...arguments );
	}

	render() {

		// Setup the attributes
		const { attributes: { tabOpen }, setAttributes } = this.props;

		return (
      <PanelBody title={ __( 'Panel Settings' ) }>
        <ToggleControl
  				label={ __( 'Open by default' ) }
  				checked={ tabOpen }
  				onChange={ () => this.props.setAttributes( { tabOpen: ! tabOpen } ) }
  			/>
      </PanelBody>
		);
	}
}
