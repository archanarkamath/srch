const attributes = {
  tabTitle: {
    type: 'text',
  },
  tabOpen: {
    type: 'boolean',
    default: false
  },
  tabInstanceId: {
    type: 'text',
  }
};

export default attributes;
