/**
 * Gutenberg Blocks
 *
 * All blocks related JavaScript files should be imported here.
 * You can create a new block folder in this dir and include code
 * for that block here as well.
 *
 * All blocks should be included here since this is the file that
 * Webpack is compiling as the input file.
 */

import './i18n.js';

// Nicolai blocks
import './nlsn-tabs-container/block.js';
import './nlsn-tab/block.js';

// Andrew blocks
import './nlsn-image-slider/block.js';
import './nlsn-accordion-tab/block.js';
import './nlsn-accordion/block.js';
import './nlsn-callout/block.js';
import './nlsn-profile/block.js';

// Edison blocks
import './nlsn-container/block.js';
import './nlsn-editor-with-image/block.js';
import './nlsn-blockquote/block.js';
import './nlsn-embed/block.js';
import './nlsn-slider/block.js';
import './nlsn-slide-editor-with-image/block.js';
import './nlsn-columns/block.js';
import './nlsn-columns-inner/block.js';
import './nlsn-template-2-columns/block.js';
import './nlsn-layouts/block.js';
import './nlsn-subheading/block.js';
import './nlsn-hero-slider/block.js';
import './nlsn-hero-slide/block.js';
import './nlsn-popup/block.js';
import './nlsn-feed-smart-list/block.js';
// Block Styles
import './block-styles/block.js';

//Hongzhe Blocks
import './nlsn-button/block.js';
import './nlsn-sticky-nav/block.js';
import './nlsn-custom-list/block.js';
import './nlsn-animated-callout/block.js';
import './nlsn-custom-slider/block.js';

// Ryan's Blocks
import './nlsn-info-box/block.js';
import './nlsn-heading/block.js';
import './nlsn-banner/block.js';

// Spencer blocks
import './nlsn-client-login/block.js';

// Extensions for Core Blocks
import './core-block-extensions/highlight-color.js'; // Prapti

/**
 * Import Editor stylesheet
 */
import './editor.scss';
