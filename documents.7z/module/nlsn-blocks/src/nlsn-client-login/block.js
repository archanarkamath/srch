/**
 * BLOCK: Client Login
 */

// Block dependencies
import defineClassNames from '../utilities/defineClasses';
import attributes from './attributes';
import icon from './icon';

// Import all of our Container Options requirements.
import ContainerOptions, {
	ContainerOptionsAttributes,
} from '../components/container-options';

// Components
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks

// Register editor components
const {
	InspectorControls,
	PlainText,
} = wp.blockEditor;

registerBlockType( 'nlsn-blocks/nlsn-client-login', {
	title: __( 'Client Login - NLSN', 'nlsn-blocks' ),
	description: __( 'Add the client login.', 'nlsn-blocks' ),
	icon: icon,
	category: 'nielsen-blocks',
	keywords: [
		__( 'client', 'nlsn-blocks' ),
		__( 'login', 'nlsn-blocks' ),
	],
    attributes: {
        ...attributes,
		...ContainerOptionsAttributes,
    },

    /**
     * The edit function describes the structure of your block in the context of the editor. This
     * represents what the editor will render when the block is used.
     * @see https://wordpress.org/gutenberg/handbook/designers-developers/developers/block-api/block-edit-save/
     */
    edit: props => {
		const {
			attributes: {
				placeholderUserName,
                placeholderUserPass,
                formIntro,
                formForgotPass,
                formSubmit,
                containerSettings,
			},
			setAttributes,
        } = props;

        const classes = defineClassNames( props, 'container' );

        return (
            <div className={ classes.container }>
                <div id={ classes.id } className={ classes.container }>
                    <div className="container">
                        <div className='row justify-content-center'>
                            <div className={ classes.width }>
                                <InspectorControls>
                                    <ContainerOptions
                                        { ...props }
                                        />
                                </InspectorControls>
                                <div className="row">
                                    <div className="col-12 mb-2">
                                        <PlainText
                                            value={ formIntro }
                                            onChange={ ( nextValue ) => setAttributes( { formIntro: nextValue } ) }
                                        />
                                    </div>
                                    <div className="col-sm-6 col-12">
                                        <PlainText
                                            className="input-placeholderUserName form-control"
                                            value={ placeholderUserName }
                                            onChange={ ( nextValue ) => setAttributes( { placeholderUserName: nextValue } ) }
                                        />
                                    </div>
                                    <div className="col-sm-6 col-12">
                                        <PlainText
                                            className="input-placeholderUserPass form-control"
                                            value={ placeholderUserPass }
                                            onChange={ ( nextValue ) => setAttributes( { placeholderUserPass: nextValue } ) }
                                        />
                                    </div>
                                </div>
                                <div className="row mt-4">
                                    <div className="col-sm-3">
                                        <PlainText
                                            className="input-placeholderUserName btn"
                                            value={ formSubmit }
                                            onChange={ ( nextValue ) => setAttributes( { formSubmit: nextValue } ) }
                                        />
                                    </div>
                                    <div className="col-sm-9">
                                        <PlainText
                                            className="input-placeholderUserName p-2"
                                            value={ formForgotPass }
                                            onChange={ ( nextValue ) => setAttributes( { formForgotPass: nextValue } ) }
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    },

    /**
    * The save function defines the way in which the different attributes should be combined into
    * the final markup, which is then serialized by Gutenberg into post_content.
    * @see https://wordpress.org/gutenberg/handbook/designers-developers/developers/block-api/block-edit-save/
    */
    save: props => {
    const {
        attributes: {
            placeholderUserName,
            placeholderUserPass,
            formIntro,
            formForgotPass,
            formSubmit,
            containerSettings,
        },
        className,
    } = props;

    const classes = defineClassNames( props, 'container', 'save' );

    return (
            <div id={ classes.id } className={ classes.container }>
                <div className="container">
                    <div className='row justify-content-center'>
						<div className={ classes.width }>
                            <p className='mb-1'>{ formIntro }</p>
                            <form method="POST" target="_blank" action='https://answers.nielsen.com/gateway/forms/login.fcc'>
                                <input name="partner" value="" type="hidden"></input>
                                <input name="realm" value="" type="hidden"></input>
                                <input name="target" value="https://answers.nielsen.com/portal/site/answers" type="hidden"></input>
                                <div className='row'>
                                    <div className='col-sm-6'>
                                        <input className='form-control' name='USER' aria-label="user" maxlength='250' type='email' placeholder={ placeholderUserName }></input>
                                    </div>
                                    <div className='col-sm-6 my-2 my-sm-0'>
                                        <input className='form-control' name='PASSWORD' aria-label="password" maxlength='250' type='password' placeholder={ placeholderUserPass }></input>
                                    </div>
                                </div>
                                <div className='row mt-2'>
                                    <div className='col-sm-3'>
                                        <input className='' type='submit' value={ formSubmit }></input>
                                    </div>
                                    <div className='col-sm-9 forgotPassword'>
                                        <a className='d-flex p-4' href="https://answers.nielsen.com/gateway/logon.htm#/forget-password/">{ formForgotPass }</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
    );
    }
} );
