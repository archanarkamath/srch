const attributes = {
	placeholderUserName: {
      type: 'string',
      default: 'Username',
    },
    placeholderUserPass: {
      type: 'string',
      default: 'Password',
    },
    formIntro: {
        type: 'string',
        default: 'Nielsen Answers Login',
    },
    formForgotPass: {
        type: 'string',
        default: 'Forgot your password?',
    },
    formSubmit: {
        type: 'string',
        default: 'Submit',
    }
};

export default attributes;
