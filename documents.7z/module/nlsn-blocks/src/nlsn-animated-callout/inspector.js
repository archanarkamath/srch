/**
 * Internal block libraries
 */
const { __ } = wp.i18n;
const { Component } = wp.element;
const {
  PanelColorSettings,
} = wp.blockEditor;

const {
  PanelBody,
	PanelRow,
  ToggleControl,
	BaseControl,
	ButtonGroup,
	IconButton,
} = wp.components;
/**
 * Create an Inspector Controls wrapper Component
 */
export default class Inspector extends Component {

  constructor() {
    super( ...arguments );
  }

  render() {
    const {
			attributes: {
				buttonTarget,
				buttonColor,
        alignment,
        titleAlign,
        popupEnable,
			},
			setAttributes
		} = this.props;

    // Button Alignment Options
		const buttonAlignment = {};
		buttonAlignment.alignment = [
		  { id: 1, value: 'left', label: 'Left', icon: 'editor-alignleft' },
		  { id: 2, value: 'right', label: 'Right', icon: 'editor-alignright' },
		];

    // Text Alignment Options
    const titleAlignOptions = {};
    titleAlignOptions.alignment = [
      { id: 1, value: 'left', label: 'Left', icon: 'editor-alignleft' },
      { id: 2, value: 'center', label: 'Center', icon: 'editor-aligncenter' },
      { id: 3, value: 'right', label: 'Right', icon: 'editor-alignright' },
    ];

    return (
      <PanelBody
				title={ __( 'Button Settings', 'nlsn-blocks' ) }
				initialOpen={ false }
			>

				<PanelRow>
					<BaseControl
						id={ 'callout-alignment' }
						className={ 'alignment-button-group' }
						label={ `Align ${alignment}` }
					>
						{ buttonAlignment.alignment.map( type => {
							return (
								<IconButton
									key={ type.id }
									icon={ type.icon }
									label={ __( type.label, 'nlsn-blocks' ) }
									style={ { display: 'd-inline', float: 'left' } }
									isPrimary={ alignment === type.value }
									aria-pressed={ alignment === type.value }
									onClick={ () => { setAttributes({ alignment: type.value } ) } }
								/>
							);
						})}
					</BaseControl>
				</PanelRow>

				<PanelRow>
					<ToggleControl
						label={ __( 'Enable Popup window', 'nlsn-blocks' ) }
						checked={ popupEnable }
						help={ popupEnable ? __( 'Popup Button enabled', 'nlsn-blocks' ) : __( 'Popup Button disabled', 'nlsn-blocks' ) }
						onChange={ popupEnable => setAttributes( { popupEnable } ) }
					/>
				</PanelRow>

				{ !popupEnable &&
					<PanelRow>
						<ToggleControl
							label={ __( 'New Window', 'nlsn-blocks' ) }
							checked={ buttonTarget }
							help={ __( 'Open button link in new window?', 'nlsn-blocks' ) }
							onChange={ buttonTarget => setAttributes( { buttonTarget } ) }
						/>
					</PanelRow>
				}
      </PanelBody>
    );
  }
}
