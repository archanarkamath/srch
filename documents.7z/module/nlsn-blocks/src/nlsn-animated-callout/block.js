/**
 * BLOCK: Animated Callout
 */

// Block dependencies
import classnames from 'classnames';
import defineClassNames from '../utilities/defineClasses';
import Inspector from './inspector';
import attributes from './attributes';
// import './editor.scss';

import { link, megaphone, keyboardReturn } from '@wordpress/icons';

// Import all of our Container Options requirements.
import ContainerOptions, {
	ContainerOptionsAttributes,
	HideSectionEdit,
	BlockIdEdit,
	NLSNHeading,
} from '../components/container-options';

import { colors } from '../components/colors/colorUtils';

// Register editor components
const {
	InspectorControls,
	RichText,
	URLInput,
	getColorObjectByColorValue,
	PanelColorSettings,
	InnerBlocks,
} = wp.blockEditor;

const {
	IconButton,
	Icon,
	Tooltip,
	ToggleControl,
	RangeControl,
	BaseControl,
	PanelRow,
	PanelBody,
} = wp.components;

const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks
const { withInstanceId } = wp.compose;


const blockClasses = classnames(
	'animated-callout',
	'd-flex justify-content-center flex-column',
);

// Register: Call to action
registerBlockType( 'nlsn-blocks/nlsn-animated-callout', {
	title: __( 'Animated Callout - NLSN', 'nlsn-blocks' ),
	description: __( 'This is an Animated Callout block. The block has Timer effect and Viewport effect. After an effect, the block will be sticky fullwidth or sidebar ', 'nlsn-blocks' ),
	icon: megaphone,
	category: 'nielsen-blocks',
	keywords: [
		__( 'animated callout', 'nlsn-blocks' ),
		__( 'popup', 'nlsn-blocks' ),
		__( 'action', 'nlsn-blocks' ),
		__( 'nielsen', 'nlsn-blocks' ),
	],
	attributes: {
		...attributes,
		...ContainerOptionsAttributes,
	},

	/**
	 * Determines what is displayed in the editor.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 * @param {Object} props - The properties that are available to this block.
	 * @returns {Object} - How the block will display in the Gutenberg editor.
	 */
	edit: withInstanceId (
		props => {
		const {
			attributes: {
				containerSettings,
				headingContent,
				calloutText,
				buttonURL,
				buttonTitle,
				buttonColor,
				alignment,
				titleAlign,
				enableSidebar,
				displayTimeout,
				popupTimer,
				popupBorder,
				popupExpire,
				popupDateZoned,
				sidebarWidth,
				popupEnable,
			},
			isSelected,
			className,
			setAttributes,
			instanceId,
		} = props;

		const classes = defineClassNames( props, 'animated-callout' );

		let buttonAlign = '';
		let calloutTitleAlign = '';

		buttonAlign = classnames(
			'd-flex',
			'justify-content-center',
			{ 'flex-row-reverse': alignment === 'left' },
			{ '': alignment === 'right' },

		);

		calloutTitleAlign = classnames(
			{ 'text-left': alignment === 'left' },
			{ 'text-right': alignment === 'right' },
			{ 'text-center': alignment === 'center' },

		);

		// get color object
		const buttonColorObject = getColorObjectByColorValue( colors, buttonColor );
		let buttonColorName = '';

		( buttonColorObject && buttonColorObject !== undefined ? (
			// get 'slug' value from color object
			buttonColorName = buttonColorObject.slug
		) : null )

		const buttonClasses = classnames(
			'btn',
			`btn-${ buttonColorName }`,
		);

    const borderStyle = {
      border: '1px dashed black',
    };

		props.attributes.popupItemId = 'animated-callout-item-' + instanceId;

		// Text Alignment Options
		const titleAlignOptions = {};
		titleAlignOptions.alignment = [
			{ id: 1, value: 'left', label: 'Left', icon: 'editor-alignleft' },
			{ id: 2, value: 'center', label: 'Center', icon: 'editor-aligncenter' },
			{ id: 3, value: 'right', label: 'Right', icon: 'editor-alignright' },
		];

		// Return the markup displayed in the editor.
		return (
			<div key="editor-display" className={ className }>

				{ isSelected &&
					<InspectorControls>
						<ContainerOptions
							{ ...props }
						/>

						<PanelBody
							title={ __( 'Display Options', 'nlsn-blocks' ) }
							initialOpen={ false }
						>
							<PanelRow>
								<ToggleControl
									label={ __( 'Switch Popup position', 'nlsn-blocks' ) }
									checked={ enableSidebar }
									help={ ( checked ) => checked ? __( 'Sticky Sidebar Enabled.', 'nlsn-blocks' ) : __( 'Sticky Fullwidth Enabled.', 'nlsn-blocks' ) }
									onChange={ enableSidebar => setAttributes( { enableSidebar } ) }
								/>
							</PanelRow>
							{	enableSidebar &&
								<PanelRow>
									<RangeControl
											label="Sidebar Width(px)"
											value={ sidebarWidth }
											onChange={ ( sidebarWidth ) => setAttributes( { sidebarWidth } ) }
											min={ 200 }
											max={ 500 }
											initialPosition={ 300 }

									/>
								</PanelRow>
							}
							<PanelRow>
								<ToggleControl
									label={ displayTimeout ? __( 'Switch to Viewport effect', 'nlsn-blocks' ) : __( 'Switch to Timer effect', 'nlsn-blocks' ) }
									checked={ displayTimeout }
									help={ displayTimeout ? __( 'Timer effect enabled. Popup will display after timeout', 'nlsn-blocks' ) : __( 'Viewport enabled. Popup will display after reaching viewport', 'nlsn-blocks' ) }
									onChange={ displayTimeout => setAttributes( { displayTimeout } ) }
								/>
							</PanelRow>

						{	displayTimeout &&
							<PanelRow>
								<RangeControl
										label="Timeout Seconds"
										value={ popupTimer }
										onChange={ ( popupTimer ) => setAttributes( { popupTimer } ) }
										min={ 20 }
										max={ 60 }
										initialPosition={ 20 }
								/>
							</PanelRow>
						}
							<PanelRow>
								<ToggleControl
									label={ __( 'Toggle Border option', 'nlsn-blocks' ) }
									checked={ popupBorder }
									onChange={ ( popupBorder ) => setAttributes( { popupBorder } ) }
									help={ ( checked ) => checked ? __( 'Border Enabled.', 'nlsn-blocks' ) : __( 'Border Disabled.', 'nlsn-blocks' ) }
								/>
							</PanelRow>							

							<PanelRow>
								<PanelColorSettings
									title={ __( 'Color Settings', 'nlsn-blocks' ) }
									colorSettings={ [
										{
											value: buttonColor,
											onChange: ( buttonColor ) => setAttributes( { buttonColor } ),
											label: __( 'Button/Border Color', 'nlsn-blocks' ),
										},
									] }
								>
								</PanelColorSettings>
							</PanelRow>
						</PanelBody>

						<PanelBody
							title={ __( 'Text Align Options', 'nlsn-blocks' ) }
							initialOpen={ false }
						>
							<PanelRow>
								<BaseControl
									id={ 'callout-title-align' }
									className={ 'alignment-text-group' }
									label={ `Title Align ${titleAlign}` }
								>
									{ titleAlignOptions.alignment.map( type => {
										return (
											<IconButton
												key={ type.id }
												icon={ type.icon }
												label={ __( type.label, 'nlsn-blocks' ) }
												style={ { display: 'd-inline', float: 'left' } }
												isPrimary={ titleAlign === type.value }
												aria-pressed={ titleAlign === type.value }
												onClick={ () => { setAttributes({ titleAlign: type.value } ) } }
											/>
										);
									} ) }
								</BaseControl>
							</PanelRow>
						</PanelBody>

						<Inspector
							{ ...props }
						/>
					</InspectorControls>
				}


				{ containerSettings &&
					<div className="container-settings">
						<BlockIdEdit
							{ ...props }
						/>
						<HideSectionEdit
							{ ...props }
						/>
					</div>
				}

				<div
					// className={ enableSidebar ? classes.container + ` popup-${ buttonColorName }` + " module-sidebar" : classes.container + ` popup-${ buttonColorName }` }
					className={ classes.container + ` popup-${ buttonColorName }` + (enableSidebar ? " module-sidebar" : "") + (popupBorder ? " hasBorder" : "") }
					id={ classes.id }
					>
					<div className="container">
						<div className={ classes.width }>
							<div className={ classnames( blockClasses ) }>
								<div className={ "align-self-center" + ( titleAlign ? ' align-title-' + titleAlign : '' ) }>

									{ ( ( headingContent && headingContent.length > 0 ) || isSelected ) &&
										<div className="headingWrapper"
										>
											<NLSNHeading.edit { ...props } />
										</div>
									}

								</div>
                <div className={ enableSidebar ? "justify-content-center " : "row justify-content-center " + buttonAlign}>
                  <div className={ !enableSidebar ? "col-4" : "text-center"} style={ borderStyle}>
                    <RichText
                      tagName='div'
                      multiline='p'
                      className={ classnames(
                        'callout-text p-2'
                      ) }
                      placeholder={ __( 'Add Message', 'nlsn-blocks' ) }
                      value={ calloutText }
                      onChange={ value => {
                        setAttributes( { calloutText: value } );
                      } }
                    />
                  </div>
                	<div className={ !enableSidebar ? "col-1" : ""} />
									<div className={ enableSidebar ? "callout-button text-center p-2" : "callout-button col-4 align-self-center p-2" } style={ borderStyle }>
									<div className={ popupEnable ? "popup-button" : ""}		>
										{
											<div
												style={ { display: 'inline-block' } }
											>
												<RichText
													tagName="p"
													multiline="false"
													className={ popupEnable ? classnames( 'content-button', 'btn', 'btn-popup', buttonClasses): classnames( 'callout-link', buttonClasses ) }
													placeholder={ __( 'Button Title', 'nlsn-blocks' ) }
													value={ buttonTitle }
													onChange={ value => setAttributes( { buttonTitle: value } ) }
												/>
											</div>
										 }
										{
											popupEnable ? (
												<div className="popup-content">
													<InnerBlocks />
												</div>
											):(
											isSelected && (

											<form
												id="buttonUrl"
												className="button-url"
												onSubmit={ event => event.preventDefault() }
											>
												<Tooltip
													text="Add Link"
													children="url"
												>
													<Icon icon={ link } />
													<label htmlFor="buttonUrl">{ __( ' Add Link', 'nlsn-blocks' ) }</label>
												</Tooltip>

												<URLInput
													className={ classnames( enableSidebar ? "url url-sidebar" : "url url-fullwidth" ) }
													value={ buttonURL }
													onChange={ value => setAttributes( { buttonURL: value } ) }
												/>
												<IconButton
													icon={ keyboardReturn }
													label={ __( 'Apply', 'nlsn-blocks' ) }
													type="submit"
												/>
											</form>
										 )
										) }
									</div>
								 </div>
                </div>
							</div>
						</div>
					</div>
				</div>
			</div>
		)
	} ),

	/**
	 * Determines what is displayed on the front-end.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 * @param {Object} props - The properties that are available to this block.
	 * @returns {Object} - How the block will display on the front-end.
	 */
	save: props => {
		const {
			attributes: {
				calloutText,
				buttonURL,
				buttonTarget,
				buttonTitle,
				buttonColor,
				backgroundColor,
				alignment,
				titleAlign,
				enableSidebar,
				sidebarWidth,
				displayTimeout,
				popupTimer,
				popupBorder,
				popupExpire,
				popupDateZoned,
				popupEnable,
				popupItemId,
			},
			className,
			setAttributes,
		} = props;

		// console.log( moment().format(), moment.tz( theDate, postTimezone ).format(), moment().isAfter( moment.tz( props.attributes.popupDate, postTimezone ).format() ) );

		const classes = defineClassNames( props, 'animated-callout', 'save' );

		let buttonAlign = '';

		buttonAlign = classnames(
			'd-flex',
			'justify-content-center',
			{ 'flex-row-reverse': alignment === 'left' },
			{ '': alignment === 'right' },

		);

		let linkTarget = '';
		buttonTarget === true ? linkTarget = '_blank' : linkTarget = null;

		let relAttr = '';
		linkTarget && linkTarget !== undefined ? relAttr = 'noopener noreferrer' : relAttr = null;

		// get color object
		const buttonColorObject = getColorObjectByColorValue( colors, buttonColor );
		let buttonColorName = '';

		( buttonColorObject && buttonColorObject !== undefined ? (
			// get 'slug' value from color object
			buttonColorName = buttonColorObject.slug
		) : null )

		const buttonClasses = classnames(
			'btn',
			`btn-${ buttonColorName }`,
		);

		const closeBtnClasses = classnames(
			`bg-${ buttonColorName }`,
		)

		return (
			<div
						id={ classes.id }
						className={
							className + (enableSidebar ? " sticky-sidebar" : " sticky-fullwidth") + (!displayTimeout ? " viewport" : "")
						}
						style={ { width: `${sidebarWidth}px` } }
						data-timer={ displayTimeout ? popupTimer : "0" }
						data-expire={ popupExpire ? popupDateZoned : "" }
				>
				<div
					className={ classes.container + ` popup-${ buttonColorName }` + (popupBorder ? " hasBorder" : "") }
				>
				<button
					type="button"
					className={ enableSidebar ? "Close popup-close fixed-top": "Close popup-close"}
					aria-label="close"
					>
					<span aria-hidden="true">&times;</span>
				 </button>
					<div className="container">
						<div className="row justify-content-center">
							<div className={ classes.width }>
								<div className={ popupEnable ? classnames( 'popup-container', blockClasses ) : classnames( blockClasses ) }>
									<div className={ "align-self-center animated-callout-title" + ( titleAlign ? ' align-title-' + titleAlign : '' ) }>
										<NLSNHeading.save { ...props } />
									</div>

									<div className ={ enableSidebar ? "justify-content-center": "row justify-content-center " + buttonAlign}>
										<div className={ enableSidebar ? "callout-text text-center col-sm-12" : "callout-text popup-text col-md-3 col-sm-12"}>
											{ calloutText }
										</div>
									{ ( buttonTitle && buttonTitle.length > 0 ) && (
										<div className={ enableSidebar ? "callout-button justify-content-center d-flex col-sm-12" : "callout-button justify-content-center text-center d-flex col-md-3 col-sm-12"}>
											<div className={ popupEnable ? "popup-button custom-button" : "custom-button" }>
												<RichText.Content
													tagName='a'
													className={ popupEnable ? classnames( 'content-button', 'btn', 'btn-popup', 'callout-link animated-callout-link', buttonClasses )
													: classnames( 'callout-link animated-callout-link', buttonClasses ) }
													href={ popupEnable ? '#' + popupItemId : buttonURL }
													target={ !popupEnable ? linkTarget : "" }
													rel={ relAttr }
													value={ buttonTitle }
												/>
											</div>
										</div>
									) }
									{
										popupEnable && (
											<div
												id={ popupItemId }
												className="popup-content container mfp-hide"
											>
												<div className="module alignfull not-alignfull bg-white">
													<div className="container">
														<div className="row">
															<div className="col">
																<InnerBlocks.Content />
															</div>
														</div>
													</div>
												</div>
											</div>
										)
									}
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		);
	 },
	deprecated: [
	 {
		 attributes: {
	 		...attributes,
	 		...ContainerOptionsAttributes,
	 	},

		 save: props => {
	 const {
		 attributes: {
			 calloutText,
			 buttonURL,
			 buttonTarget,
			 buttonTitle,
			 buttonColor,
			 backgroundColor,
			 alignment,
			 enableSidebar,
			 sidebarWidth,
			 displayTimeout,
			 popupTimer,
			 popupBorder,
			 popupEnable,
			 popupItemId,
		 },
		 className,
		 setAttributes,
	 } = props;

	 const classes = defineClassNames( props, 'animated-callout', 'save' );

	 let buttonAlign = '';

	 buttonAlign = classnames(
		 'd-flex',
		 'justify-content-center',
		 { 'flex-row-reverse': alignment === 'left' },
		 { '': alignment === 'right' },

	 );

	 let linkTarget = '';
	 buttonTarget === true ? linkTarget = '_blank' : linkTarget = null;

	 let relAttr = '';
	 linkTarget && linkTarget !== undefined ? relAttr = 'noopener noreferrer' : relAttr = null;

	 // get color object
	 const buttonColorObject = getColorObjectByColorValue( colors, buttonColor );
	 let buttonColorName = '';

	 ( buttonColorObject && buttonColorObject !== undefined ? (
		 // get 'slug' value from color object
		 buttonColorName = buttonColorObject.slug
	 ) : null )

	 const buttonClasses = classnames(
		 'btn',
		 `btn-${ buttonColorName }`,
	 );

	 const closeBtnClasses = classnames(
		 `bg-${ buttonColorName }`,
	 )

	 return (
		 <div
					 id={ classes.id }
					 className={
						 className + (enableSidebar ? " sticky-sidebar" : " sticky-fullwidth") + (!displayTimeout ? " viewport" : "")
					 }
					 style={ { width: `${sidebarWidth}px` } }
					 data-timer={ displayTimeout ? popupTimer : "0" }
			 >
			 <div
				 className={ classes.container + ` popup-${ buttonColorName }` + (popupBorder ? " hasBorder" : "") }
			 >
			 <button
				 type="button"
				 className={ enableSidebar ? "Close popup-close fixed-top": "Close popup-close"}
				 aria-label="close"
				 >
				 <span aria-hidden="true">&times;</span>
				</button>
				 <div className="container">
					 <div className="row justify-content-center">
						 <div className={ classes.width }>
							 <div className={ popupEnable ? classnames( 'popup-container', blockClasses ) : classnames( blockClasses ) }>
								 <div className="align-self-center animated-callout-title">
									 <NLSNHeading.save { ...props } />
								 </div>

								 <div className ={ enableSidebar ? "justify-content-center": "row justify-content-center " + buttonAlign}>
									 <div className={ enableSidebar ? "callout-text text-center col-sm-12" : "callout-text popup-text col-md-3 col-sm-12"}>
										 { calloutText }
									 </div>
								 { ( buttonTitle && buttonTitle.length > 0 ) && (
									 <div className={ enableSidebar ? "callout-button justify-content-center d-flex col-sm-12" : "callout-button justify-content-center text-center d-flex col-md-3 col-sm-12"}>
										 <div className={ popupEnable ? "popup-button custom-button" : "custom-button" }>
											 <RichText.Content
												 tagName='a'
												 className={ popupEnable ? classnames( 'content-button', 'btn', 'btn-popup', 'callout-link animated-callout-link', buttonClasses )
												 : classnames( 'callout-link animated-callout-link', buttonClasses ) }
												 href={ popupEnable ? '#' + popupItemId : buttonURL }
												 target={ !popupEnable ? linkTarget : "" }
												 rel={ relAttr }
												 value={ buttonTitle }
											 />
										 </div>
									 </div>
								 ) }
								 {
									 popupEnable && (
										 <div
											 id={ popupItemId }
											 className="popup-content container mfp-hide"
										 >
											 <div className="module alignfull not-alignfull bg-white">
												 <div className="container">
													 <div className="row">
														 <div className="col">
															 <InnerBlocks.Content />
														 </div>
													 </div>
												 </div>
											 </div>
										 </div>
									 )
								 }
								 </div>
							 </div>
						 </div>
					 </div>
				 </div>
			 </div>
		 </div>
	 );
	},
	 },
 ]
} );
