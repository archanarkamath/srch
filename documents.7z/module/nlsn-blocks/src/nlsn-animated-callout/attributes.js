const attributes = {
	calloutText: {
		type: 'array',
		source: 'children',
		selector: '.callout-text',
		default: '',
	},
	buttonURL: {
		type: 'string',
		default: '',
	},
	buttonTarget: {
		type: 'boolean',
		default: true,
	},
	buttonTitle: {
		type: 'string',
		source: 'html',
		selector: '.callout-link',
	},
	buttonColor: {
		type: 'string',
		default: '',
	},
	sidebarWidth: {
		type: 'number',
		default: '300',
	},
	backgroundColor: {
		type: 'string',
		default: '',
	},
	alignment: {
		type: 'string',
		default: 'center',
	},
	titleAlign: {
		type: 'string',
		default: 'left',
	},
	enableSidebar: {
		type: 'boolean',
		default: false,
	},
	titleAlign: {
		type: 'string',
		default: '',
	},
	displayTimeout: {
		type: 'boolean',
		default: false,
	},
	popupTimer: {
		type: 'number',
		default: '20',
	},
	popupBorder: {
		type: 'boolean',
		default: false,
	},
	popupEnable: {
		type: 'boolean',
		default: false,
	},
	popupItemId: {
		type: 'string',
	},
};

export default attributes;
