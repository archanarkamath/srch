<?php
/**
 * Helpers
 *
 */

/**
 * Custom Excerpt Length
 *
 * Use a post's excerpt to output a custom-length version of the excerpt.
 * The length (character-count) of the excerpt can be customized when running this function if a value is provided.
 *
 * If the excerpt length is longer than the specified character-count,
 * then trim the excerpt based on the character-count provided and add an ellipsis (...) - the Trailing Dots.
 *
 * @param variable $post_excerpt          The variable name that references the excerpt of the current post selected.
 * @param int      $post_excerpt_count    The number(integer) of characters to count before the excerpt is trimmed. Default is '215'
 *
 * @return string  $custom_excerpt_length  Print the custom-length version of the excerpt.
 *
 *
 * <sample>
 *
 * $my_post_excerpt = get_the_excerpt();
 * nlsn_custom_excerpt_length( $my_post_excerpt, '190' );
 *
 * </sample>
 *
 */
function nlsn_custom_excerpt_length( $post_excerpt, $post_excerpt_count = 300 ) {
	// Strip tags to better sanitize the excerpt
	$custom_excerpt_length = wp_strip_all_tags( $post_excerpt );
	// Custom excerpt length
	if ( strlen( $custom_excerpt_length ) > $post_excerpt_count ) {
		// truncate string
		$stringCut = substr( $custom_excerpt_length, 0, $post_excerpt_count );
		// make sure it ends in a complete word
		$custom_excerpt_length = substr( $stringCut, 0, strrpos( $stringCut, ' ' ) ) . '...';
	}

	return $custom_excerpt_length;
}
