/**
 * Internal block libraries
 */
const { __ } = wp.i18n;
const { Component, Fragment } = wp.element;

const {
  PanelBody,
	BaseControl,
	Button,
	ButtonGroup,
  ToggleControl,
	RangeControl,
	TextControl,
} = wp.components;

/**
 * Create an Inspector Controls wrapper Component
 */
export default class Inspector extends Component {

  constructor() {
    super( ...arguments );
  }

  render() {
    const {
    	attributes: {
				postsToShow,
				columns,
				blockLayout,
				displayPostContent,
				displayPostDate,
				dateFormat,
				postLinkTarget,
				customPostLink,
				postLinkText,
				displayViewAllLink,
				viewAllLink,
				viewAllText,
			},
			setAttributes
    } = this.props;

		// Options
		const options = {
			dateFormat: [
				{ label: '05-17-2016', value: 'm-d-Y' },
				{ label: '17-05-2016', value: 'd-m-Y' },
				{ label: '2016-17-05', value: 'Y-d-m' },
				{ label: '2016-05-17', value: 'Y-m-d' },
			],
		};

    return (
    	<Fragment>
				<PanelBody
					title={ __( 'Feed Smart List Settings', 'nlsn-blocks' ) }
					initialOpen={ true }
				>

					<RangeControl
						label={ __( 'Number of posts', 'coblocks' ) }
						value={ postsToShow }
						onChange={ postsToShow  => setAttributes( { postsToShow } ) }
						min={ 2 }
						max={ 10 }
						beforeIcon={ 'image-flip-horizontal' }
					/>

					{ ( blockLayout === 'grid' || blockLayout === 'carousel' ) &&
						<RangeControl
							label={ __( 'Columns', 'nlsn-blocks' ) }
							value={ columns }
							onChange={ columns => setAttributes( { columns } ) }
							min={ 2 }
							max={ 4 }
							beforeIcon={ 'image-flip-horizontal' }
						/>
					}

					<ToggleControl
						label={ __( 'Display Date', 'nlsn-blocks' ) }
						checked={ displayPostDate }
						onChange={ () => setAttributes( { displayPostDate: ! displayPostDate } ) }
					/>

					{ displayPostDate &&
						<BaseControl
							id="date-format"
							label={ __( 'Date Format', 'nlsn-blocks' ) }
						>
							<ButtonGroup
								id="date-format"
								aria-label={ __( 'Date Format', 'nlsn-blocks' ) }
								className="date-format"
							>
								{ options.dateFormat.map( format => {
									return (
										<Button
											key={ format.label }
											isPrimary={ dateFormat === format.value }
											aria-pressed={ dateFormat === format.value }
											onClick={ () => setAttributes( { dateFormat: format.value } ) }
										>
											{ format.label }
										</Button>
									);
								} ) }
							</ButtonGroup>
						</BaseControl>
					}

					<ToggleControl
						label={ __( 'Display Content', 'nlsn-blocks' ) }
						checked={ displayPostContent }
						onChange={ () => setAttributes( { displayPostContent: ! displayPostContent } ) }
					/>

					<ToggleControl
						label={ __( 'Open Links in New Window', 'nlsn-blocks' ) }
						checked={ postLinkTarget }
						help={
							postLinkTarget ?
								__( 'Links will open in new windows', 'nlsn-blocks' ) :
								__( 'Toggle to open links in new windows', 'nlsn-blocks' )
						}
						onChange={ () => setAttributes( { postLinkTarget: ! postLinkTarget } ) }
					/>

					<ToggleControl
						label={ __( 'Custom Post Link', 'nlsn-blocks' ) }
						checked={ customPostLink }
						help={
							customPostLink ?
								__( 'Enabled additional fields below.', 'nlsn-blocks' ) :
								__( 'Toggle to customize the post link.', 'nlsn-blocks' )
						}
						onChange={ () => setAttributes( { customPostLink: ! customPostLink } ) }
					/>

					{ customPostLink &&
						<TextControl
							label={ __( 'Post Link Text', 'nlsn-blocks' ) }
							help={ __( 'Text will be the same for each item in the feed', 'nlsn-blocks' ) }
							placeholder={ __( 'Read More', 'nlsn-blocks' ) }
							value={ postLinkText }
							onChange={ postLinkText  => setAttributes( { postLinkText } ) }
						/>
					}

					<ToggleControl
						label={ __( 'View All Link', 'nlsn-blocks' ) }
						checked={ displayViewAllLink }
						help={
							displayViewAllLink ?
								__( 'Enabled additional fields below', 'nlsn-blocks' ) :
								__( 'Toggle to enable the "View All" link.', 'nlsn-blocks' )
						}
						onChange={ () => setAttributes( { displayViewAllLink: ! displayViewAllLink } ) }
					/>

					{ displayViewAllLink &&
						<Fragment>
							<TextControl
								label={ __( 'View All Link', 'nlsn-blocks' ) }
								help={ __( 'View All button will not be displayed unless a Link/URL has been provided!', 'nlsn-blocks' ) }
								placeholder={ __( 'https://example.com/blog', 'nlsn-blocks' ) }
								value={ viewAllLink }
								onChange={ viewAllLink  => setAttributes( { viewAllLink } ) }
							/>
							<TextControl
								label={ __( 'View All Link Text', 'nlsn-blocks' ) }
								placeholder={ __( 'View All', 'nlsn-blocks' ) }
								value={ viewAllText }
								onChange={ viewAllText  => setAttributes( { viewAllText } ) }
							/>
						</Fragment>
					}
				</PanelBody>
			</Fragment>
		);
  }
}
