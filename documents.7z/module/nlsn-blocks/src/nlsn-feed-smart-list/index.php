<?php
/**
 * Server-side rendering of the `nlsn-blocks/nlsn-feed-smart-list` block.
 *
 * @package gutenberg
 */

/**
 * Renders the `nlsn-blocks/nlsn-feed-smart-list` block on server.
 *
 * @param array $attributes The block attributes.
 *
 * @return string Returns the block content.
 */
function nlsn_blocks_render_feed_smart_list_block( $attributes ) {

	/*
	 * Build Classes
	 */
	// Block classes
	$block_classes = 'wp-block-nlsn-blocks-nlsn-feed-smart-list nlsn-feed-smart-list';
	// Layout Classes
	$layout_classes = 'block-layout feed-layout';
	// Feed Item Classes
	$feed_item_classes = 'nielsen-post feed-item';
	// Grid Title Classes
	$feed_item_title_classes = 'entry-title slide-title post-title mb-3';
	// Data Columns
	$data_columns = '';
	// Bootstrap Columns Width
	$columns_width = 'col-md-12';

	// Assign proper classes
	if ( isset( $attributes['align'] ) ) {
		$block_classes .= ' text-' . $attributes['align'];
	}
	if ( isset( $attributes['blockLayout'] ) && 'list' === $attributes['blockLayout'] ) {
		$block_classes .= ' is-list';
		$layout_classes .= ' layout-list';
		$feed_item_title_classes .= ' h2';
	}
	if ( isset( $attributes['blockLayout'] ) && 'grid' === $attributes['blockLayout'] ) {
		$block_classes .= ' is-grid';
		$layout_classes .= ' layout-grid container row';
	}
	if ( isset( $attributes['blockLayout'] ) && 'carousel' === $attributes['blockLayout'] ) {
		$block_classes .= ' is-carousel';
		$layout_classes .= ' layout-carousel feed-card-carousel owl-carousel';
		$columns_width = 'col-md-11';
	}
	// Include Gutenberg 'Advanced CSS Class(es)' panel
	if ( isset( $attributes['className'] ) ) {
		$block_classes .= ' ' . $attributes['className'];
	}

	// Assign column classes if the proper layout is selected
	if ( ( isset( $attributes['blockLayout'] ) ) && ( 'carousel' === $attributes['blockLayout'] || 'grid' === $attributes['blockLayout'] ) ) {
		if ( isset( $attributes['columns'] ) ) {
			$layout_classes .= ' columns-' . $attributes['columns'];
			$data_columns = $attributes['columns'];

			if ( 'grid' === $attributes['blockLayout'] ) {
				// Apply the proper column classes for each feed item
				$columnsNum = $attributes['columns'];
				switch ( $columnsNum ) {
					case 2:
						$feed_item_classes .= ' col-md-6 col-lg-6';
						break;
					case 3:
						$feed_item_classes .= ' col-md-6 col-lg-4';
						break;
					case 4:
						$feed_item_classes .= ' col-md-6 col-lg-3';
						break;
				}
			}
		}
	}

	// Get the post link target
	if ( $attributes['postLinkTarget'] ) {
		$post_link_target = '_blank';
	} else {
		$post_link_target = '_self';
	}

	// Get the post link text
	if ( $attributes['postLinkText'] ) {
		$post_link_text = $attributes['postLinkText'];
	} else {
		$post_link_text = __( 'Read More', 'nlsn-blocks' );
	}

	/*
	 * If enabled, and if a custom link has been provided, display a 'View All' link with
	 * the View-All-Link-Text provided.
	 * If no custom View-All-Link-Text is provided, assign a default 'View All'.
	 */

	// Feed VIew All Content
	$feed_view_all = '';

	if ( $attributes['displayViewAllLink'] ) {
		if ( $attributes['viewAllLink'] ) {
			$all_link = $attributes['viewAllLink'];
		} else {
			$all_link = __( '', 'nlsn-blocks' );
		}

		if ( $attributes['viewAllText'] ) {
			$all_link_text = $attributes['viewAllText'];
		} else {
			$all_link_text = __( 'View All', 'nlsn-blocks' );
		}

		$all_link = esc_url( $all_link );
		if ( $all_link ) {
			$all_link = "<div class='read-more'><a href='{$all_link}' target='{$post_link_target}' class='more-link btn view-all'>{$all_link_text}</a></div>";
		}

		$feed_view_all .= $all_link;
	}

	// Feed List Items
	$feed_list_items = '';

	// Pull RSS Data
	if ( $attributes['feedUrl'] && 'rss' === $attributes['feedType'] ) {

		// Build SimplePie object based on RSS or Atom feed from URL.
		$rss_items = fetch_feed( urldecode( $attributes['feedUrl'] ) );

		// Checks if the object created is a WP Error
		if ( is_wp_error( $rss_items ) ) {
			return '<div class="components-placeholder"><div class="notice notice-error"><strong>' . __( 'RSS Error:', 'nlsn-blocks' ) . '</strong> ' . $rss_items->get_error_message() . '</div></div>';
		}

		if ( ! $rss_items->get_item_quantity() ) {
			// PHP 5.2 compatibility. See: http://simplepie.org/wiki/faq/i_m_getting_memory_leaks.
			$rss_items->__destruct();
			unset( $rss_items );

			return '<div class="components-placeholder"><div class="notice notice-error">' . __( 'Error, the feed may be down. Try again later.', 'nlsn-blocks' ) . '</div></div>';
		}

		// Build an array of all the items, starting with element 0 (first element) and ending with value provided by our attribute
		$rss_items = $rss_items->get_items( 0, $attributes['postsToShow'] );

		// Loop through each feed item
		foreach ( $rss_items as $rss_item ) {

			// Get the post title; if one is not found, assign custom title
			$title = esc_html( trim( wp_strip_all_tags( $rss_item->get_title() ) ) );
			if ( empty( $title ) ) {
				$title = __( '(No Title)', 'nlsn-blocks' );
			}

			// Get the post link
			$post_link = '';
			$get_post_link = $rss_item->get_link();
			if ( $get_post_link ) {
				$post_link = esc_url( $get_post_link );
			}

			/*
			 * If enabled, customize and display the post link with the custom Link-Text provided.
			 * If no custom Link-Text is provided, assign a default 'Read More'.
			 *
			 * If this is disabled however, display the post title hyperlinked.
			 */
			$custom_post_link = '';
			if ( $attributes['customPostLink'] ) {

				/*
				 * If layout is not 'carousel' create title hyperlinked
				 */
				if ( $post_link && isset( $attributes['blockLayout'] ) && 'carousel' !== $attributes['blockLayout'] ) {
					$title = "<a href='{$post_link}' target='{$post_link_target}' class=''>{$title}</a>";
				}

				// Create title and custom post link
				$title = "<h3 class='{$feed_item_title_classes}'>{$title}</h3>";
				$custom_post_link = "<div class='read-more'><a href='{$post_link}' target='{$post_link_target}' class='more-link'>{$post_link_text}</a></div>";

				/*
				 * If layout is 'carousel' create elements not hyperlinked
				 */
				if ( isset( $attributes['blockLayout'] ) && 'carousel' === $attributes['blockLayout'] ) {
					$custom_post_link = "<div class='read-more'>{$post_link_text}</div>";
				}

			} else {
				/*
				 * If layout is 'carousel' create elements not hyperlinked
				 */
				if ( isset( $attributes['blockLayout'] ) && 'carousel' === $attributes['blockLayout'] ) {
					$title = "<h3 class='{$feed_item_title_classes}'>{$title}</h3>";

				} else {
					// Else, create title hyperlinked
					if ( $post_link ) {
						$title = "<a href='{$post_link}' target='{$post_link_target}' class=''>{$title}</a>";
					}
					$title = "<h3 class='{$feed_item_title_classes}'>{$title}</h3>";
				}
			}

			// Get and create the date object
			$date = '';
			if ( $attributes['displayPostDate'] ) {
				$date = $rss_item->get_date( 'U' );

				if ( $date ) {
					$date = sprintf(
						'<div class="entry-meta h5"><time datetime="%1$s" class="nlsn-feed__item-publish-date knockout h5">%2$s</time> </div>',
						wp_date( 'c', $date ),
						wp_date( $attributes['dateFormat'], $date )
					);
				}
			}

			// Get and create the excerpt object
			$excerpt = '';
			if ( $attributes['displayPostContent'] ) {
				$excerpt = $rss_item->get_description();

				$excerpt = nlsn_custom_excerpt_length( $excerpt );
				$excerpt = esc_html( $excerpt );
			}
			$post_content = "<div class='entry-summary'>{$excerpt}{$custom_post_link}</div>";


			// Create Feed single list-item
			// If layout is 'carousel' create hyperlinked carousel item
			if ( isset( $attributes['blockLayout'] ) && 'carousel' === $attributes['blockLayout'] ) {
				$feed_list_items .= "<article class='{$feed_item_classes}'><div class='feed-item-content'><a href='{$post_link}' target='{$post_link_target}'><header>{$date}{$title}</header>{$post_content}</a></div></article>";

			} else {
				$feed_list_items .= "<article class='{$feed_item_classes}'><div class='feed-item-content'><header>{$date}{$title}</header>{$post_content}</div></article>";
			}
		}

	} elseif ( $attributes['feedUrl'] && 'json' === $attributes['feedType'] ) {

		// Pull JSON data
		$get_data = wpcom_vip_file_get_contents( esc_url_raw( urldecode( $attributes['feedUrl'] ) ), 3 );
		if ( false === $get_data ) {
			return false;
		}
		$data_array = json_decode( $get_data, true );

		// If there are any errors, send a notification
		$error_check = count( $data_array );
		if ( 0 === $error_check ) {
			return '<div class="components-placeholder"><div class="notice notice-error"><strong>' . __( 'JSON Error: ', 'nlsn-blocks' ) . '</strong> ' . __( 'No Connection', 'nlsn-blocks' ) . '</div></div>';
		}

		if ( 1 === $error_check ) {
			return '<div class="components-placeholder"><div class="notice notice-error">' . __( 'Empty JSON. Try again later.', 'nlsn-blocks' ) . '</div></div>';
		}

		// Loop through each feed item
		$x = 0;
		$totalItems = (int) $attributes['postsToShow'];

		// check for custom feed items
		$custom_feed_data = $attributes['customFeedData'];

		do {
			// Check for Custom Open Graph meta fields
			$custom_open_graph = '';
			$meta_title        = '';
			$meta_description  = '';
			if ( isset( $data_array[$x]['custom_open_graph'] )) {
				$custom_open_graph = $data_array[$x]['custom_open_graph'];
			}
			if ( isset( $data_array[$x]['meta_title'] )) {
				$meta_title = $data_array[$x]['meta_title'];
			}
			if ( isset( $data_array[$x]['meta_description'] )) {
				$meta_description = $data_array[$x]['meta_description'];
			}

			// Get the post title; if one is not found, assign custom title
			$title = '';
			if ( isset( $data_array[$x]['title']['rendered'] ) ) {
				$title = $data_array[$x]['title']['rendered'];
			}

			/*
			 * Check if custom_open_graph is enabled and if a meta_title has been provided
			 */
			if ( $custom_open_graph && $meta_title ) {
				$title = $meta_title;
			}

			/*
			 * If custom feed data is enabled, use the provided field name to get the title
			 */
			if ( $custom_feed_data ) {
				$custom_header_title = $attributes['customHeaderTitle'];
				if ( $custom_header_title ) {
					$title = $data_array[$x][$custom_header_title];
				}
			}
			if ( empty( $title ) ) {
				$title = __( '(No Title)', 'nlsn-blocks' );
			}

			/*
			 * If custom feed data is enabled, use the provided field name to get the subtitle
			 */
			$subtitle = '';
			if ( $custom_feed_data ) {
				$custom_header_subtitle = $attributes['customHeaderSubtitle'];
				if ( $custom_header_subtitle ) {
					$subtitle = $data_array[$x][$custom_header_subtitle];
					$subtitle = "<p>{$subtitle}</p>";
				}
			}

			// Get the post link
			$post_link = '';
			$get_post_link = '';
			if ( isset( $data_array[$x]['link'] ) ) {
				$get_post_link = $data_array[$x]['link'];
			}
			if ( $get_post_link ) {
				$post_link = $get_post_link;
			}
			/*
			 * If custom feed data is enabled, use the provided field name to get the feed item link
			 */
			if ( $custom_feed_data ) {
				$custom_feed_link = $attributes['customFeedLink'];
				if ( $custom_feed_link ) {
					$post_link = $data_array[$x][$custom_feed_link];
				}
			}
			$post_link = esc_url( $post_link );

			/*
			 * If enabled, customize and display the post link with the custom Link-Text provided.
			 * If no custom Link-Text is provided, assign a default 'Read More'.
			 *
			 * If this is disabled however, display the post title hyperlinked.
			 */
			$custom_post_link = '';
			if ( $attributes['customPostLink'] ) {

				/*
				 * If layout is not 'carousel' create title hyperlinked
				 */
				if ( $post_link && isset( $attributes['blockLayout'] ) && 'carousel' !== $attributes['blockLayout'] ) {
					$title = "<a href='{$post_link}' target='{$post_link_target}' class=''>{$title}</a>";
				}

				// Create title and custom post link
				$title = "<h3 class='{$feed_item_title_classes}'>{$title}</h3>";
				$custom_post_link = "<div class='read-more'><a href='{$post_link}' target='{$post_link_target}' class='more-link'>{$post_link_text}</a></div>";

				/*
				 * If layout is 'carousel' create elements not hyperlinked
				 */
				if ( isset( $attributes['blockLayout'] ) && 'carousel' === $attributes['blockLayout'] ) {
					$custom_post_link = "<div class='read-more'>{$post_link_text}</div>";
				}

			} else {
				/*
				 * If layout is 'carousel' create elements not hyperlinked
				 */
				if ( isset( $attributes['blockLayout'] ) && 'carousel' === $attributes['blockLayout'] ) {
					$title = "<h3 class='{$feed_item_title_classes}'>{$title}</h3>";

				} else {
					// Else, create title hyperlinked
					if ( $post_link ) {
						$title = "<a href='{$post_link}' target='{$post_link_target}' class=''>{$title}</a>";
					}
					$title = "<h3 class='{$feed_item_title_classes}'>{$title}</h3>";
				}
			}

			/*
			 * If custom feed data is enabled, append custom header items to the date object below
			 */
			$custom_header_items = '';
			if ( $custom_feed_data ) {
				$header_items = $attributes['customHeaderItems'];
				if ( $header_items ) {

					// create array of comma-separated items
					$header_items_list = explode( ',', $header_items );

					// create new <span> for every feed item
					foreach ( $header_items_list as $key => $header_item ) {
						$single_item = $data_array[$x][$header_item];
						$separator = ( $key !== ( count( $header_items_list ) - 1 ) ) ? ' | ' : '';
						$custom_header_items .= "<span class=''>{$single_item}{$separator}</span>";
					}
				}
			}

			// Get and create the date object
			$date = '';
			if ( $attributes['displayPostDate'] ) {
				$date = $data_array[$x]['date'];

				if ( $date ) {
					$date = sprintf(
						'<div class="entry-meta h5"><time datetime="%1$s" class="nlsn-feed__item-publish-date knockout h5">%2$s</time>%3$s</div>',
						wp_date( 'c', $date ),
						wp_date( $attributes['dateFormat'], $date ),
						' | ' . $custom_header_items // if enabled, append custom feed items to the .entry-meta
					);
				}
			} else {
				if ( $custom_header_items ) {
					$date = "<div class='entry-meta h5'>{$custom_header_items}</div>";
				}
			}

			// Get and create the excerpt object
			$excerpt = '';
			if ( $attributes['displayPostContent'] ) {
				$excerpt = '';
				if ( isset( $data_array[$x]['content']['rendered'] ) ) {
					$excerpt = $data_array[$x]['content']['rendered'];
				}

				/*
				 * Check if custom_open_graph is enabled and if a meta_description has been provided
				 */
				if ( $custom_open_graph && $meta_description ) {
					$excerpt = $meta_description;
				}

				/*
				 * If custom feed data is enabled, use the provided field name to get the excerpt
				 */
				if ( $custom_feed_data ) {
					$custom_excerpt = $attributes['customExcerpt'];
					if ( $custom_excerpt ) {
						$excerpt = $data_array[$x][$custom_excerpt];
					}
				}

				$excerpt = nlsn_custom_excerpt_length( $excerpt );
				$excerpt = esc_html( $excerpt );
			}
			$post_content = "<div class='entry-summary'>{$excerpt}{$custom_post_link}</div>";

			// Create Feed single list-item
			// If layout is 'carousel' create hyperlinked carousel item
			if ( isset( $attributes['blockLayout'] ) && 'carousel' === $attributes['blockLayout'] ) {
				$feed_list_items .= "<article class='{$feed_item_classes}'><div class='feed-item-content'><a href='{$post_link}' target='{$post_link_target}'><header>{$date}{$title}{$subtitle}</header>{$post_content}</a></div></article>";

			} else {
				$feed_list_items .= "<article class='{$feed_item_classes}'><div class='feed-item-content'><header>{$date}{$title}{$subtitle}</header>{$post_content}</div></article>";
			}

			$x++;
		} while ( $x < $totalItems );
	}

	// Build the block content with the proper layout classes
	$block_content = "<div class='{$block_classes}'><div class='module alignfull'><div class='container'><div class='row justify-content-center'><div class='{$columns_width}'><div class='{$layout_classes}' data-columns='{$data_columns}'>{$feed_list_items}</div>{$feed_view_all}</div></div></div></div></div>";

	return $block_content;
}

/**
 * Registers the `posts` block on server.
 */
function nlsn_blocks_register_feed_smart_list_block() {
	// Return early if this function does not exist.
	if ( ! function_exists( 'register_block_type' ) ) {
		return;
	}

	register_block_type(
		'nlsn-blocks/nlsn-feed-smart-list',
		array(
			'render_callback' => 'nlsn_blocks_render_feed_smart_list_block',
			'attributes'      => [
				'feedUrl' => [
					'type'    => 'string',
					'default' => '',
				],
				'align' => [
					'type' => 'string',
				],
				'className' => [
					'type' => 'string',
				],
				'blockLayout' => [
					'type'    => 'string',
					'default' => 'list',
				],
				'postsToShow' => [
					'type' => 'number',
					'default' => 2,
				],
				'columns' => [
					'type' => 'number',
					'default' => 2,
				],
				'displayPostDate' => [
					'type' => 'boolean',
					'default' => false,
				],
				'dateFormat' => [
					'type' => 'string',
					'default' => 'm-d-Y',
				],
				'displayPostContent' => [
					'type' => 'boolean',
					'default' => false,
				],
				'postLinkTarget' => [
					'type' => 'boolean',
					'default' => false,
				],
				'customPostLink' => [
					'type' => 'boolean',
					'default' => false,
				],
				'postLinkText' => [
					'type' => 'string',
					'default' => '',
				],
				'displayViewAllLink' => [
					'type' => 'boolean',
					'default' => false,
				],
				'viewAllLink' => [
					'type' => 'string',
					'default' => '',
				],
				'viewAllText' => [
					'type' => 'string',
					'default' => '',
				],
				'feedType' => [
					'type'    => 'string',
					'default' => 'rss',
				],
				'customFeedData' => [
					'type' => 'boolean',
					'default' => false,
				],
				'customHeaderItems' => [
					'type' => 'string',
					'default' => '',
				],
				'customHeaderTitle' => [
					'type' => 'string',
					'default' => '',
				],
				'customHeaderSubtitle' => [
					'type' => 'string',
					'default' => '',
				],
				'customExcerpt' => [
					'type' => 'string',
					'default' => '',
				],
				'customFeedLink' => [
					'type' => 'string',
					'default' => '',
				],
			],
		)
	);
}
add_action( 'init', 'nlsn_blocks_register_feed_smart_list_block' );
