/**
 * BLOCK: Feed Smart List
 */

// Block dependencies
import icon from './icon';
import edit from './edit';

// Components
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks

// Register: Feed Smart List
registerBlockType( 'nlsn-blocks/nlsn-feed-smart-list', {
	title: __( 'Feed Smart List - NLSN', 'nlsn-blocks' ),
	description: __( 'Display entries/posts from an RSS or JSON feed as a list, grid, or carousel view.', 'nlsn-blocks' ),
	icon: icon,
	category: 'nielsen-blocks',
	keywords: [
		__( 'rss', 'nlsn-blocks' ),
		__( 'json', 'nlsn-blocks' ),
		__( 'post', 'nlsn-blocks' ),
		__( 'carousel', 'nlsn-blocks' ),
		__( 'grid', 'nlsn-blocks' ),
		__( 'nielsen', 'nlsn-blocks' ),
	],

	edit,

	save: props => {
		// Rendering in PHP
		return null;
	},

	/**
	 * Provide a “deprecated” version of the block.
	 * This allows users opening these blocks in Gutenberg to edit them using the updated block.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/deprecated-blocks/
	 */
	deprecated: [],
} );
