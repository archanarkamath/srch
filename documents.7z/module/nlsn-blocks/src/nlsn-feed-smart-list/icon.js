const icon = <svg width='20' height='20' xmlns='http://www.w3.org/2000/svg'>
  <rect x='-1' y='-1' width='22' height='22' id='canvas_background' fill='#fff'
  />
  <g id='canvasGrid' display='none'>
    <rect id='svg_1' width='100%' height='100%' strokeWidth='0' fill='url(#gridpattern)'
    />
  </g>
  <g>
		<rect fill="#fff" stroke="#000" strokeWidth="0.5" x="0.5" y="0.5" width="19" height="19" id="svg_1"/>
	  <rect fill="#000" stroke="#fff" strokeWidth="0.5" x="2" y="5.13296" width="16" height="2.81354" id="svg_9"/>
	  <rect fill="#000" stroke="#fff" strokeWidth="0.5" x="2" y="9.54942" width="16" height="2.81354" id="svg_10"/>
	  <rect fill="#000" stroke="#fff" strokeWidth="0.5" x="2" y="13.96589" width="16" height="2.81354" id="svg_11"/>
	  <line fill="none" stroke="#000" strokeOpacity="null" fillOpacity="null" x1="1.36534" y1="2.9654" x2="6.98237" y2="2.9654" id="svg_16" strokeLinejoin="null" strokeLinecap="null"/>
  </g>
</svg>

export default icon;
