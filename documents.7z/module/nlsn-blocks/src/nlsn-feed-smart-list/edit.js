/**
 * BLOCK: Feed Smart List
 */

// Block dependencies
import Inspector from './inspector';
import AdvancedInspector from './advanced-inspector';
import icon from './icon';

import { Icon, edit, grid, postList, stack } from '@wordpress/icons';

const {
	Fragment,
	Component,
} = wp.element;

const {
	Button,
	Disabled,
	Placeholder,
	TextControl,
	Toolbar,
	// ServerSideRender,
} = wp.components;

const { BlockIcon } = wp.blockEditor;

// Components
const { __ } = wp.i18n; // Import __() from wp.i18n
const { serverSideRender: ServerSideRender } = wp;

// Register editor components
const {
	AlignmentToolbar,
	RichText,
	BlockControls,
	InspectorControls,
	InspectorAdvancedControls,
} = wp.blockEditor;

class FeedSmartListEdit extends Component {
	constructor() {
		super( ...arguments );

		this.state = {
			editing: ! this.props.attributes.feedUrl
		};

		this.onSubmitURL = this.onSubmitURL.bind( this );
	}

	onSubmitURL( event ) {
		event.preventDefault();

		const { feedUrl } = this.props.attributes;
		if ( feedUrl ) {
			this.setState( { editing: false } );
		}
	}

	render() {

		const {
			attributes,
			className,
			setAttributes,
		} = this.props;

		const {
			feedUrl,
			align,
			blockLayout,
		} = attributes;

		const toolbarControls = [
			{
				icon: edit,
				title: __( 'Edit Feed URL', 'nlsn-blocks' ),
				onClick: () => this.setState( { editing: true } ),
			},
			{
				icon: postList,
				title: __( 'List view' ),
				onClick: () => setAttributes( { blockLayout: 'list' } ),
				isActive: blockLayout === 'list',
			},
			{
				icon: grid,
				title: __( 'Grid view' ),
				onClick: () => setAttributes( { blockLayout: 'grid' } ),
				isActive: blockLayout === 'grid',
			},
			{
				icon: stack,
				title: __( 'Carousel view' ),
				onClick: () => setAttributes( { blockLayout: 'carousel' } ),
				isActive: blockLayout === 'carousel',
			},
		];

		if ( this.state.editing ) {
			return(
				<Fragment>
					<Placeholder
						icon={ <Icon icon={ icon } /> }
						label={ __( 'RSS Feed', 'nlsn-blocks' ) }
						instructions={ __( 'RSS URLs are generally located at the /feed/ directory of a site.', 'nlsn-blocks' ) }
					>
						<form onSubmit={ this.onSubmitURL }>
							<TextControl
								placeholder={ __( 'https://example.com/feed…', 'nlsn-blocks' ) }
								value={ unescape( feedUrl ) }
								onChange={ ( feedUrl ) => setAttributes( { feedUrl: escape( feedUrl ) } ) }
								className={ 'components-placeholder__input' }
							/>
							<Button type="submit" disabled={ ! feedUrl }>
								{ __( 'Use URL', 'nlsn-blocks' ) }
							</Button>
						</form>
					</Placeholder>
				</Fragment>
			);
		}


		return (
			<div>
				<Fragment>
					<BlockControls>
						<Toolbar
							controls={ toolbarControls }
						/>
						<AlignmentToolbar
							value={ align }
							onChange={ value => setAttributes( { align: value } ) }
						/>
					</BlockControls>
					<InspectorControls>
						<Inspector
							{ ...this.props }
						/>
					</InspectorControls>
					<InspectorAdvancedControls>
						<AdvancedInspector
							{ ...this.props }
						/>
					</InspectorAdvancedControls>
					{ ( blockLayout === 'list' || blockLayout === 'grid')  &&
						<Disabled>
							<ServerSideRender
								block="nlsn-blocks/nlsn-feed-smart-list"
								attributes={ this.props.attributes }
							/>
						</Disabled>
					}
					{ blockLayout === 'carousel'  && // don't disable component to allow overflow-x scroll behaviour
						<Fragment>
							<ServerSideRender
								block="nlsn-blocks/nlsn-feed-smart-list"
								attributes={ this.props.attributes }
							/>
							<div className='carousel-arrows d-flex justify-content-center bg-light-gray'>
								<i className="fa fa-long-arrow-left"/>
								<i className="fa fa-long-arrow-right"/>
							</div>
						</Fragment>
					}
				</Fragment>
			</div>
		);
	}
}

export default FeedSmartListEdit;
