/**
 * Internal block libraries
 */
const { __ } = wp.i18n;
const { Component, Fragment } = wp.element;

const {
	RadioControl,
	ToggleControl,
	TextControl,
} = wp.components;

/**
 * Create an Advanced Inspector Controls wrapper Component
 */
export default class AdvancedInspector extends Component {

  constructor() {
    super( ...arguments );
  }

  render() {
    const {
    	attributes: {
				feedType,
				customFeedData,
				customHeaderItems,
				customHeaderTitle,
				customHeaderSubtitle,
				customFeedLink,
				customExcerpt,
			},
			setAttributes
    } = this.props;

    return (
    	<Fragment>
				<RadioControl
					label={ __( 'Feed Type', 'nlsn-blocks' ) }
					help={
						feedType === 'rss' ?
							__( 'By default RSS is the feed type. Only change this if needed', 'nlsn-blocks' ) :
							__( 'JSON is being used as the feed type. This might not work for all scenarios', 'nlsn-blocks' )
					}
					selected={ feedType }
					options={ [
						{
							label: __( 'RSS', 'nlsn-blocks' ),
							value: 'rss',
						},
						{
							label: __( 'JSON', 'nlsn-blocks' ),
							value: 'json',
						},
					] }
					onChange={ feedType  => setAttributes( { feedType } ) }
				/>

				{ feedType && 'json' === feedType &&
					<Fragment>
						<ToggleControl
							label={ __( 'Customize Feed Data', 'nlsn-blocks' ) }
							checked={ customFeedData }
							help={
								customFeedData ?
									__( 'Only for use of custom json feed items.', 'nlsn-blocks' ) :
									__( 'Toggle to customize the feed data fields.', 'nlsn-blocks' )
							}
							onChange={ () => setAttributes( { customFeedData: ! customFeedData } ) }
						/>

						{ customFeedData &&
							<Fragment>
								<TextControl
									label={ __( 'Item Header', 'nlsn-blocks' ) }
									help={ __( 'Provide comma-separated field names for the feed item to be pulled into the header.', 'nlsn-blocks' ) }
									placeholder={ __( 'date,author', 'nlsn-blocks' ) }
									value={ customHeaderItems }
									onChange={ customHeaderItems  => setAttributes( { customHeaderItems } ) }
								/>
								<TextControl
									label={ __( 'Item Title', 'nlsn-blocks' ) }
									help={ __( 'Provide the single field name for the feed item title.', 'nlsn-blocks' ) }
									placeholder={ __( 'title, post_title, etc', 'nlsn-blocks' ) }
									value={ customHeaderTitle }
									onChange={ customHeaderTitle  => setAttributes( { customHeaderTitle } ) }
								/>
								<TextControl
									label={ __( 'Item Subtitle', 'nlsn-blocks' ) }
									help={ __( 'Provide the single field name for the feed item subtitle.', 'nlsn-blocks' ) }
									placeholder={ __( 'subtitle, post_subtitle, etc', 'nlsn-blocks' ) }
									value={ customHeaderSubtitle }
									onChange={ customHeaderSubtitle  => setAttributes( { customHeaderSubtitle } ) }
								/>
								<TextControl
									label={ __( 'Item URL', 'nlsn-blocks' ) }
									help={ __( 'Provide the single field name for the feed item URL.', 'nlsn-blocks' ) }
									placeholder={ __( 'url, link, etc', 'nlsn-blocks' ) }
									value={ customFeedLink }
									onChange={ customFeedLink  => setAttributes( { customFeedLink } ) }
								/>
								<TextControl
									label={ __( 'Item Excerpt', 'nlsn-blocks' ) }
									help={ __( 'Provide the single field name for the feed item excerpt/description.', 'nlsn-blocks' ) }
									placeholder={ __( 'description, excerpt, content, etc', 'nlsn-blocks' ) }
									value={ customExcerpt }
									onChange={ customExcerpt  => setAttributes( { customExcerpt } ) }
								/>
							</Fragment>
						}
					</Fragment>
				}
    	</Fragment>
		);
  }
}
