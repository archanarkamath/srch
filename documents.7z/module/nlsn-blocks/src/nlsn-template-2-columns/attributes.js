const attributes = {
	columns: {
		type: 'number',
		default: 2,
	},
	columnLayout: {
		type: 'string',
		default: '66-33',
	}
};

export default attributes;
