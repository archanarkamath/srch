/**
 * Internal block libraries
 */
const { __ } = wp.i18n;
const { Component } = wp.element;

// Block dependencies
import icons from './icons';

const {
  PanelBody,
	PanelRow,
	BaseControl,
	ButtonGroup,
	Button,
  RangeControl,
	TextControl
} = wp.components;

/**
 * Create an Inspector Controls wrapper Component
 */
export default class Inspector extends Component {

  constructor() {
    super( ...arguments );
  }

  render() {
    const { attributes: { columns, columnLayout }, setAttributes } = this.props;

		// Column Layout Icons
		const layouts = {};
		layouts.columnLayout = [
			{ columns: 2, label: 'Right Sidebar', value: '66-33', icon: icons.sixtysix_thirtythree },
			{ columns: 2, label: 'Left Sidebar', value: '33-66', icon: icons.thirtythree_sixtysix },
		];

    return (
			<PanelBody
				title={ __( 'Column Layouts', 'nlsn-blocks' ) }
				className='nlsn-column-layouts'
				initialOpen={ true }
			>
				<PanelRow>
					<BaseControl
						id={ 'column-layout' }
						label={ columnLayout }
					>
						<ButtonGroup
							id="column-layout"
							aria-label={ columnLayout }
							className="button-group"
							style={ { display: 'block' } }
						>
							{ layouts.columnLayout.map( ( type ) => {
								return (
									<Button
										key={ type.label }
										icon={ type.icon }
										label={ type.label }
										isPrimary={ columnLayout === type.value }
										aria-pressed={ columnLayout === type.value }
										onClick={ () => { setAttributes({ columns: type.columns, columnLayout: type.value } ) } }
									/>
								);
							} ) }
						</ButtonGroup>
					</BaseControl>
				</PanelRow>

			</PanelBody>
    );
  }
}
