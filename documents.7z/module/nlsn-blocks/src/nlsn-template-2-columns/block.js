/**
 * BLOCK: Template 2 Columns
 */

// Block dependencies
import classnames from 'classnames';
import { times } from 'lodash-es';
import memoize from 'memize';
import Inspector from './inspector';
import attributes from './attributes';

//  Import CSS.
// import './editor.scss';

/**
 * WordPress dependencies
 */
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks

// Register editor components
const {
	InspectorControls,
	InnerBlocks,
} = wp.blockEditor;

const moduleClass = classnames(
	// main classes to be applied/used for all blocks
	'module',
	'alignfull',
);

const defineBlockClasses = ( props ) => {
	// setup layout classes
	const blockClasses = classnames(
		'column-layout',
		`has-${ props.attributes.columnLayout }-layout`,
	);
	return {
		blockClasses,
	};
};

/**
 * Allowed blocks constant is passed to InnerBlocks precisely as specified here.
 * The contents of the array should never change.
 * The array should contain the name of each block that is allowed.
 * In columns block, the only block we allow is 'core/column'.
 *
 * @constant
 * @type {string[]}
*/
const ALLOWED_BLOCKS = [ 'core/column' ];

/**
 * Returns the layouts configuration for a given number of columns.
 *
 * @param {number} columns Number of columns.
 *
 * @return {Object[]} Columns layout configuration.
 */
const getColumnTemplate = memoize( ( columns ) => {
	return times( columns, () => [ 'core/column' ] );
} );

registerBlockType( 'nlsn-blocks/nlsn-template-2-columns', {
	title: __( 'Template - 2 Columns - NLSN', 'nlsn-blocks' ),
	description: __( 'Create template columns layout', 'nlsn-blocks' ),
	icon: 'columns',
	category: 'nielsen-blocks',
	keywords: [
		__( 'columns', 'nlsn-blocks' ),
		__( 'template', 'nlsn-blocks' ),
		__( 'nielsen', 'nlsn-blocks' ),
	],
	attributes: {
		...attributes,
	},

	edit: props => {
		const {
			attributes: {
				columns,
			},
			isSelected,
			className,
			setAttributes,
		} = props;

		// setup block container classes
		const containerClasses = classnames(
			moduleClass,
		);

		const blockClassesObject = defineBlockClasses( props );

		return (
			<div key="editor-display" className={ className }>

				{ isSelected &&
					<InspectorControls>
						<Inspector
							{ ...props }
						/>
					</InspectorControls>
				}

				<div className={ containerClasses }>

					<div className="container">
						<div className="row justify-content-center">
							<div className={ 'col-md-12' }>

								<div className={ blockClassesObject.blockClasses }>
									<InnerBlocks
										template={ getColumnTemplate( columns ) }
										templateLock="all"
										allowedBlocks={ ALLOWED_BLOCKS }
									/>
								</div>

							</div>
						</div>
					</div>
				</div>
			</div>
		)
	},

	save: props => {
		const {
			attributes: {
				columns,
			},
			className,
		} = props;


		// setup block container classes
		const containerClasses = classnames(
			moduleClass,
		);

		const blockClassesObject = defineBlockClasses( props );

		// Return the markup displayed on the front-end.
		return (
			<div className={ className }>
				<div
					className={ containerClasses }
				>

					<div className="container">
						<div className="row justify-content-center">
							<div className={ 'col-md-12' }>

								<div className={ classnames( blockClassesObject.blockClasses, 'row' ) }>
									<InnerBlocks.Content />
								</div>

							</div>
						</div>
					</div>

				</div>
			</div>
		);
	},
} );
