/**
 * BLOCK: Layouts
 */

// Block dependencies
import classnames from 'classnames';
import attributes from './attributes';
import icons from './icons';

import { columns } from '@wordpress/icons';

// Import all of our Container Options requirements.
import ContainerOptions, {
	ContainerOptionsAttributes,
	HideSectionEdit,
	HideSectionSave,
	BlockIdEdit,
	BlockIdSave,
	BackgroundOptionsClasses,
	BlockPaddingClasses,
	BlockWidthClasses,
} from '../components/container-options';

//  Import CSS.
// import './editor.scss';
import defineClassNames from "../utilities/defineClasses";

/**
 * WordPress dependencies
 */
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks

// Register editor components
const {
	InspectorControls,
	InnerBlocks,
} = wp.blockEditor;

const {
	BaseControl,
	Button,
} = wp.components;

const { Fragment } = wp.element;

/**
 * Allowed blocks constant is passed to InnerBlocks precisely as specified here.
 * The contents of the array should never change.
 * The array should contain the name of each block that is allowed.
 * In columns block, the only block we allow is 'core/column'.
 *
 * @constant
 * @type {string[]}
*/
const ALLOWED_BLOCKS = [ 'core/column' ];

const template2Columns = [
  [
		'nlsn-blocks/nlsn-template-2-columns', { columns: 2, columnLayout: '66-33' },
		[
			[
				'core/column', {},
			],
			[
				'core/column', {},
			]

		]
	],
];

registerBlockType( 'nlsn-blocks/nlsn-layouts', {
	title: __( 'Layouts - NLSN', 'nlsn-blocks' ),
	description: __( 'Block Template layouts', 'nlsn-blocks' ),
	icon: columns,
	category: 'nielsen-templates',
	keywords: [
		__( 'columns', 'nlsn-blocks' ),
		__( 'template', 'nlsn-blocks' ),
		__( 'nielsen', 'nlsn-blocks' ),
	],
	supports: {
		multiple: false,
	},
	attributes: {
		...ContainerOptionsAttributes,
		...attributes,
	},

	edit: props => {
		const {
			attributes: {
				columns,
				columnLayout,
				layoutSelect,
				containerSettings,
			},
			isSelected,
			className,
			setAttributes,
		} = props;

		const classes = defineClassNames( props, 'layouts' );

		// Column Layout Icons
		const layouts = {};
		layouts.columnLayout = [
			{ columns: 2, label: 'Full Width', value: 'Full-Width', icon: icons.full_width },
			{ columns: 2, label: 'Sidebar', value: '2-Columns', icon: icons.sixtysix_thirtythree },
		];

		return (
			<div className={ 'layout-selector' } style= { { backgroundColor: '#e4e8eb' } }>

				{ isSelected &&
					<InspectorControls>
						<ContainerOptions
							{ ...props }
						/>
					</InspectorControls>
				}

				<h3 className="text-center">Layouts</h3>

				<div className="text-center">
					<BaseControl
						id={ 'column-layout' }
						label={ columnLayout }
					>
						{ ( layoutSelect === false ) && (
							<Fragment>
								<div>
									{ layouts.columnLayout.map( ( type ) => {
										return (
											<Button
												key={ type.label }
												icon={ type.icon }
												label={ type.label }
												key={ 'icon-'+type.value }
												className={ 'layout-button d-inline-block' }
												isPrimary={ columnLayout === type.value }
												aria-pressed={ columnLayout === type.value }
												onClick={ () => { setAttributes({ columns: type.columns, columnLayout: type.value } ) } }
											/>
										);
									})}
								</div>

								<Button
									className='select-layout btn btn-green'
									style={ { padding: '3px', margin: '8px 0px',  } }
									onClick={ () => setAttributes( { layoutSelect: true } ) }
								>
									<label
										style={ { margin: '0px', padding: '0px 5px' } }
									>
										{ __( 'Use this Layout', 'nlsn-blocks' ) }
									</label>
								</Button>
							</Fragment>
						) }

					</BaseControl>
				</div>

				{ 'Full-Width' === columnLayout ? (
					null
				) : (

					<div key="editor-display" className={ classnames( className, 'nlsn-layout' ) }>

						{ containerSettings &&
							<div className="container-settings">
								<BlockIdEdit
									{ ...props }
								/>
								<HideSectionEdit
									{ ...props }
								/>
							</div>
						}

						<div className={ classes.container } id={ classes.id }>
							<div className="container">
								<div className="row justify-content-center">
									<div className={ classes.width }>

										<InnerBlocks
											template={ template2Columns }
											templateLock="all"
											allowedBlocks={ ALLOWED_BLOCKS }
										/>

									</div>
								</div>
							</div>
						</div>
					</div>
				) }
			</div>
		)
	},

	save: props => {
		const {
			attributes: {
				columnLayout,
			},
			className,
		} = props;

		const classes = defineClassNames( props, 'layouts', 'save' );

		// Return the markup displayed on the front-end.
		return (
			'Full-Width' === columnLayout ? (
				null
			) : (

				<div className={ className }>
					<div
						id={ classes.id }
						className={ classes.container }
					>

						<div className="container">
							<div className="row justify-content-center">
								<div className={ classes.width }>

									<InnerBlocks.Content />

								</div>
							</div>
						</div>

					</div>
				</div>
			)
		);
	},

	deprecated: [
		{

		},
	],
} );
