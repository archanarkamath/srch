const attributes = {
	columns: {
		type: 'number',
		default: 2,
	},
	columnLayout: {
		type: 'string',
		default: 'Full-Width',
	},
	layoutSelect: {
		type: 'boolean',
		default: false,
	}
};

export default attributes;
