/**
 * BLOCK: Banner
 */

// Block dependencies
import classnames from 'classnames';
import attributes from './attributes';

// Import all of our Container Options requirements.
import ContainerOptions, {
	ContainerOptionsAttributes,
	HideSectionEdit,
	BlockIdEdit,
} from '../components/container-options';

//  Import CSS.
// import './editor.scss';
import defineClassNames from '../utilities/defineClasses';

/**
 * WordPress dependencies
 */
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks

// Editor components
const {
	InspectorControls,
	InnerBlocks,
	PanelColorSettings,
} = wp.blockEditor;

// WordPress components
const { Fragment } = wp.element;

/**
 * Allowed blocks constant is passed to InnerBlocks precisely as specified here.
 * The contents of the array should never change.
 * The array should contain the name of each block that is allowed.
 * In columns block, the only block we allow is 'core/column'.
 *
 * @constant
 * @type {string[]}
*/
const ALLOWED_BLOCKS = [ 'core/column' ];

const BANNER_TEMPLATE = [ [ 'nlsn-blocks/nlsn-columns', { columns: 2, columnLayout: '25-75', hideInspector: true }, [
	[ 'core/column', {}, [
		[ 'nlsn-blocks/nlsn-heading' ],
	] ],
	[ 'core/column', {}, [
		[ 'core/paragraph' ],
	] ],
] ] ];

registerBlockType( 'nlsn-blocks/nlsn-banner', {
	title: __( 'Banner - NLSN', 'nlsn-blocks' ),
	description: __( 'Solutions Detail Banner', 'nlsn-blocks' ),
	icon: 'slides',
	category: 'nielsen-templates',
	keywords: [
		__( 'banner', 'nlsn-blocks' ),
		__( 'details', 'nlsn-blocks' ),
		__( 'nielsen', 'nlsn-blocks' ),
	],
	attributes: {
		...ContainerOptionsAttributes,
		...attributes,
	},

	edit: ( props ) => {
		const {
			attributes: {
				containerSettings,
				highlight,
			},
			className,
			setAttributes,
		} = props;

		const classes = defineClassNames( props, 'banner' );

		// METHODS
		const onChangeContent = ( element, updatedValue ) => {
			setAttributes( { [ element ]: updatedValue } );
		};

		return [
			<Fragment key="controls-display">
				<InspectorControls>
					<ContainerOptions { ...props } />
					<PanelColorSettings
						title={ __( 'Color Settings', 'nlsn-blocks' ) }
						colorSettings={ [
							{
								value: highlight.color,
								onChange: ( color ) => onChangeContent( 'highlight', { color } ),
								label: __( 'Highlight Color', 'nlsn-blocks' ),
							},
						] }
					>
					</PanelColorSettings>
				</InspectorControls>
				{ containerSettings &&
					<div className="container-settings">
						<BlockIdEdit
							{ ...props }
						/>
						<HideSectionEdit
							{ ...props }
						/>
					</div>
				}
			</Fragment>,
			<div key="editor-display" className={ className }>
				<div className={ classes.container } id={ classes.id }>
					<div className="container">
						<div className={
							classnames(
								'row',
								'justify-content-center',
								'nlsn-banner',
								classes.highlight,
							)
						}>
							<div className={
								classnames(
									'banner-wrapper',
									classes.width,
								)
							}>
								<InnerBlocks
									template={ BANNER_TEMPLATE }
									templateLock="all"
									allowedBlocks={ ALLOWED_BLOCKS }
								/>
							</div>
						</div>
					</div>
				</div>
			</div>,
		];
	},
	save: ( props ) => {
		const {
			className,
		} = props;

		const classes = defineClassNames( props, 'banner', 'save' );

		return (
			<div className={ className }>
				<div className={ classes.container } id={ classes.id }>
					<div className="container">
						<div className={
							classnames(
								'row',
								'justify-content-center',
								'nlsn-banner',
								classes.highlight,
							)
						}>
							<div className={
								classnames(
									'banner-wrapper',
									classes.width,
								)
							}>
								<InnerBlocks.Content />
							</div>
						</div>
					</div>
				</div>
			</div>
		);
	},
} );
