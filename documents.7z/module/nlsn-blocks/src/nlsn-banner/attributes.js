const attributes = {
	highlight: {
		type: 'object',
		default: {},
	},
};

export default attributes;
