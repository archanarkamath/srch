/**
 * BLOCK: Sticky Navbar
 */

// Block dependencies
import classnames from 'classnames';
import defineClassNames from '../utilities/defineClasses';
import attributes from './attributes';
import icon from './icon';


// Import all of our Container Options requirements.
import ContainerOptions, {
	ContainerOptionsAttributes,
	HideSectionEdit,
	HideSectionSave,
	BlockIdEdit,
	BlockIdSave,
	BlockWidthClasses,
	BackgroundOptionsClasses,
	BlockPaddingClasses,
	NLSNHeading,
} from '../components/container-options';

import { gallery, cancelCircleFilled } from '@wordpress/icons';

// Components
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks

// Register editor components
const {
	InspectorControls,
	MediaUpload,
	RichText,
	BlockControls,
} = wp.blockEditor;

const {
	Button,
	Toolbar,
} = wp.components;

const {
	Fragment,
} = wp.element;

const blockClasses = classnames(
	`nav-header`,
	`site-header`,
);
const navClasses = classnames(
	`navbar-sticky`,
)
const imageClasses = classnames(
	`content-image`,
);
const titleClasses = classnames(
	`stickynav-title`,
);
const menuClasses = classnames(
	`content-body`,
);
const editorClasses = classnames(
	`content-editor`,
	`nav`,
	`navbar-nav`,
)

// Register: Sticky Navbar
registerBlockType( 'nlsn-blocks/nlsn-sticky-nav', {
	title: __( 'Sticky Navbar - NLSN', 'nlsn-blocks' ),
	description: __( 'Add a sticky navbar to the internal page. Hit Enter to generate a new nav item', 'nlsn-blocks' ),
	icon: icon,
	category: 'nielsen-blocks',
	keywords: [
		__( 'navbar', 'nlsn-blocks' ),
		__( 'sticky', 'nlsn-blocks' ),
		__( 'nielsen', 'nlsn-blocks' ),
	],
	attributes: {
		...attributes,
		...ContainerOptionsAttributes,
	},

	/**
	 * Determines what is displayed in the editor.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 */
	edit: props => {
		const {
			attributes: {
				imgID,
				imgURL,
				imgAlt,
				contentEditor,
				containerSettings,
			},
			isSelected,
			className,
			setAttributes,
		} = props;

		const classes = defineClassNames( props, 'sticky-nav' );

	const onSelectImage = img => {
      setAttributes( {
        imgID: img.id,
        imgURL: img.url,
        imgAlt: img.alt,
      } );
    };
    const onRemoveImage = () => {
      setAttributes({
        imgID: null,
        imgURL: null,
        imgAlt: null,
      });
    }

		// Return the markup displayed in the editor.
		return (

			<div key="editor-display" className={ className }>

				{ isSelected &&
					<InspectorControls>
						<ContainerOptions
							{ ...props }
						/>
					</InspectorControls>
				}

				{ containerSettings &&
					<div className="container-settings">
						<BlockIdEdit
							{ ...props }
						/>
						<HideSectionEdit
							{ ...props }
						/>
					</div>
				}

				<div className={ classes.container } id={ classes.id }>
					<div className='container'>
						<div className='row justify-content-center'>
							<div className={ classes.width }>

								<nav className={ classnames( navClasses ) }>
									<header className={ classnames( blockClasses ) }>
										<nav className={ 'nav-primary navbar' }>
											<div className={ 'row justify-content-center align-items-center' }>

												{ ( ! imgID && isSelected ) ? (
													<div className={ classnames( imageClasses ) }>
														<MediaUpload
															onSelect={ onSelectImage }
															value={ imgID }
															render={ ( { open } ) => (
																<Button onClick={ open } icon={ gallery } > Add/Upload Image </Button>
															) }
														/>
													</div>
												) : (
													<div className={ classnames( imageClasses ) }>
							              <img
															className='content-thumbnail'
						                  src={ imgURL }
						                  alt={ imgAlt }
							              />

										{ isSelected ? (
						                  <Button onClick={ onRemoveImage } icon={ cancelCircleFilled } />
						                ) : null }

													</div>
												)}

												<NLSNHeading.edit formattingControls={[ 'bold', 'italic' ]} { ...props } />

												<div className={ classnames( menuClasses ) }>
													<RichText
														tagName='ul'
														multiline='li'
														className={ classnames( editorClasses ) }
														placeholder={ __( 'Add your first nav item', 'nlsn-blocks' ) }
														value={ contentEditor }
														onChange={ contentEditor => { setAttributes( { contentEditor } ) } }
														
													/>
												</div>

											</div>
										</nav>
									</header>
								</nav>

							</div>
						</div>
					</div>
				</div>
			</div>
		)
	},

	/**
	 * Determines what is displayed on the front-end.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 */
	save: props => {
		const {
			attributes: {
				imgURL,
				imgAlt,
				contentEditor,
				headingContent,
				headingLevel,
			},
			className,
		} = props;

		const classes = defineClassNames( props, 'sticky-nav', 'save' );

		const tagName = `h${ headingLevel }`;
	
		// Return the markup displayed on the front-end.
		return (
			<div className={ className }>
				<div
					id={ classes.id }
					className={ classes.container }
				>
					<div className='container'>
						<div className='row justify-content-center'>
							<div className={ classes.width }>

								<nav className={ classnames( navClasses ) }>
									<header className={ classnames( blockClasses ) }>
										<nav className={ 'nav-primary navbar' }>
											<div className={ 'row justify-content-center align-items-center' }>

												{ imgURL ? (
													<div className={ classnames( imageClasses ) }>
														<a className='image-icon scroll-top' href={ imgURL }>
															<img
																className='content-thumbnail'
																src={ imgURL }
																alt={ imgAlt }
															/>
														</a>
													</div>
												) : null }
											<div className ={ classnames( titleClasses ) }>
												<a href="#" className="scroll-top">
													<RichText.Content
														className={ classnames( 'heading-content' ) }
														tagName={ tagName }
														value={ headingContent }
													/>
												</a>
											</div>
												<div className={ classnames( menuClasses ) }>
													{ ( contentEditor && contentEditor.length > 0 ) ? (
														<ul className={ classnames( editorClasses ) }>
															{ contentEditor }
														</ul>
													) : null }
												</div>

											</div>
										</nav>
									</header>
								</nav>

							</div>
						</div>
					</div>
				</div>
			</div>
		);
	},

	/**
	 * Provide a “deprecated” version of the block.
	 * This allows users opening these blocks in Gutenberg to edit them using the updated block.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/deprecated-blocks/
	 */
	deprecated: [
		{
			attributes: {
				...attributes,
				...ContainerOptionsAttributes,
			},
			save: props => {
				const {
					attributes: {
						imgURL,
						imgAlt,
						contentEditor,
					},
					className,
				} = props;
		
				const classes = defineClassNames( props, 'sticky-nav', 'save' );
		
				// Return the markup displayed on the front-end.
				return (
					<div className={ className }>
						<div
							id={ classes.id }
							className={ classes.container }
						>
							<div className='container'>
								<div className='row justify-content-center'>
									<div className={ classes.width }>
		
										<nav className={ classnames( navClasses ) }>
											<header className={ classnames( blockClasses ) }>
												<nav className={ 'nav-primary navbar' }>
													<div className={ 'row justify-content-center align-items-center' }>
		
														{ imgURL ? (
															<div className={ classnames( imageClasses ) }>
																<a className='image-icon scroll-top' href={ imgURL }>
																	<img
																		className='content-thumbnail'
																		src={ imgURL }
																		alt={ imgAlt }
																	/>
																</a>
															</div>
														) : null }
													<div className ={ classnames( titleClasses ) }>
														<a href="#" className="scroll-top"><NLSNHeading.save { ...props } /></a>
													</div>
														<div className={ classnames( menuClasses ) }>
															{ ( contentEditor && contentEditor.length > 0 ) ? (
																<ul className={ classnames( editorClasses ) }>
																	{ contentEditor }
																</ul>
															) : null }
														</div>
		
													</div>
												</nav>
											</header>
										</nav>
		
									</div>
								</div>
							</div>
						</div>
					</div>
				);
			},
		},
	]
} );
