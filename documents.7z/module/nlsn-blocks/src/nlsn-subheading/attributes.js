const attributes = {
	pageSubtitle: {
		type: 'string',
		source: 'meta',
		meta: 'page_subtitle',
	},
};

export default attributes;
