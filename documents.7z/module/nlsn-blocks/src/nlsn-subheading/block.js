/**
 * BLOCK: Subheading
 */

// Block dependencies
import classnames from 'classnames';
import attributes from './attributes';
import icon from './icon';

// Components
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks
const { PlainText } = wp.blockEditor;

// Register: Blockquote
registerBlockType( 'nlsn-blocks/nlsn-subheading', {
	title: __( 'Subheading - NLSN', 'nlsn-blocks' ),
	description: __( 'Add a Subheading below the page title. This block cannot be deleted. If a subtitle isn’t needed, leave the field blank. Only some post types support this block. If you add this block to a post that doesn’t support it, no subtitle will appear on publishing.', 'nlsn-blocks' ),
	icon,
	category: 'nielsen-blocks',
	keywords: [
		__( 'subheading', 'nlsn-blocks' ),
		__( 'subtitle', 'nlsn-blocks' ),
		__( 'nielsen', 'nlsn-blocks' ),
	],
	supports: {
		multiple: false,
		inserter: false,
		reusable: false,
	},
	attributes: {
		...attributes,
	},

	/**
	 * Determines what is displayed in the editor.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 */
	edit: props => {
		const { attributes: { pageSubtitle }, setAttributes } = props;

		// Return the markup displayed in the editor.
		return (
			<PlainText
				className={ classnames(
					'page-subtitle h3'
				) }
				style={ { margin: 0, textTransform: 'initial' } }
				placeholder={ __( 'Optional: Add a subtitle or leave it blank', 'nlsn-blocks' ) }
				value={ pageSubtitle }
				onChange={ pageSubtitle => setAttributes( { pageSubtitle } ) }
			/>
		)
	},

	/**
	 * Determines what is displayed on the front-end.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 */
	save: props => {
		// Rendering in PHP
		return null;
	},
} );
