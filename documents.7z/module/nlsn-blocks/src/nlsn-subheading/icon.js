const icon = <svg width='20' height='20' xmlns='http://www.w3.org/2000/svg'>
        <path d="M12.5 4v5.2h-5V4H5v13h2.5v-5.2h5V17H15V4z" fill="#626262"/>
        </svg>

export default icon;
