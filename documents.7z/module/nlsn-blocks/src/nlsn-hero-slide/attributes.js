const attributes = {
	backgroundImageID: {
		type: 'number',
	},
	backgroundImageURL: {
		type: 'string',
	},
	contentAlignment: {
		type: 'string',
		default: 'left',
	},
	slideTitle: {
		type: 'string',
		source: 'html',
		selector: '.slide-title',
	},
	slideSubtitle: {
		type: 'string',
		source: 'html',
		selector: '.slide-subtitle',
	},
	slideEditor: {
		type: 'string',
		source: 'html',
		selector: '.slide-editor',
	},
	newWindow: {
		type: 'boolean',
		default: false,
	},
	buttonText: {
		type: 'string',
		source: 'html',
		selector: '.more-link',
	},
	buttonUrl: {
		type: 'string',
		source: 'attribute',
		selector: 'a',
		attribute: 'href',
	},
	buttonColor: {
		type: 'string',
	}
};

export default attributes;
