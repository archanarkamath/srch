/**
 * Internal block libraries
 */
const { __ } = wp.i18n;
const { Component, Fragment } = wp.element;

// Register editor components
const {
	MediaUpload,
	PanelColorSettings,
} = wp.blockEditor;

const {
  PanelBody,
	PanelRow,
	ToggleControl,
	BaseControl,
	ButtonGroup,
	Button,
} = wp.components;

import { Icon, link, gallery } from '@wordpress/icons';

/**
 * Create an Inspector Controls wrapper Component
 */
export default class Inspector extends Component {

  constructor() {
    super( ...arguments );
  }

  render() {
    const { attributes: { backgroundImageID, backgroundImageURL, contentAlignment, newWindow, buttonColor }, setAttributes } = this.props;

		const onSelectImage = ( { id, url } ) => {
			setAttributes( {
				backgroundImageID: id,
				backgroundImageURL: url,
			} );
		};
		const onRemoveImage = () => {
			setAttributes( {
				backgroundImageID: null,
				backgroundImageURL: null,
			});
		};

		// Button Alignment Options
		const buttonAlignment = {};
		buttonAlignment.contentAlignment = [
		  { value: 'left',   label: 'Left',   icon: 'editor-alignleft' },
		  { value: 'right',  label: 'Right',  icon: 'editor-alignright' },
		];

    return (
			<Fragment>
				<PanelBody
					title={ __( 'Content Settings', 'nlsn-blocks' ) }
					initialOpen={ true }
				>

					<PanelRow>
						{ ! backgroundImageID ? (
							<MediaUpload
								buttonProps={ {
									className: 'components-button button',
								} }
								onSelect={ onSelectImage }
								value={ backgroundImageID }
								render={ ( { open } ) => (
									<Button className="button" onClick={ open } icon={gallery}>Add/Upload Image</Button>
								) }
							/>
						) : (
							<div className="image-wrapper">
								<p>
									<img
									src={ backgroundImageURL }
								/>
								</p>
								<p>
									<Button onClick={ onRemoveImage }>Remove Image</Button>
								</p>
							</div>
						) }

					</PanelRow>

					<PanelRow>
						<BaseControl
							id={ 'content-alignment' }
							className={ 'alignment-button-group' }
							label={ `Content Align ${contentAlignment}` }
						>
							<ButtonGroup
								id="content-alignment"
								aria-label={ `Content Align ${contentAlignment}` }
								className="alignment-button-group"
								style={ { display: 'block' } }
							>
								{ buttonAlignment.contentAlignment.map( ( type ) => {
									return (
										<Button
											key={ type.label }
											icon={ type.icon }
											label={ __( type.label, 'nlsn-blocks' ) }
											style={ { display: 'd-inline', float: 'left' } }
											isPrimary={ contentAlignment === type.value }
											aria-pressed={ contentAlignment === type.value }
											onClick={ () => { setAttributes({ contentAlignment: type.value } ) } }
										/>
									);
								} ) }
							</ButtonGroup>
						</BaseControl>
					</PanelRow>
				</PanelBody>

				<PanelBody
					title={ __( 'Button Settings', 'nlsn-blocks' ) }
					initialOpen={ true }
				>
					<PanelRow>
						<ToggleControl
							label={ __( 'New Window', 'nlsn-blocks' ) }
							checked={ newWindow }
							help={ __( 'Open button link in new window?', 'nlsn-blocks' ) }
							onChange={ newWindow => setAttributes( { newWindow } ) }
						/>
					</PanelRow>

					<PanelRow>
						<PanelColorSettings
							title={ __( 'Color Settings', 'nlsn-blocks' ) }
							colorSettings={ [
								{
									value: buttonColor,
									onChange: ( buttonColor ) => setAttributes( { buttonColor } ),
									label: __( 'Button Color', 'nlsn-blocks' ),
								},
							] }
						>
						</PanelColorSettings>
					</PanelRow>

				</PanelBody>
			</Fragment>
    );
  }
}
