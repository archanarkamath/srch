/**
 * BLOCK: Hero Slide
 */

// Block dependencies
import classnames from 'classnames';
import Inspector from './inspector';
import attributes from './attributes';
import icon from './icon';

import { Icon, link, keyboardReturn } from '@wordpress/icons';

// Import all of our Global Inspector Options requirements.
import TextOptions, { TextOptionsAttributes, TextOptionsClasses } from '../components/text-options';

// Dependencies
import { colors } from '../components/colors/colorUtils';

// Components
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks

// Register editor components
const {
	InspectorControls,
	RichText,
	URLInput,
	getColorObjectByColorValue,
} = wp.blockEditor;

const {
	Button,
	Tooltip,
} = wp.components;

const blockClasses = classnames(
	`carousel-item`,
	`hero-slide`,
);

const imageClasses = classnames(
	`image-background`,
	`slide-image-background`,
);

const editorClasses = classnames(
	`slide-content`,
);

// Register: Slide Editor with Image
registerBlockType( 'nlsn-blocks/nlsn-hero-slide', {
	title: __( 'Hero Slide - NLSN', 'nlsn-blocks' ),
	description: __( 'Add a background image and text content with a button to the Hero Slider.', 'nlsn-blocks' ),
	icon: icon,
	category: 'nielsen-blocks',
	parent: [ 'nlsn-blocks/nlsn-hero-slider' ],
	keywords: [
		__( 'hero', 'nlsn-blocks' ),
		__( 'slider', 'nlsn-blocks' ),
		__( 'nielsen', 'nlsn-blocks' ),
	],
	attributes: {
		...attributes,
		...TextOptionsAttributes,
	},

	/**
	 * Determines what is displayed in the editor.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 */
	edit: props => {
		const { attributes: { backgroundImageID, backgroundImageURL, contentAlignment, slideTitle, slideSubtitle, slideEditor, buttonText, buttonUrl, buttonColor },
			isSelected, className, setAttributes } = props;

		let contentAlign = '';
		if ( contentAlignment === 'right' ) {
			contentAlign = 'text-right';
		}

		// get color object
		const buttonColorObject = getColorObjectByColorValue( colors, buttonColor );
		let buttonColorName = '';

		( buttonColorObject && buttonColorObject !== undefined ? (
			// get 'slug' value from color object
			buttonColorName = buttonColorObject.slug
		) : null );

		// Return the markup displayed in the editor.
		return (
			<div className={ className }>
				{ isSelected &&
					<InspectorControls>
						<Inspector
							{ ...props }
						/>
						<TextOptions
							{ ...props }
						/>
					</InspectorControls>
				}
				<div
					className={ classnames( blockClasses ) }
					style={ { display: 'block' } }>

					{ backgroundImageID ? (
						<div
							className={ classnames( imageClasses ) }
							style={ {
								backgroundImage: `url(${ backgroundImageURL })`,
								backgroundPosition: 'center',
							} }
						>
						</div>
					) : null }

					<div
						className={ classnames(
							editorClasses,
							contentAlign,
							...TextOptionsClasses( props ),
						) }
					>
						<div className='container'>
							<RichText
								tagName='h1'
								multiline='false'
								className={ classnames(
									'slide-title'
								) }
								placeholder={ __( 'Add your title', 'nlsn-blocks' ) }
								value={ slideTitle }
								onChange={ slideTitle => { setAttributes( { slideTitle } ) } }
							/>

							{ ( ( slideSubtitle && slideSubtitle.length > 0 ) || isSelected ) && (
								<RichText
									tagName='h3'
									multiline='false'
									className={ classnames(
										'slide-subtitle'
									) }
									placeholder={ __( 'Add your subtitle', 'nlsn-blocks' ) }
									value={ slideSubtitle }
									onChange={ slideSubtitle => { setAttributes( { slideSubtitle } ) } }
								/>
							) }

							<RichText
								tagName='div'
								multiline='p'
								className={ classnames(
									'slide-editor'
								) }
								placeholder={ __( 'Add your message', 'nlsn-blocks' ) }
								value={ slideEditor }
								onChange={ slideEditor => { setAttributes( { slideEditor } ) } }
							/>

							{ ( ( buttonText && buttonText.length > 0 ) || isSelected ) && (
								<div
									style={ { display: 'inline-block' } }
								>
									<RichText
										tagName='p'
										multiline='false'
										className={ classnames( 'more-link', 'btn', `btn-${ buttonColorName }` ) }
										placeholder={ __( 'Button Text', 'nlsn-blocks' ) }
										value={ buttonText }
										onChange={ buttonText => setAttributes( { buttonText } ) }
									/>
								</div>
							) }

							{ isSelected && (
								<form
									className='button-url'
									onSubmit={ event => event.preventDefault() }
								>
									<Tooltip
										text='Add Link'
										children='url'
									>
										<Icon icon={ link } />
										<label>{ __( ' Add Link', 'nlsn-blocks' ) }</label>
									</Tooltip>

									<URLInput
										className='url'
										value={ buttonUrl }
										onChange={ buttonUrl => setAttributes( { buttonUrl } ) }
									/>
									<Button
										icon={ keyboardReturn }
										label={ __( 'Apply', 'nlsn-blocks' ) }
										type='submit'
									/>
								</form>
							) }
						</div>
					</div>

				</div>
			</div>
		)
	},

	/**
	 * Determines what is displayed on the front-end.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 */
	save: props => {
		const { attributes: { backgroundImageID, backgroundImageURL, contentAlignment, slideTitle, slideSubtitle, slideEditor, newWindow, buttonText, buttonUrl, buttonColor },
			className } = props;

		let contentAlign = '';
		if ( contentAlignment === 'right' ) {
			contentAlign = 'text-right';
		}

		let linkTarget = '';
		newWindow === true ? linkTarget = '_blank' : linkTarget = null;

		let relAttr = '';
		linkTarget && linkTarget !== undefined ? relAttr = 'noopener noreferrer' : relAttr = null;

		// get color object
		const buttonColorObject = getColorObjectByColorValue( colors, buttonColor );
		let buttonColorName = '';

		( buttonColorObject && buttonColorObject !== undefined ? (
			// get 'slug' value from color object
			buttonColorName = buttonColorObject.slug
		) : null );

		// Return the markup displayed on the front-end.
		return (
			<div
				className={ classnames(
					className,
					blockClasses,
				) }
			>

				{ backgroundImageID ? (
					<div
						className={ classnames( imageClasses ) }
						style={ {
							backgroundImage: `url(${ backgroundImageURL })`,
							backgroundPosition: 'center',
						} }
					>
					</div>
				) : null }

				<div
					className={ classnames(
						editorClasses,
						contentAlign,
						...TextOptionsClasses( props ),
					) }
				>

					<div className={ 'container' }>

						{ ( slideTitle && slideTitle.length > 0 ) ? (
							<RichText.Content
								tagName='h1'
								className={ 'slide-title' }
								value={ slideTitle }
							/>
						) : null }

						{ ( slideSubtitle && slideSubtitle.length > 0 ) ? (
							<RichText.Content
								tagName='h3'
								className={ 'slide-subtitle' }
								value={ slideSubtitle }
							/>
						) : null }

						<RichText.Content
							tagName='div'
							className={ 'slide-editor' }
							value={ slideEditor }
						/>

						{ ( buttonText && buttonText.length > 0 ) ? (
							<RichText.Content
								tagName="a"
								className={ classnames( 'more-link', 'btn', `btn-${ buttonColorName }` ) }
								href={ buttonUrl }
								target={ linkTarget }
								rel={ relAttr }
								value={ buttonText }
							/>
						) : null }
					</div>
				</div>
			</div>
		);
	},

	/**
	 * Provide a “deprecated” version of the block.
	 * This allows users opening these blocks in Gutenberg to edit them using the updated block.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/deprecated-blocks/
	 */
	deprecated: [
		{
			attributes: {
				backgroundImage: {
					type: 'object',
				},
				contentAlignment: {
					type: 'string',
					default: 'left',
				},
				slideTitle: {
					type: 'string',
					source: 'html',
					selector: '.slide-title',
				},
				slideSubtitle: {
					type: 'string',
					source: 'html',
					selector: '.slide-subtitle',
				},
				slideEditor: {
					type: 'string',
					source: 'html',
					selector: '.slide-editor',
				},
				newWindow: {
					type: 'boolean',
					default: false,
				},
				buttonText: {
					type: 'string',
					source: 'html',
					selector: '.more-link',
				},
				buttonUrl: {
					type: 'string',
					source: 'attribute',
					selector: 'a',
					attribute: 'href',
				},
				buttonColor: {
					type: 'string',
				},
				...TextOptionsAttributes,
			},
			save: props => {
				const { attributes: { backgroundImage, contentAlignment, slideTitle, slideSubtitle, slideEditor, newWindow, buttonText, buttonUrl, buttonColor },
					className } = props;

				let contentAlign = '';
				if ( contentAlignment === 'right' ) {
					contentAlign = 'text-right';
				}

				let linkTarget = '';
				newWindow === true ? linkTarget = '_blank' : linkTarget = null;

				let relAttr = '';
				linkTarget && linkTarget !== undefined ? relAttr = 'noopener noreferrer' : relAttr = null;

				// get color object
				const buttonColorObject = getColorObjectByColorValue( colors, buttonColor );
				let buttonColorName = '';

				( buttonColorObject && buttonColorObject !== undefined ? (
					// get 'slug' value from color object
					buttonColorName = buttonColorObject.slug
				) : null );

				// Return the markup displayed on the front-end.
				return (
					<div
						className={ classnames(
							className,
							blockClasses,
						) }
					>

						{ backgroundImage ? (
							<div
								className={ classnames( imageClasses ) }
								style={ {
									backgroundImage: `url(${ backgroundImage.url })`,
									backgroundPosition: 'center',
								} }
							>
							</div>
						) : null }

						<div
							className={ classnames(
								editorClasses,
								contentAlign,
								...TextOptionsClasses( props ),
							) }
						>

							<div className={ 'container' }>

								{ ( slideTitle && slideTitle.length > 0 ) ? (
									<RichText.Content
										tagName='h1'
										className={ 'slide-title' }
										value={ slideTitle }
									/>
								) : null }

								{ ( slideSubtitle && slideSubtitle.length > 0 ) ? (
									<RichText.Content
										tagName='h3'
										className={ 'slide-subtitle' }
										value={ slideSubtitle }
									/>
								) : null }

								<RichText.Content
									tagName='div'
									className={ 'slide-editor' }
									value={ slideEditor }
								/>

								{ ( buttonText && buttonText.length > 0 ) ? (
									<RichText.Content
										tagName="a"
										className={ classnames( 'more-link', 'btn', `btn-${ buttonColorName }` ) }
										href={ buttonUrl }
										target={ linkTarget }
										rel={ relAttr }
										value={ buttonText }
									/>
								) : null }
							</div>
						</div>
					</div>
				);
			},
		},
		{
			attributes: {
				backgroundImage: {
					type: 'object',
				},
				contentAlignment: {
					type: 'string',
					default: 'left',
				},
				slideTitle: {
					type: 'array',
					source: 'children',
					selector: '.slide-title',
				},
				slideSubtitle: {
					type: 'array',
					source: 'children',
					selector: '.slide-subtitle',
				},
				slideEditor: {
					type: 'array',
					source: 'children',
					selector: '.slide-editor',
				},
				newWindow: {
					type: 'boolean',
					default: false,
				},
				buttonText: {
					type: 'array',
					source: 'children',
					selector: '.more-link',
				},
				buttonUrl: {
					type: 'string',
					source: 'attribute',
					selector: 'a',
					attribute: 'href',
				},
				buttonColor: {
					type: 'string',
				},
				...TextOptionsAttributes,
			},
			save: props => {
				const { attributes: { backgroundImage, contentAlignment, slideTitle, slideSubtitle, slideEditor, newWindow, buttonText, buttonUrl, buttonColor },
					className } = props;

				let contentAlign = '';
				if ( contentAlignment === 'right' ) {
					contentAlign = 'text-right';
				}

				let linkTarget = '';
				newWindow === true ? linkTarget = '_blank' : linkTarget = null;

				let relAttr = '';
				linkTarget && linkTarget !== undefined ? relAttr = 'noopener noreferrer' : relAttr = null;

				// get color object
				const buttonColorObject = getColorObjectByColorValue( colors, buttonColor );
				let buttonColorName = '';

				( buttonColorObject && buttonColorObject !== undefined ? (
					// get 'slug' value from color object
					buttonColorName = buttonColorObject.slug
				) : null );

				// Return the markup displayed on the front-end.
				return (
					<div
						className={ classnames(
							className,
							blockClasses,
						) }
					>

						{ backgroundImage ? (
							<div
								className={ classnames( imageClasses ) }
								style={ {
									backgroundImage: `url(${ backgroundImage.url })`,
									backgroundPosition: 'center',
								} }
							>
							</div>
						) : null }

						<div
							className={ classnames(
								editorClasses,
								contentAlign,
								...TextOptionsClasses( props ),
							) }
						>

							<div className={ 'container' }>

								{ ( slideTitle && slideTitle.length > 0 ) ? (
									<RichText.Content
										tagName='h1'
										className={ 'slide-title' }
										value={ slideTitle }
									/>
								) : null }

								<RichText.Content
									tagName='h3'
									className={ 'slide-subtitle' }
									value={ slideSubtitle }
								/>

								{ ( slideEditor && slideEditor.length > 0 ) ? (
									<RichText.Content
										tagName='div'
										className={ 'slide-editor' }
										value={ slideEditor }
									/>
								) : null }

								{ ( buttonText && buttonText.length > 0 ) ? (
									<RichText.Content
										tagName="a"
										className={ classnames( 'more-link', 'btn', `btn-${ buttonColorName }` ) }
										href={ buttonUrl }
										target={ linkTarget }
										rel={ relAttr }
										value={ buttonText }
									/>
								) : null }
							</div>
						</div>
					</div>
				);
			},
		},
		{
			attributes: {
				backgroundImage: {
					type: 'object',
				},
				contentAlignment: {
					type: 'string',
					default: 'left',
				},
				slideTitle: {
					type: 'array',
					source: 'children',
					selector: '.slide-title',
				},
				slideSubtitle: {
					type: 'array',
					source: 'children',
					selector: '.slide-subtitle',
				},
				slideEditor: {
					type: 'array',
					source: 'children',
					selector: '.slide-editor',
				},
				newWindow: {
					type: 'boolean',
					default: false,
				},
				buttonText: {
					type: 'array',
					source: 'children',
					selector: '.more-link',
				},
				buttonUrl: {
					type: 'string',
					source: 'attribute',
					selector: 'a',
					attribute: 'href',
				},
				buttonColor: {
					type: 'string',
				},
				...TextOptionsAttributes,
			},
			save: props => {
				const { attributes: { backgroundImage, contentAlignment, slideTitle, slideSubtitle, slideEditor, newWindow, buttonText, buttonUrl, buttonColor },
					className } = props;

				let contentAlign = '';
				if ( contentAlignment === 'right' ) {
					contentAlign = 'text-right';
				}

				let linkTarget = '';
				newWindow === true ? linkTarget = '_blank' : linkTarget = null;

				let relAttr = '';
				linkTarget && linkTarget !== undefined ? relAttr = 'noopener noreferrer' : relAttr = null;

				// get color object
				const buttonColorObject = getColorObjectByColorValue( colors, buttonColor );
				let buttonColorName = '';

				( buttonColorObject && buttonColorObject !== undefined ? (
					// get 'slug' value from color object
					buttonColorName = buttonColorObject.slug
				) : null );

				// Return the markup displayed on the front-end.
				return (
					<div
						className={ classnames(
							className,
							blockClasses,
						) }
					>

						{ backgroundImage ? (
							<div
								className={ classnames( imageClasses ) }
								style={ {
									backgroundImage: `url(${ backgroundImage.url })`,
									backgroundPosition: 'center',
								} }
							>
							</div>
						) : null }

						<div
							className={ classnames(
								editorClasses,
								contentAlign,
								...TextOptionsClasses( props ),
							) }
						>

							<div className={ 'container' }>

								{ ( slideTitle && slideTitle.length > 0 ) ? (
									<RichText.Content
										tagName='h1'
										className={ 'slide-title' }
										value={ slideTitle }
									/>
								) : null }

								{ ( slideSubtitle && slideSubtitle.length > 0 ) ? (
									<RichText.Content
										tagName='h3'
										className={ 'slide-subtitle' }
										value={ slideSubtitle }
									/>
								) : null }

								{ ( slideEditor && slideEditor.length > 0 ) ? (
									<RichText.Content
										tagName='div'
										className={ 'slide-editor' }
										value={ slideEditor }
									/>
								) : null }

								<RichText.Content
									tagName="a"
									className={ classnames( 'more-link', 'btn', `btn-${ buttonColorName }` ) }
									href={ buttonUrl }
									target={ linkTarget }
									rel={ relAttr }
									value={ buttonText }
								/>
							</div>
						</div>
					</div>
				);
			},
		},
	]
} );
