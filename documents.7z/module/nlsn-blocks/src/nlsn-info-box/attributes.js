const attributes = {
	type: {
		type: 'string',
		default: 'blockquote',
	},
	headline: {
		type: 'string',
		source: 'html',
		selector: '.info-headline',
	},
	body: {
		type: 'string',
		source: 'html',
		selector: '.info-body',
	},
	footnote: {
		type: 'string',
		source: 'html',
		selector: '.info-footnote',
	},
	img: {
		type: 'object',
		default: {
			id: '',
			url: '',
			alt: '',
		},
	},
	border: {
		type: 'object',
		default: {},
	},
};

export default attributes;
