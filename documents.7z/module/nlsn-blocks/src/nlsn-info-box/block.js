/**
 * BLOCK: Info Box
 */

// Block dependencies
import attributes from './attributes';
import defineClassNames from '../utilities/defineClasses';

// Import all of our Container Options requirements.
import ContainerOptions, {
	ContainerOptionsAttributes,
	HideSectionEdit,
	BlockIdEdit,
} from '../components/container-options';

// WordPress dependencies
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks

// Editor components
const {
	InspectorControls,
	RichText,
	MediaUpload,
	PanelColorSettings,
} = wp.blockEditor;

// WordPress components
const {
	PanelBody,
	PanelRow,
	SelectControl,
	Button,
} = wp.components;
const { Fragment } = wp.element;

import { cancelCircleFilled, gallery, info as infoIcon } from '@wordpress/icons';

// Block styles
// import './style.scss';

registerBlockType( 'nlsn-blocks/nlsn-info-box', {
	title: __( 'Info Box - NLSN', 'nlsn-blocks' ),
	description: __( 'Select between a blockquote or fact information box.', 'nlsn-blocks' ),
	infoIcon,
	category: 'nielsen-blocks',
	keywords: [
		__( 'nielsen', 'nlsn-blocks' ),
		__( 'info information', 'nlsn-blocks' ),
		__( 'box', 'nlsn-blocks' ),
	],
	attributes: {
		...attributes,
		...ContainerOptionsAttributes,
	},

	edit: ( props ) => {
		const {
			attributes: {
				body,
				img,
				headline,
				footnote,
				type,
				border,
				containerSettings,
			},
			isSelected,
			setAttributes,
			className,
		} = props;

		const classes = defineClassNames( props, 'info-box' );

		// METHODS
		const onChangeContent = ( element, updatedValue ) => {
			setAttributes( { [ element ]: updatedValue } );
		};

		// ELEMENTS
		const BodyEditor = <RichText
			tagName="p"
			className="info-body d-block"
			placeholder={ __( 'Add the body of your info box here...', 'nlsn-blocks' ) }
			value={ body }
			onChange={ ( value ) => onChangeContent( 'body', value ) }
		/>;

		return (
			<div key="editor-display" className={ className }>
				{ isSelected &&
					<InspectorControls>
						<ContainerOptions { ...props } />
						<PanelBody
							title={ __( 'Info Box Settings', 'nlsn-blocks' ) }
						>
							<PanelRow>
								<SelectControl
									label={ __( 'Type', 'nlsn-blocks' ) }
									options={ [
										{ value: 'fact', label: __( 'Fact', 'nlsn-blocks' ) },
										{ value: 'blockquote', label: __( 'Blockquote', 'nlsn-blocks' ) },
									] }
									value={ type }
									onChange={ ( value ) => onChangeContent( 'type', value ) }
								/>
							</PanelRow>

							<PanelRow>
								<PanelColorSettings
									title={ __( 'Color Settings', 'nlsn-blocks' ) }
									colorSettings={ [
										{
											value: border.color,
											onChange: ( color ) => onChangeContent( 'border', { color } ),
											label: __( 'Border Color', 'nlsn-blocks' ),
										},
									] }
								>
								</PanelColorSettings>
							</PanelRow>
						</PanelBody>
					</InspectorControls>
				}

				<div className={ classes.container } id={ classes.id }>

					{ containerSettings ? (
						<div className="container-settings">
							<BlockIdEdit
								{ ...props }
							/>
							<HideSectionEdit
								{ ...props }
							/>
						</div>
					) : null }

					<div className="container">
						<div className={ classes.infoBox }>
							<div className={ `box-component box-${ type }` }>
								<div className="row no-gutters justify-content-center">
									<div className={ classes.width }>
										<div className="box-icon">
											<span className={ classes.iconBox }>
												{
													( 'blockquote' === type ) ? `${ String.fromCharCode( 8220 ) }` : ''
													// The above is a double left-quote symbol character code. You can't use HTML entities in template concatenation which is required in this instance.
												}
											</span>
										</div>
										<div className="box-content col-md-12">

											{ 'blockquote' === type ? (
												<Fragment>

													{ ( img.id === '' ) ? ( // If there isn't an image then show the media button.
														<MediaUpload
															value={ ( ! img ) ? '' : img.id }
															onSelect={ ( imgData ) => {
																onChangeContent( 'img', imgData );
															} }
															render={ ( { open } ) => (
																<Button onClick={ open } icon={ gallery } > Add/Upload Image </Button>
															) }
														/>
													) : ( // Else, display the image.
														<p className="img-wrapper">
															<img src={ img.url } alt={ img.alt } />
															{ isSelected ? (
																<Button
																	className="remove-image"
																	icon={ cancelCircleFilled }
																	onClick={ () => {
																		onChangeContent( 'img', {
																			id: '',
																			src: '',
																			alt: '',
																		} );
																	} }
																>
																</Button>
															) : null }
														</p>
													) }

													<RichText
														tagName="h3"
														className="info-headline d-block"
														placeholder={ __( 'Add headline', 'nlsn-blocks' ) }
														multiline="false"
														value={ headline }
														onChange={ ( value ) => onChangeContent( 'headline', value ) }
													/>
													<Fragment>
														{ BodyEditor }
													</Fragment>
													{ ( isSelected || ( footnote && footnote.length > 0 ) ) && ( // Display the footnote only if the block is selected OR the footnote attribute has a value that has been inputted by the user.
														<RichText
															tagName="h5"
															className="info-footnote text-right"
															placeholder={ __( 'Add footnote', 'nlsn-blocks' ) }
															multiline="false"
															value={ footnote }
															onChange={ ( value ) => onChangeContent( 'footnote', value ) }
														/>
														) }
												</Fragment>
											) : (
												<Fragment>
													{ BodyEditor }
												</Fragment>
											) }

										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		)
	},

	save: ( props ) => {
		const {
			attributes: {
				body,
				img,
				headline,
				footnote,
				type,
			},
			className,
		} = props;

		const classes = defineClassNames( props, 'info-box', 'save' );

		return (
			<div className={ className }>
				<div className={ classes.container } id={ classes.id }>
					<div className="container">
						<div className={ classes.infoBox }>
							<div className={ `box-component box-${ type }` }>
								<div className="row no-gutters justify-content-center">
									<div className={ classes.width }>
										<div className="box-icon">
											<span className={ classes.iconBox }>
												{
													( 'blockquote' === type ) ? `${ String.fromCharCode( 8220 ) }` : ''
													// The above is a double left-quote symbol character code. You can't use HTML entities in template concatenation which is required in this instance.
												}
											</span>
										</div>
										<div className="box-content">

											{ 'blockquote' === type ? (
												<Fragment>
													<Fragment>
														{ img.id !== '' &&
															<p className="img-wrapper">
																<Fragment>
																	<img src={ img.url } alt={ img.alt } />
																</Fragment>
															</p>
														}
													</Fragment>
													<Fragment>
														{ headline && headline.length > 0 &&
															<RichText.Content
																tagName="h3"
																className="info-headline"
																value={ headline }
															/>
														}
													</Fragment>
													<Fragment>
														{ body && body.length > 0 &&
															<RichText.Content
																tagName="p"
																className="info-body"
																value={ body }
															/>
														}
													</Fragment>
													<Fragment>
														{ footnote && footnote.length > 0 &&
															<RichText.Content
																tagName="h5"
																className="info-footnote text-right"
																value={ footnote }
															/>
														}
													</Fragment>
												</Fragment>
											) : (
												<Fragment>
													{ body.length > 0 &&
														<p className="info-body">{ body }</p>
													}
												</Fragment>
											) }

										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		);
	},
} );
