/**
 * BLOCK: Slider
 */

// Block dependencies
import classnames from 'classnames';
import attributes from './attributes';
import defineClassNames from '../utilities/defineClasses';
import icon from './icon';

// Import all of our Container Options requirements.
import ContainerOptions, {
	ContainerOptionsAttributes,
	HideSectionEdit,
	HideSectionSave,
	BlockIdEdit,
	BlockIdSave,
	BackgroundOptionsClasses,
	BlockPaddingClasses,
	BlockWidthClasses,
} from '../components/container-options';

import SliderOptions, {
	SliderOptionsAttributes,
	ColorHighlightClasses,
} from '../components/slider-options';

//  Import CSS.
// import './editor.scss';

// Components
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks

// Register editor components
const {
	InspectorControls,
	InnerBlocks,
} = wp.blockEditor;

const { withInstanceId } = wp.compose;

const blockClasses = classnames(
	`smart-slider`,
	`post-carousel`,
	`carousel`,
	`slide`,
);

// Register: Container Block.
registerBlockType( 'nlsn-blocks/nlsn-slider', {
	title: __( 'Slider - NLSN', 'nlsn-blocks' ),
	description: __( 'Slider Container - A slider container block. Slider blocks are added inside this container and they should all be the same.', 'nlsn-blocks' ),
	icon,
	category: 'nielsen-blocks',
	keywords: [
		__( 'slider', 'nlsn-blocks' ),
		__( 'container', 'nlsn-blocks' ),
		__( 'nielsen', 'nlsn-blocks' ),
	],
	attributes: {
		...attributes,
		...ContainerOptionsAttributes,
		...SliderOptionsAttributes,
	},

	/**
	 * Determines what is displayed in the editor.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 */
	edit: withInstanceId(	( props ) => {
		const {
			attributes: {
				containerSettings,
				sliderSettings,
				blockInstanceId,
			},
			isSelected,
			className,
			setAttributes,
			instanceId,
		} = props;

		props.attributes.blockInstanceId = 'nlsn-slider-id-' + instanceId

		const classes = defineClassNames( props, 'smart-slider' );

		// classes to be applied conditionally
		let sliderSettingsClasses = '';
		// if containerSettings is enabled, use the following classes
		if ( sliderSettings ) {
			sliderSettingsClasses = classnames(
				...ColorHighlightClasses( props ),
			)
		}

		// setup Slider container classes
		const sliderClasses = classnames(
			blockClasses,
			sliderSettingsClasses,
		)

		const BLOCK_TEMPLATE = [
			[ 'nlsn-blocks/nlsn-slide-editor-with-image', {} ],
		];

		const ALLOWED_BLOCKS = [
			'nlsn-blocks/nlsn-slide-editor-with-image',
		];

		// Return the markup displayed in the editor.
		return (
			<div key="editor-display" className={ className }>

				{ isSelected &&
					<InspectorControls>
						<ContainerOptions
							{ ...props }
						/>
						<SliderOptions
							{ ...props }
						/>
					</InspectorControls>
				}

				{ containerSettings &&
					<div className="container-settings">
						<BlockIdEdit
							{ ...props }
						/>
						<HideSectionEdit
							{ ...props }
						/>
					</div>
				}

				<div className={ classes.container } id={ classes.id }>
					<div className='container'>
						<div className='row justify-content-center'>
							<div className={ classes.width }>

								<div className={ sliderClasses }
								>
									<InnerBlocks
										template={ BLOCK_TEMPLATE }
										allowedBlocks={ ALLOWED_BLOCKS }
									/>
								</div>

							</div>
						</div>
					</div>

				</div>
			</div>
		)
	} ),

	/**
	 * Determines what is displayed on the front-end.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 */
	save: props => {
		const {
			attributes: {
				sliderSettings,
				blockInstanceId,
			},
			className,
		} = props;

		const classes = defineClassNames( props, 'smart-slider', 'save' );

		// classes to be applied conditionally
		let sliderSettingsClasses = '';
		// if sliderSettings is enabled, use the following classes
		if ( sliderSettings ) {
			sliderSettingsClasses = classnames(
				...ColorHighlightClasses( props ),
			)
		}

		// setup Slider container classes
		const sliderClasses = classnames(
			blockClasses,
			sliderSettingsClasses,
		)

		// values to be applied conditionally
		let setLoop = '';
		let setPause = '';
		let setAutoplay = '';
		let setTimeInterval = '';
		// if SliderOptions is enabled, use the following classes
		if ( props.attributes.sliderSettings ) {
			setLoop = props.attributes.loop ? 'true' : 'false'
			setPause = props.attributes.pauseOnHover ? 'hover' : 'false'
			setAutoplay = props.attributes.autoplay ? setTimeInterval = props.attributes.timeInterval * 1000 : setTimeInterval = 'false'
		}

		// Return the markup displayed on the front-end.
		return (
			<div className={ className }>

			<div
				id={ classes.id }
				className={ classes.container }
			>
					<div className='container'>
						<div className='row justify-content-center'>
							<div className={ classes.width }>

								<div
									id={ blockInstanceId }
									className={ sliderClasses }
									data-ride='carousel'
									data-wrap={ setLoop ? setLoop.toString() : 'true' }
									data-pause={ setPause ? setPause : 'hover' }
									data-interval={ setAutoplay ? setTimeInterval : '5000' }
								>
									<div className='carousel-inner'>
										<InnerBlocks.Content />
									</div>
								</div>

							</div>
						</div>
					</div>

				</div>
			</div>
		);
	},

	deprecated: [
		{

		},
	]
} );
