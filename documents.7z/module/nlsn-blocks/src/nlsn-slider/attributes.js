const attributes = {
  blockInstanceId: {
    type: 'text',
  }
};

export default attributes;
