/**
 * BLOCK: Container
 */

// Block dependencies
import classnames from 'classnames';
import defineClassNames from '../utilities/defineClasses';
import icon from './icon';

// Import all of our Container Options requirements.
import ContainerOptions, {
	ContainerOptionsAttributes,
	HideSectionEdit,
	HideSectionSave,
	BlockIdEdit,
	BlockIdSave,
	BackgroundOptionsClasses,
	BackgroundImages,
	BackgroundVideos,
	BackgroundVideosImages,
	BlockPaddingClasses,
	BlockWidthClasses,
	TextOptionsClasses,
	MarginOptionsEdit,
	HeroOptionsClasses,
	DirectionalArrowClasses,
} from '../components/container-options';

//  Import CSS.
//import './editor.scss';

// Components
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks

// Register editor components
const {
	InspectorControls,
	InnerBlocks,
} = wp.blockEditor;

// Register: Container Block.
registerBlockType( 'nlsn-blocks/nlsn-container', {
	title: __( 'Container - NLSN', 'nlsn-blocks' ),
	description: __( 'Add blocks inside of a container.', 'nlsn-blocks' ),
	icon,
	category: 'nielsen-blocks',
	keywords: [
		__( 'container', 'nlsn-blocks' ),
		__( 'module', 'nlsn-blocks' ),
		__( 'nielsen', 'nlsn-blocks' ),
	],
	attributes: {
		...ContainerOptionsAttributes,
	},
	edit: props => {
		const {
			attributes: {
				containerSettings,
				backgroundType,
				backgroundVideo,
				backgroundVideoImage,
			},
			isSelected,
			className,
		} = props;

		const classes = defineClassNames( props, 'container' );


		return (
			
			<>

				<InspectorControls>
					<ContainerOptions
						{ ...props }
						fullFunctionality={ true }
						negativeMarginFunctionality={ true }
					/>
				</InspectorControls>

				{ containerSettings &&
					<div className="container-settings">
						<BlockIdEdit
							{ ...props }
						/>
						<HideSectionEdit
							{ ...props }
						/>
						<MarginOptionsEdit
							{ ...props }
						/>
					</div>
				}

				<div className={ classes.container + ' ' + classes.width } style={ classes.styles }>
					{ ( 'image' === backgroundType && containerSettings ) &&
						<BackgroundImages
							{ ...props }
						/>
					}
					{ ( 'video' === backgroundType && containerSettings && backgroundVideo ) &&
						<div>
							<div className='video-embeded'>
								{ 'Video Embeded!' }
							</div>
							{ ( backgroundVideoImage ) &&
								<BackgroundVideosImages
									{ ...props }
								/>
							}
						</div>
					}
					<InnerBlocks />
				</div>
			</>
		)
	},
	save: props => {
		const {
			attributes: {
				containerSettings,
				backgroundType,
				backgroundVideo,
				backgroundVideoImage,
			},
			className,
		} = props;

		const classes = defineClassNames( props, 'container', 'save' );

		return (
			<div className={ className }>
				<div
					id={ classes.id }
					className={ classes.container }
					style={ classes.styles }
				>

					{ ( 'image' === backgroundType && containerSettings ) &&
						<BackgroundImages
							{ ...props }
						/>
					}
					{ ( 'video' === backgroundType && containerSettings ) &&
						<BackgroundVideos
							{ ...props }
						/>
					}
					{ ( 'video' === backgroundType && containerSettings && backgroundVideoImage ) &&
						<BackgroundVideosImages
							{ ...props }
						/>
					}

					<div className="container">
						<div className="row justify-content-center">
							<div className={ classes.width }>
								<InnerBlocks.Content />
							</div>
						</div>
					</div>

				</div>
			</div>
		);
	},

	/**
	 * Provide a “deprecated” version of the block.
	 * This allows users opening these blocks in Gutenberg to edit them using the updated block.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/deprecated-blocks/
	 */
	deprecated: [
		{

		},
	],
} );

