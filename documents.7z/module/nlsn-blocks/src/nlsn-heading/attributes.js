const attributes = {
	content: {
		type: 'array',
		source: 'children',
		selector: 'h1,h2,h3,h4,h5,h6',
	},
	level: {
		type: 'number',
		default: 2,
	},
	align: {
		type: 'string',
	},
	placeholder: {
		type: 'string',
	},
	headingColor: {
		type: 'string',
	},
	highlightColor: {
		type: 'string',
	},
};

export default attributes;
