/**
 * BLOCK: Heading
 */

// Block dependencies
import classNames from 'classnames';
import attributes from './attributes';
import icon from './icon';
import HeadingLevelDropdown from './heading-level-dropdown';

import range from 'lodash/range';

// Import all of our Container Options requirements.
import ContainerOptions, {
	ContainerOptionsAttributes,
	BackgroundOptionsClasses,
	BlockPaddingClasses,
	BlockWidthClasses,
	HideSectionEdit,
	HideSectionSave,
	BlockIdEdit,
	BlockIdSave,
} from '../components/container-options';

import { colors } from '../components/colors/colorUtils';

// Import CSS
// import './editor.scss'; //Removing this since now the styles are in the base theme

// WordPress dependencies
const { __, sprintf } = wp.i18n;
const {	registerBlockType } = wp.blocks;

// Editor components
const {
	InspectorControls,
	PanelColorSettings,
	RichText,
	BlockControls,
	AlignmentToolbar,
	getColorObjectByColorValue,
	RichTextToolbarButton,
	RichTextShortcut,
} = wp.blockEditor;

const {
	registerFormatType,
	toggleFormat
} = wp.richText;
// WordPress components
const {
	PanelBody,
	Toolbar,
	ToolbarButton,
} = wp.components;
const { Fragment } = wp.element;

// Default classnames shared between edit and save methods
const defaultContainerClasses = classNames( 'module', 'alignfull' );

const defineClassNames = ( props, view = 'edit' ) => {
	// DEFINING CLASSNAMES
	let customContainerClasses;
	let customWidthClasses;
	let customBlockId;

	// If containerSettings is enabled, use the following classes...
	if ( props.attributes.containerSettings ) {
		if ( view === 'save' ) {
			customContainerClasses = classNames(
				...HideSectionSave( props ),
				...BackgroundOptionsClasses( props ),
				...BlockPaddingClasses( props ),
			);
			customBlockId = classNames( ...BlockIdSave( props ) );
		} else {
			customContainerClasses = classNames(
				...BackgroundOptionsClasses( props ),
				...BlockPaddingClasses( props ),
			);
		}
		customWidthClasses = classNames( ...BlockWidthClasses( props ) );
	} else {
		customWidthClasses = classNames( 'col-md-12' );
	}

	// Combine our default classes with any custom classes.
	const container = classNames(
		defaultContainerClasses,
		customContainerClasses,
	);

	const width = classNames(
		customWidthClasses,
		{
			'col-md-12': ( customWidthClasses.length === 0 ), // If they enable container settings for the first time this will ensure that the text is properly aligned.
		}
	);

	const align = classNames( {
		'text-left': ( props.attributes.align === 'left' || props.attributes.align === undefined ),
		'text-center': ( props.attributes.align === 'center' ),
		'text-right': ( props.attributes.align === 'right' ),
	} );

	return {
		customBlockId,
		container,
		width,
		align,
	};
};


registerBlockType( 'nlsn-blocks/nlsn-heading', {
	title: __( 'Heading - NLSN', 'nlsn-blocks' ),
	description: __( 'Insert a headline above your content with customizable container settings.', 'nlsn-blocks' ),
	icon: icon,
	category: 'nielsen-blocks',
	keywords: [
		__( 'nielsen', 'nlsn-blocks' ),
		__( 'heading', 'nlsn-blocks' ),
		__( 'headline', 'nlsn-blocks' ),
	],
	attributes: {
		...attributes,
		...ContainerOptionsAttributes,
	},

	edit: ( props ) => {
		const {
			attributes: {
				align,
				content,
				level,
				placeholder,
				headingColor,
				highlightColor,
				containerSettings,
			},
			setAttributes,
			mergeBlocks,
			insertBlocksAfter,
			onReplace,
			className,
		} = props;

		const classNamesObject = defineClassNames( props );


		// ELEMENTS
		const tagName = `h${ level }`;
		const AlignmentOptions = () => {
			return (
				<AlignmentToolbar
					value={ align }
					onChange={ ( nextAlign ) => {
						setAttributes( { align: nextAlign } );
					} }
				/>
			);
		};
		const colorPaletteOption = () => {
			return (
				<PanelColorSettings
					title={ __( 'Color Settings', 'nlsn-blocks' ) }
					colorSettings={ [
						{
							value: headingColor,
							onChange: ( headingColor ) => setAttributes( { headingColor } ),
							label: __( 'Heading Color', 'nlsn-blocks' ),
						},
						{
							value: highlightColor,
							onChange: ( highlightColor ) => setAttributes( { highlightColor } ),
							label: __( 'Highlight Color', 'nlsn-blocks' ),
						},
					] }
				>

				</PanelColorSettings>
			);
		};

		// get color object
		const headingColorObject = getColorObjectByColorValue( colors, headingColor );
		const highlightColorObject = getColorObjectByColorValue( colors, highlightColor );
		let headingColorName = '';
		let highlightColorName = '';

		( headingColorObject && headingColorObject !== undefined ? (
			// get 'slug' value from color object
			headingColorName = headingColorObject.slug
		) : null );

		( highlightColorObject && highlightColorObject !== undefined ? (
			// get 'slug' value from highlight color object
			highlightColorName = highlightColorObject.slug
		) : null )

		return [
			<Fragment key="controls-display">
				<BlockControls>
					<HeadingLevelDropdown
						selectedLevel={ level }
						onChange={ ( newLevel ) =>
							setAttributes( { level: newLevel } )
						}
					/>
					{ AlignmentOptions() }
				</BlockControls>

				<InspectorControls>
					<ContainerOptions { ...props } />
					<PanelBody
						title={ __( 'Heading Settings' ) }
					>
						<p>{ __( 'Text Alignment' ) }</p>
						{ AlignmentOptions() }
						{ colorPaletteOption() }
					</PanelBody>
				</InspectorControls>

				{ containerSettings ? (
					<div className="container-settings">
						<BlockIdEdit
							{ ...props }
						/>
						<HideSectionEdit
							{ ...props }
						/>
					</div>
				) : null }
			</Fragment>,
			<div key="editor-display" className={ className }>
				<div className={ classNamesObject.container } id={ classNamesObject.customBlockId }>
					<div className="container">
						<div className="row no-gutters justify-content-center">
							<div className={ `${ classNamesObject.width } ${ classNamesObject.align } text-${ headingColorName }` }>
								<div className="wp-block-heading">
									<RichText
										tagName={ tagName }
										value={ content }
										className={ `text-bg-${ highlightColorName }`}
										onChange={ ( value ) => setAttributes( { content: value } ) }
										placeholder={ placeholder || __( 'Write heading…' ) }
									/>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>,
		];
	},

	save: ( props ) => {
		const {
			attributes: {
				level,
				content,
				headingColor,
				highlightColor,
			},
			className,
		} = props;

		const classNamesObject = defineClassNames( props, 'save' );

		const tagName = `h${ level }`;
		const headingColorObject = getColorObjectByColorValue( colors, headingColor );
		const highlightColorObject = getColorObjectByColorValue( colors, highlightColor );
		let headingColorName = null;
		let highlightColorName = null;
		if (headingColorObject !== undefined) {
			headingColorName = getColorObjectByColorValue( colors, headingColor ).slug;
		};
		if (highlightColorObject !== undefined) {
			highlightColorName = getColorObjectByColorValue( colors, highlightColor ).slug;
		}

		return (
			<div className={ className }>
				<div className={ classNamesObject.container } id={ classNamesObject.customBlockId }>
					<div className="container">
						<div className="row no-gutters justify-content-center">

						{highlightColorName ? (

							<div className={ `${ classNamesObject.width } ${ classNamesObject.align } text-${ headingColorName } text-highlight text-bg-${ highlightColorName }` }>
								<RichText.Content
									tagName={ tagName }
									value={ content }
									className={ 'highlight-box' }
								/>
							</div>
						) : (
							<div className={ `${ classNamesObject.width } ${ classNamesObject.align } text-${ headingColorName }` }>
								<RichText.Content
									tagName={ tagName }
									value={ content }
								/>
							</div>
						)}

						</div>
					</div>
				</div>
			</div>
		);
	},

	//Add deprecated values
	deprecated: [
        {
					attributes: {
						...attributes,
						...ContainerOptionsAttributes,
					},

						save: ( props ) => {
							const {
								attributes: {
									level,
									content,
									headingColor,
								},
								className,
							} = props;

							const classNamesObject = defineClassNames( props, 'save' );

							const tagName = `h${ level }`;
							const headingColorObject = getColorObjectByColorValue( colors, headingColor );
							let headingColorName = null;
							if (headingColorObject !== undefined) {
								headingColorName = getColorObjectByColorValue( colors, headingColor ).slug;
							}

							return (
								<div className={ className }>
									<div className={ classNamesObject.container } id={ classNamesObject.customBlockId }>
										<div className="container">
											<div className="row no-gutters justify-content-center">
												<div className={ `${ classNamesObject.width } ${ classNamesObject.align } text-${ headingColorName }` }>
													<RichText.Content
														tagName={ tagName }
														value={ content }
													/>
												</div>
											</div>
										</div>
									</div>
								</div>
							);
						},
        }
    ]
} );

registerFormatType(
'nlsn/text-highlight', {
		title: 'Highlight',
		tagName: 'mark',
		className: 'heading-highlight',
		edit( { isActive, value, onChange } ) {
		const onToggle = () => onChange( toggleFormat( value, { type: 'nlsn/text-highlight' } ) );



		return (
			<Fragment>
				<RichTextShortcut
					type="primary"
					character="m"
					onUse={ onToggle }
				/>
				<RichTextToolbarButton
					icon="admin-appearance"
					title={ __( 'Text Highlight' ) }
					onClick={ onToggle }
					isActive={ isActive }
					shortcutType="primary"
					shortcutCharacter="m"
					className="toolbar-button-with-text toolbar-button__advanced-mark"
				/>
			</Fragment>
		);
	},
});
