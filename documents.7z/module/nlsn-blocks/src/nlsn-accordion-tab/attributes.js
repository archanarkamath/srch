const attributes = {
	accordionTitle: {
		type: 'text',
	},
	accordionOpen: {
		type: 'boolean',
		default: false
	},
	accordionTabId: {
		type: 'string',
	},
};

export default attributes;
