/**
 * Internal block libraries
 */
const { __ } = wp.i18n;
const { Component } = wp.element;

const {
  PanelBody,
	PanelRow,
  ToggleControl,
} = wp.components;


/**
 * Create an Inspector Controls wrapper Component
 */
export default class Inspector extends Component {

	constructor( props ) {
		super( ...arguments );
	}

	render() {

		// Setup the attributes
		const { attributes: { accordionOpen }, setAttributes } = this.props;

		return (
      <PanelBody title={ __( 'Panel Settings' ) }>
				<PanelRow>
					<ToggleControl
						label={ __( 'Open by default' ) }
						checked={ accordionOpen }
						onChange={ () => this.props.setAttributes( { accordionOpen: ! accordionOpen } ) }
					/>
				</PanelRow>
      </PanelBody>
		);
	}
}
