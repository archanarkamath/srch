/**
 * BLOCK: Accordion
 */

 // Block dependencies
import classnames from 'classnames';
import Inspector from './inspector';
import attributes from './attributes';
import icons from './icons';

// Components
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks

// Register editor components
const {
	RichText,
	InspectorControls,
	InnerBlocks,
} = wp.blockEditor;

const {
	withInstanceId,
} = wp.compose;

const blockClasses = classnames(
	`card`,
);

// Register the block
registerBlockType( 'nlsn-blocks/nlsn-accordion-tab', {
	title: __( 'Accordion Tab - NLSN' ),
	description: __( 'Add Accordion Tabs for this section' ),
	icon: icons.tab,
	category: 'nielsen-blocks',
	keywords: [
		__( 'accordion' ),
	],
	parent: [ 'nlsn-blocks/nlsn-accordion' ],
	attributes: {
		...attributes
	},

	// Render the block components
	edit: withInstanceId (
		props => {
			// Setup the attributes
			const {
				attributes: {
					accordionTitle,
					accordionOpen,
					accordionTabId,
				},
				instanceId,
				isSelected,
				className,
				setAttributes,
			} = props;

		props.attributes.accordionTabId = 'accordion-item-' + instanceId;

		let AccordionItemLinkClasses  = classnames({'collapsed': ! accordionOpen});

		return [
			isSelected && (
				<InspectorControls>
					<Inspector
						{ ...props }
					/>
				</InspectorControls>
			),

			<div className={blockClasses}>
				<div className="card-header" role="tab">
					<h5 className={ classnames( 'accordion-title' ) }>
						<a className={AccordionItemLinkClasses}>
							<RichText
								multiline='false'
								style={ { lineHeight: "normal" } }
								formattingControls={ [] }
								placeholder={ __( 'Accordion Title' ) }
								value={ accordionTitle }
								onChange={ ( value ) => setAttributes( { accordionTitle: value } ) }
							/>
						</a>
					</h5>
				</div>
				<div>
					<div className="card-block">
						<InnerBlocks templateLock={ false }/>
					</div>
				</div>
			</div>
		]
	} ),

	// Save the attributes and markup
	save: props => {

		// Setup the attributes
		const {
			attributes: {
				accordionTitle,
				accordionOpen,
				accordionTabId,
			},
			className,
		} = props;

		let AccordionItemLinkAriaExpanded  = String(accordionOpen);
		let AccordionItemLinkClasses  = classnames({'collapsed': ! accordionOpen});
		let AccordionItemClasses = classnames('collapse', {show: accordionOpen});

		var icons = (
			<div>
				<i className="icon-open icon-left fa fa-plus" aria-hidden="true"></i>
				<i className="icon-close icon-left fa fa-minus" aria-hidden='true'></i>
			</div>
		);

		return (
			<div className={ blockClasses }>
					{ accordionTitle ? (
						<div className="card-header" role="tab">
							<h5 className={ classnames( 'accordion-title' ) }>
								<a
									href={ '#' + accordionTabId }
									className={ AccordionItemLinkClasses }
									data-toggle="collapse"
									aria-expanded={ AccordionItemLinkAriaExpanded }
									aria-controls={ accordionTabId }
								>
										{ icons }
										{ accordionTitle }
								</a>
							</h5>
						</div>
					) : (
						null
					) }

					{ accordionTitle ? (
						<div
							id={ accordionTabId }
							className= { AccordionItemClasses }
							role="tabpanel"
							aria-expanded={ AccordionItemLinkAriaExpanded }
						>
							<div className="card-block">
								<InnerBlocks.Content />
							</div>
						</div>
					) : (
						null
					) }
			</div>
		);
	},

	deprecated : [
		{

		},
	]
} );
