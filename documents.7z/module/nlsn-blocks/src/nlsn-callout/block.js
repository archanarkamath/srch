/**
 * BLOCK: Callout
 */

// Block dependencies
import classnames from 'classnames';
import defineClassNames from '../utilities/defineClasses';
import Inspector from './inspector';
import attributes from './attributes';
import icon from './icon';

import { Icon, keyboardReturn, link } from '@wordpress/icons';

// Import all of our Container Options requirements.
import ContainerOptions, {
	ContainerOptionsAttributes,
	HideSectionEdit,
	BlockIdEdit,
	NLSNHeading,
} from '../components/container-options';

import { colors } from '../components/colors/colorUtils';

// Register editor components
const {
	InspectorControls,
	RichText,
	URLInput,
	getColorObjectByColorValue,
} = wp.blockEditor;

const {
	Button,
	Tooltip,
} = wp.components;

const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks

const blockClasses = classnames(
	'callout',
);

// Register: Call to action
registerBlockType( 'nlsn-blocks/nlsn-callout', {
	title: __( 'Callout - NLSN', 'nlsn-blocks' ),
	description: __( 'This is a callout module.  The link button in this callout can be left-aligned, centered, or right aligned.  There are also different color options for the button.', 'nlsn-blocks' ),
	icon,
	category: 'nielsen-blocks',
	keywords: [
		__( 'callout', 'nlsn-blocks' ),
		__( 'action', 'nlsn-blocks' ),
		__( 'nielsen', 'nlsn-blocks' ),
	],
	attributes: {
		...attributes,
		...ContainerOptionsAttributes,
	},

	/**
	 * Determines what is displayed in the editor.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 * @param {Object} props - The properties that are available to this block.
	 * @returns {Object} - How the block will display in the Gutenberg editor.
	 */
	edit: props => {
		const {
			attributes: {
				containerSettings,
				headingContent,
				calloutText,
				buttonURL,
				buttonTitle,
				buttonColor,
				alignment,
			},
			isSelected,
			className,
			setAttributes,
		} = props;

		const classes = defineClassNames( props, 'callout' );

		let buttonAlign = '';

		buttonAlign = classnames(
			'd-flex',
			'justify-content-center',
			{ 'flex-row-reverse': alignment === 'left' },
			{ 'flex-row': alignment === 'right' },
			{ 'flex-column': alignment === 'center' },
			{ 'flex-column': ( typeof alignment === 'undefined' ) },
		);

		// get color object
		const buttonColorObject = getColorObjectByColorValue( colors, buttonColor );
		let buttonColorName = '';

		( buttonColorObject && buttonColorObject !== undefined ? (
			// get 'slug' value from color object
			buttonColorName = buttonColorObject.slug
		) : null )

		const buttonClasses = classnames(
			'btn',
			`btn-${ buttonColorName }`,
		);

		// Return the markup displayed in the editor.
		return (
			<div key="editor-display" className={ className }>

				{ isSelected &&
					<InspectorControls>
						<ContainerOptions
							{ ...props }
						/>
						<Inspector
							{ ...props }
						/>
					</InspectorControls>
				}

				{ containerSettings &&
					<div className="container-settings">
						<BlockIdEdit
							{ ...props }
						/>
						<HideSectionEdit
							{ ...props }
						/>
					</div>
				}

				<div className={ classes.container } id={ classes.id }>
					<div className="container">
						<div className="row justify-content-center">
							<div className={ classes.width }>

								<div className={ classnames( blockClasses, buttonAlign ) }>
									<div className="align-self-center">

										{ ( ( headingContent && headingContent.length > 0 ) || isSelected ) &&
											<NLSNHeading.edit { ...props } />
										}

										<RichText
											tagName='div'
											multiline='p'
											className={ classnames(
												'callout-text'
											) }
											placeholder={ __( 'Add Message', 'nlsn-blocks' ) }
											value={ calloutText }
											onChange={ value => {
												setAttributes( { calloutText: value } );
											} }
										/>

									</div>
									<div className="callout-button align-self-center">
										{ ( ( buttonTitle && buttonTitle.length > 0 ) || isSelected ) && (
											<div
												style={ { display: 'inline-block' } }
											>
												<RichText
													tagName="p"
													multiline="false"
													className={ classnames( 'callout-link', buttonClasses ) }
													placeholder={ __( 'Button Title', 'nlsn-blocks' ) }
													value={ buttonTitle }
													onChange={ value => setAttributes( { buttonTitle: value } ) }
												/>
											</div>
										) }
										{ isSelected && (
											<form
												id="buttonUrl"
												className="button-url"
												onSubmit={ event => event.preventDefault() }
											>
												<Tooltip
													text="Add Link"
													children="url"
												>
													<Icon icon={ link } />
													<label htmlFor="buttonUrl">{ __( ' Add Link', 'nlsn-blocks' ) }</label>
												</Tooltip>

												<URLInput
													className="url"
													value={ buttonURL }
													onChange={ value => setAttributes( { buttonURL: value } ) }
												/>
												<Button
													icon={ keyboardReturn }
													label={ __( 'Apply', 'nlsn-blocks' ) }
													type="submit"
												/>
											</form>
										) }
									</div>
								</div>

							</div>
						</div>
					</div>
				</div>
			</div>
		)
	},

	/**
	 * Determines what is displayed on the front-end.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 * @param {Object} props - The properties that are available to this block.
	 * @returns {Object} - How the block will display on the front-end.
	 */
	save: props => {
		const {
			attributes: {
				calloutText,
				buttonURL,
				buttonTarget,
				buttonTitle,
				buttonColor,
				alignment,
			},
			className,
		} = props;

		const classes = defineClassNames( props, 'callout', 'save' );

		let buttonAlign = '';

		buttonAlign = classnames(
			'd-flex',
			'justify-content-center',
			{ 'flex-row-reverse': alignment === 'left' },
			{ 'flex-row': alignment === 'right' },
			{ 'flex-column': alignment === 'center' },
			{ 'flex-column': ( typeof alignment === 'undefined' ) },
		);

		let linkTarget = '';
		buttonTarget === true ? linkTarget = '_blank' : linkTarget = null;

		let relAttr = '';
		linkTarget && linkTarget !== undefined ? relAttr = 'noopener noreferrer' : relAttr = null;

		// get color object
		const buttonColorObject = getColorObjectByColorValue( colors, buttonColor );
		let buttonColorName = '';

		( buttonColorObject && buttonColorObject !== undefined ? (
			// get 'slug' value from color object
			buttonColorName = buttonColorObject.slug
		) : null )

		const buttonClasses = classnames(
			'btn',
			`btn-${ buttonColorName }`,
		);

		return (
			<div className={ className }>
				<div
					id={ classes.id }
					className={ classes.container }
				>
					<div className="container">
						<div className="row justify-content-center">
							<div className={ classes.width }>

								<div className={ classnames( blockClasses, buttonAlign ) }>
									<div className="align-self-center">
										<NLSNHeading.save { ...props } />
										<div className="callout-text">
											{ calloutText }
										</div>
									</div>

									{ ( buttonTitle && buttonTitle.length > 0 ) && (
										<div className="callout-button align-self-center">
											<RichText.Content
												tagName='a'
												className={ classnames( 'callout-link', buttonClasses ) }
												href={ buttonURL }
												target={ linkTarget }
												rel={ relAttr }
												value={ buttonTitle }
											/>
										</div>
									) }
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		);
	},

	deprecated: [
		{
			attributes: {
				calloutText: {
					type: 'array',
					source: 'children',
					selector: '.callout-text',
					default: '',
				},
				buttonURL: {
					type: 'string',
					default: '',
				},
				buttonTarget: {
					type: 'boolean',
					default: false,
				},
				buttonTitle: {
					type: 'string',
					default: '',
				},
				buttonColor: {
					type: 'string',
					default: '',
				},
				alignment: {
					type: 'string',
					default: 'center',
				},
				...ContainerOptionsAttributes,
			},
			save: props => {
				const {
					attributes: {
						calloutText,
						buttonURL,
						buttonTarget,
						buttonTitle,
						buttonColor,
						alignment,
					},
					className,
				} = props;

				const classes = defineClassNames( props, 'callout', 'save' );

				let buttonAlign = '';

				buttonAlign = classnames(
					'd-flex',
					'justify-content-center',
					{ 'flex-row-reverse': alignment === 'left' },
					{ 'flex-row': alignment === 'right' },
					{ 'flex-column': alignment === 'center' },
					{ 'flex-column': ( typeof alignment === 'undefined' ) },
				);

				let linkTarget = '';
				buttonTarget === true ? linkTarget = '_blank' : linkTarget = null;

				let relAttr = '';
				linkTarget && linkTarget !== undefined ? relAttr = 'noopener noreferrer' : relAttr = null;

				// get color object
				const buttonColorObject = getColorObjectByColorValue( colors, buttonColor );
				let buttonColorName = '';

				( buttonColorObject && buttonColorObject !== undefined ? (
					// get 'slug' value from color object
					buttonColorName = buttonColorObject.slug
				) : null )

				const buttonClasses = classnames(
					'btn',
					`btn-${ buttonColorName }`,
				);

				return (
					<div className={ className }>
						<div
							id={ classes.id }
							className={ classes.container }
						>
							<div className="container">
								<div className="row justify-content-center">
									<div className={ classes.width }>

										<div className={ classnames( blockClasses, buttonAlign ) }>
											<div className="align-self-center">
												<NLSNHeading.save { ...props } />
												<div className="callout-text">
													{ calloutText }
												</div>
											</div>

											{ ( buttonTitle && buttonTitle.length > 0 ) && (
											<div className="callout-button align-self-center">
												<RichText.Content
													tagName='a'
													className={ buttonClasses }
													href={ buttonURL }
													target={ linkTarget }
													rel={ relAttr }
													value={ buttonTitle }
												/>
											</div>
											) }
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				);
			},
		},
	],
} );
