/**
 * Internal block libraries
 */
const { __ } = wp.i18n;
const { Component } = wp.element;
const {
  PanelColorSettings,
} = wp.blockEditor;

const {
  PanelBody,
	PanelRow,
  ToggleControl,
	BaseControl,
	ButtonGroup,
	Button,
} = wp.components;
/**
 * Create an Inspector Controls wrapper Component
 */
export default class Inspector extends Component {

  constructor() {
    super( ...arguments );
  }

  render() {
    const {
			attributes: {
				buttonTarget,
				buttonColor,
				alignment
			},
			setAttributes
		} = this.props;

		// Button Alignment Options
		const buttonAlignment = {};
		buttonAlignment.alignment = [
		  { value: 'left',   label: 'Left',   icon: 'editor-alignleft' },
		  { value: 'center', label: 'Center', icon: 'editor-aligncenter' },
		  { value: 'right',  label: 'Right',  icon: 'editor-alignright' },
		];

    return (
      <PanelBody
				title={ __( 'Button Settings', 'nlsn-blocks' ) }
				initialOpen={ true }
			>

			<PanelRow>
				<BaseControl
					id={ 'callout-alignment' }
					className={ 'alignment-button-group' }
					label={ `Align ${alignment}` }
				>
					{ buttonAlignment.alignment.map( ( type ) => {
						return (
							<Button
								key={ type.label }
								icon={ type.icon }
								label={ __( type.label, 'nlsn-blocks' ) }
								style={ { display: 'd-inline', float: 'left' } }
								isPrimary={ alignment === type.value }
								aria-pressed={ alignment === type.value }
								onClick={ () => { setAttributes({ alignment: type.value } ) } }
							/>
						);
					})}
				</BaseControl>
			</PanelRow>

			<PanelRow>
				<ToggleControl
					label={ __( 'New Window', 'nlsn-blocks' ) }
					checked={ buttonTarget }
					help={ __( 'Open button link in new window?', 'nlsn-blocks' ) }
					onChange={ buttonTarget => setAttributes( { buttonTarget } ) }
				/>
			</PanelRow>

			<PanelRow>
				<PanelColorSettings
					title={ __( 'Color Settings', 'nlsn-blocks' ) }
					colorSettings={ [
						{
							value: buttonColor,
							onChange: ( buttonColor ) => setAttributes( { buttonColor } ),
							label: __( 'Button Color', 'nlsn-blocks' ),
						},
					] }
				>
				</PanelColorSettings>
			</PanelRow>

      </PanelBody>
    );
  }
}
