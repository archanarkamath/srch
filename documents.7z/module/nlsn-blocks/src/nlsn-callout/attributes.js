const attributes = {
	calloutText: {
		type: 'array',
		source: 'children',
		selector: '.callout-text',
		default: '',
	},
	buttonURL: {
		type: 'string',
		default: '',
	},
	buttonTarget: {
		type: 'boolean',
		default: false,
	},
	buttonTitle: {
		type: 'string',
		source: 'html',
		selector: '.callout-link',
	},
	buttonColor: {
		type: 'string',
		default: '',
	},
	alignment: {
		type: 'string',
		default: 'center',
	},
};

export default attributes;
