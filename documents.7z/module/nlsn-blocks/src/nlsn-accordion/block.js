/**
 * BLOCK: Accordion
 */

// Import block dependencies and components
import classnames from 'classnames';
import defineClassNames from '../utilities/defineClasses';
import attributes from './attributes';
import icons from './icons';

// Import all of our Container Options requirements.
import ContainerOptions, {
	ContainerOptionsAttributes,
	HideSectionEdit,
	BlockIdEdit,
} from '../components/container-options';

// import './editor.scss';

// Components
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks

// Register editor components
const {
	InspectorControls,
	InnerBlocks,
} = wp.blockEditor;

const ALLOWED_BLOCKS = [ 'nlsn-blocks/nlsn-accordion-tab' ];

const BLOCK_TEMPLATE = [
	[ 'nlsn-blocks/nlsn-accordion-tab', {} ],
];

// Register the block
registerBlockType( 'nlsn-blocks/nlsn-accordion', {
	title: __( 'Accordion - NLSN' ),
	description: __( 'Hide and show large amounts of content' ),
	icon: icons.accordion,
	category: 'nielsen-blocks',
	keywords: [
		__( 'accordion' ),
		__( 'navigation' ),
		__( 'Nielsen' ),
	],
	attributes: {
		...attributes,
		...ContainerOptionsAttributes,
	},
	// Render the block components
	edit: props => {
		// Setup the attributes
		const {
			attributes: {
				containerSettings,
				tabs,
			},
			isSelected,
			className,
		} = props;

		const classes = defineClassNames( props, 'accordion' );

		return [
			isSelected && (
				<InspectorControls>
					<ContainerOptions
						{ ...props }
					/>
				</InspectorControls>
			),
			<div key="editor-display" className={ classnames( className, 'accordion-navigation' ) }>
				{ containerSettings &&
					<div className="container-settings">
						<BlockIdEdit
							{ ...props }
						/>
						<HideSectionEdit
							{ ...props }
						/>
					</div>
				}

				<div className={ classes.container } id={ classes.id }>
					<div className="row justify-content-center">
						<div className={ classes.width }>
							<div className="accordion">
								<InnerBlocks
									template={ BLOCK_TEMPLATE }
									allowedBlocks={ ALLOWED_BLOCKS }
								/>
							</div>
						</div>
					</div>
				</div>
			</div>,
		];
	},
	// Save the attributes and markup
	save: function( props ) {
		// Setup the attributes
		const {
			className,
		} = props;

		const classes = defineClassNames( props, 'accordion', 'save' );

		return (
			<div className={ className }>
				<div
					id={ classes.id }
					className={ classes.container }
				>
					<div className="container">
						<div className="row justify-content-center">
							<div className={ classes.width }>
								<div className="accordion" role="tablist" aria-multiselectable="true">
									<InnerBlocks.Content />
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		);
	},
	deprecated: [
		{

		},
	],
} );
