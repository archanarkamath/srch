const attributes = {
	tabs: {
		type: 'number',
		default: 1,
	},
};

export default attributes;
