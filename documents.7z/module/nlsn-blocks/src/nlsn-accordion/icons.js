const icons = {};
icons.accordion = <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 360 360">
    <g id="Data_Session">
        <polygon points="152.367,324 78.146,246.833 84.695,240.533 152.464,310.991 222.292,240.484 228.752,246.882"
        fill="#00aeef" />
        <rect x="148.648" y="142.295" width="9.087" height="169.499" fill="#00aeef"
        />
        <g>
            <polygon points="137.419,119.512 130.958,113.114 207.344,36 281.569,113.162 275.021,119.463 207.247,49.009"
            />
            <rect x="201.976" y="48.202" width="9.087" height="169.499" />
        </g>
    </g>
</svg>;

export default icons;
