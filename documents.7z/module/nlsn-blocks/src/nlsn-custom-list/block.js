/**
 * BLOCK: Custom List
 */

// Block dependencies
import classnames from 'classnames';
import defineClassNames from '../utilities/defineClasses';
import attributes from './attributes';
import icon from './icon';

import { Icon, gallery, cancelCircleFilled } from '@wordpress/icons';


// Import all of our Container Options requirements.
import ContainerOptions, {
	ContainerOptionsAttributes,
	HideSectionEdit,
	HideSectionSave,
	BlockIdEdit,
	BlockIdSave,
	BlockWidthClasses,
	BackgroundOptionsClasses,
	BlockPaddingClasses,
} from '../components/container-options';

// Components
const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks

// Register editor components
const {
	InspectorControls,
	MediaUpload,
	RichText,
} = wp.blockEditor;

const {
	Button,
} = wp.components;

const blockClasses = classnames(
	`nav-sidebar`,
);
const navClasses = classnames(
	`content-body`,
)
const imageClasses = classnames(
	`content-image`,
);
const editorClasses = classnames(
	`content-editor`,
	`nav`,
	`link-list`,
)

// Register: Custom List
registerBlockType( 'nlsn-blocks/nlsn-custom-list', {
	title: __( 'Custom List - NLSN', 'nlsn-blocks' ),
	description: __( 'Add a custom list to the page. Hit Enter to generate a new item', 'nlsn-blocks' ),
	icon: icon,
	category: 'nielsen-blocks',
	keywords: [
		__( 'list', 'nlsn-blocks' ),
		__( 'sidebar', 'nlsn-blocks' ),
		__( 'nielsen', 'nlsn-blocks' ),
	],
	attributes: {
		...attributes,
		...ContainerOptionsAttributes,
	},

	/**
	 * Determines what is displayed in the editor.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 */
	edit: props => {
		const {
			attributes: {
				imgID,
				imgURL,
				imgAlt,
				contentEditor,
				containerSettings,
			},
			isSelected,
			className,
			setAttributes,
		} = props;

		const classes = defineClassNames( props, 'custom-list' );

		const onSelectImage = img => {
      setAttributes( {
        imgID: img.id,
        imgURL: img.url,
        imgAlt: img.alt,
      } );
    };
    const onRemoveImage = () => {
      setAttributes({
        imgID: null,
        imgURL: null,
        imgAlt: null,
      });
    }

		// Return the markup displayed in the editor.
		return (
			<div key="editor-display" className={ className }>

				{ isSelected &&
					<InspectorControls>
						<ContainerOptions
							{ ...props }
						/>
					</InspectorControls>
				}

				{ containerSettings &&
					<div className="container-settings">
						<BlockIdEdit
							{ ...props }
						/>
						<HideSectionEdit
							{ ...props }
						/>
					</div>
				}

				<div className={ classes.container } id={ classes.id }>
					<div className='container'>
						<div className='row justify-content-center'>
							<div className={ classes.width }>

									<div className={ classnames( blockClasses ) }>
										{ ( ! imgID && isSelected ) ? (
											<div className={ classnames( imageClasses ) }>
												<MediaUpload
													onSelect={ onSelectImage }
													value={ imgID }
													render={ ( { open } ) => (
														<Button
															className='select-image'
															onClick={ open }
															style={ {
																display: "grid",
																padding: "10px",
															} }
														>
															<Icon icon={ gallery } />
															<label>{ __( ' Add Image', 'nlsn-blocks' ) }</label>
														</Button>
													) }
												>
												</MediaUpload>
											</div>
										) : (
											<div className={ classnames( imageClasses ) }>
					              <img
				                  src={ imgURL }
				                  alt={ imgAlt }
					              />

								{ isSelected ? ( <Button onClick={ onRemoveImage } icon={ cancelCircleFilled }  /> ) : null }

											</div>
										)}

										<div className={ classnames( navClasses ) }>
											<RichText
												tagName='ul'
												multiline='li'
												className={ classnames( editorClasses ) }
												placeholder={ __( 'Add your first list item', 'nlsn-blocks' ) }
												value={ contentEditor }
												onChange={ contentEditor => { setAttributes( { contentEditor } ) } }
											/>
										</div>
									</div>

							</div>
						</div>
					</div>
				</div>
			</div>
		)
	},

	/**
	 * Determines what is displayed on the front-end.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 */
	save: props => {
		const {
			attributes: {
				imgURL,
				imgAlt,
				contentEditor,
				containerSettings,
			},
			className,
		} = props;

		const classes = defineClassNames( props, 'custom-list', 'save' );

		// Return the markup displayed on the front-end.
		return (
			<div className={ className }>
				<div
					id={ classes.id }
					className={ classes.container }
				>
					<div className='container'>
						<div className='row justify-content-center'>
							<div className={ classes.width }>

								<div className={ classnames( blockClasses ) }>
									{ imgURL ? (
										<div className={ classnames( imageClasses ) }>
											<a className='image-icon'>
												<img
													className='content-thumbnail'
													src={ imgURL }
													alt={ imgAlt }
												/>
											</a>
										</div>
									) : null }

									<div className={ classnames( navClasses ) }>
										<ul className={ classnames( editorClasses ) }>
											{ contentEditor }
										</ul>
									</div>
								</div>

							</div>
						</div>
					</div>
				</div>
			</div>
		);
	},

	/**
	 * Provide a “deprecated” version of the block.
	 * This allows users opening these blocks in Gutenberg to edit them using the updated block.
	 * @link https://wordpress.org/gutenberg/handbook/block-api/deprecated-blocks/
	 */
	deprecated: [
		{

		},
	 ]
} );
