const attributes = {
	imgID: {
		type: 'number',
	},
	imgURL: {
		type: 'string',
		source: 'attribute',
		attribute: 'src',
		selector: '.content-thumbnail',
	},
	imgAlt: {
		type: 'string',
		source: 'attribute',
		attribute: 'alt',
		selector: '.content-thumbnail',
	},
	contentEditor: {
    type: 'array',
		source: 'children',
		selector: '.content-editor',
  },
};

export default attributes;
