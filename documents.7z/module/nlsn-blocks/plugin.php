<?php
/**
 * Plugin Name: Nielsen Gutenberg Blocks
 * Plugin URI: https://github.com/ahmadawais/create-guten-block/
 * Description: Nielsen Gutenberg Blocks is a Gutenberg plugin created for Nielsen.
 * Text Domain: nlsn-blocks
 * Author: Nielsen Dev Team
 * Author URI: https://nielsen.com/
 * Version: 1.3.0
 *
 * @package CGB
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Helpers.
 */
require_once plugin_dir_path( __FILE__ ) . 'src/helpers.php';

/**
 * Dynamic Blocks
 */
require_once plugin_dir_path( __FILE__ ) . 'src/nlsn-feed-smart-list/index.php';


add_action( 'enqueue_block_editor_assets', function(){

	$asset_file = include( plugin_dir_path( __FILE__ ) . 'build/index.asset.php');

	wp_enqueue_script(
		'nlsn-block-editor-scripts',
		plugins_url( 'build/index.js', __FILE__ ),
		$asset_file['dependencies'],
		$asset_file['version']
	);
	wp_enqueue_style(
        'nlsn-block-editor-styles',
        plugins_url( 'build/index.css', __FILE__ ),
        '',
        $asset_file['version']
    );
});


/**
 * Add custom block category
 */
function nlsn_block_categories( $categories, $post ) {

	return array_merge(
		array(
			array(
				'slug'  => 'nielsen-templates',
				'title' => __( 'Nielsen Templates', 'nlsn-blocks' ),
			),
			array(
				'slug'  => 'nielsen-blocks',
				'title' => __( 'Nielsen Blocks', 'nlsn-blocks' ),
			),
		),
		$categories
	);
}

add_filter( 'block_categories', 'nlsn_block_categories', 10, 2 );

/**
 * Register meta field for Subheading block.
 */
function nlsn_register_block_meta() {
	register_meta( 'post', 'page_subtitle', array(
		'show_in_rest' => true,
		'single'       => true,
		'type'         => 'string',
	) );
}
add_action( 'init', 'nlsn_register_block_meta' );
