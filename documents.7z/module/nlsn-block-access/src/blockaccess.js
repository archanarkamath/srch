/* eslint-disable react/react-in-jsx-scope */
/* eslint-disable react/prop-types */

import { get } from 'lodash';

/* eslint-disable no-undef */
const { getBlockTypes } = wp.blocks;
const { useEffect, useState } = wp.element;
const { registerPlugin } = wp.plugins;
const { withDispatch, withSelect } = wp.data;
const { compose, ifCondition } = wp.compose;
/* eslint-enable no-undef */


// Get stored hidden blocks from prior use
const getStoredHiddenBlocks = ({ id }) => {

  // Create default stored hidden blocks value with linked
  // WP_DATA_USER key in localStorage and try to pull data
  const storedHiddenBlocks = [`WP_DATA_USER_${id}`, []];
  let wpDataUser = window.localStorage.getItem(storedHiddenBlocks[0]);

  // If existing hidden blocks are in localStorage from a non-admin user,
  // update the stored hidden blocks array. If user was changed from a
  // non-admin to an admin, make sure to return anyways for removal
  if (wpDataUser) {
    wpDataUser = JSON.parse(wpDataUser);
    if (('core/edit-post' in wpDataUser) && ('preferences' in wpDataUser['core/edit-post'])) {
      storedHiddenBlocks[1] = wpDataUser['core/edit-post'].preferences.hiddenBlockTypes;
    }
  }

  return storedHiddenBlocks;

};


// Main render class
const BlockAccessView = ({
  hideBlockTypes,
  user,
  removeBlocks,
  showBlockTypes,
  storedHiddenBlocks,
}) => {

  // Setup state for removed blocks and get roles from user
  // prop and set default array for allowed blocks
  const [removedBlocks, setRemovedBlocks] = useState(false);
  const { roles } = user;

  // Hide blocks and also update localStorage value(s)
  const hideBlocks = () => {

    // Hide blocks from the UI
    hideBlockTypes(removeBlocks);

    // Continue if stored hidden blocks exist with key and values
    if (storedHiddenBlocks.length === 2) {

      // Extract current localStorage key and blocks array from props and
      // store boolean value whether removal blocks match current blocks
      const [lsKey, currentBlocks] = storedHiddenBlocks;
      const matchingBlocks = (JSON.stringify(removeBlocks) === JSON.stringify(currentBlocks));

      // If current blocks exist and removal blocks do not match
      if (currentBlocks.length && !matchingBlocks) {

        // Update the localStorage value by grabbing the key and defined
        // removal blcosk from props and update the hiddenBlockTypes key
        const currentStorage = JSON.parse(window.localStorage.getItem(lsKey));
        currentStorage['core/edit-post'].preferences.hiddenBlockTypes = removeBlocks;
        window.localStorage.setItem(lsKey, JSON.stringify(currentStorage));

        // Get the currently stored hidden blocks, compare against the new ones
        // to remove, and restore the ones that should be visible again
        const restoreBlocks = currentBlocks.filter((k) => !removeBlocks.includes(k));
        showBlockTypes(restoreBlocks);

      }

    }

    // Now update state
    setRemovedBlocks(true);

  };

  // Hide block manager for non-admin users
  const hideBlockManager = () => {

    // Get the Tools menu
    let toolsMenu = null;
    const menuGroupLabels = [...document.querySelectorAll('div.components-menu-group__label')];
    if (menuGroupLabels.length) {
      [toolsMenu] = menuGroupLabels.filter((k) => k.innerHTML === 'Tools');
    }

    // Hide Block Manager if it is available and store in state
    if (toolsMenu) {
      const menuGroup = toolsMenu.parentNode;
      const menuButtons = [...menuGroup.querySelectorAll('button.components-menu-item__button')];
      const blockManager = menuButtons.filter((k) => k.innerHTML === 'Block Manager');
      if (blockManager.length) {
        blockManager[0].style.display = 'none'; // If removing, use blockManager[0].remove();
      }
    }

  };

  // If an administrator, run this on component mount only
  // and also have another to check for removeBlocks and hide
  useEffect(() => {
    if ((removeBlocks.length || storedHiddenBlocks[1].length) && !removedBlocks) {
      hideBlocks();
    }
    if (roles.includes('administrator') && !removedBlocks) {
      setRemovedBlocks(true);
    }
  }, []);

  // Add a hook to always listen for Block Manager link status and remove due
  // to visibility based on click event on "show more tools and options" menu
  useEffect(() => {
    if (!roles.includes('administrator')) {
      hideBlockManager();
    }
  });

  return true;

};


const BlockAccess = compose([

  withSelect((select) => {

    const { getPostType } = select('core');
    const { getEditedPostAttribute } = select('core/editor');
    const postType = get(getPostType(getEditedPostAttribute('type')), ['slug'], false);

    // Get stored user data and streamline user for props
    const { allPostBlocks, currentUser } = window;
    const { id, roles } = currentUser;
    const user = {
      id: Number(id),
      roles,
    };

    // Setup blocks to remove. To avoid any issues with blocks like
    // "event" which could conflict with reserved words, reference
    // the "_blocks" value in the array
    let removeBlocks = [];
    const postTypeBlocks = `${postType}_blocks`;
    if (!roles.includes('administrator') && (postTypeBlocks in allPostBlocks)) {
      const allowedBlocks = allPostBlocks[postTypeBlocks];
      const blockTypes = getBlockTypes().map((k) => k.name);
      removeBlocks = blockTypes.filter((k) => !allowedBlocks.includes(k));
    }

    // Now return props
    return {
      postType,
      removeBlocks,
      storedHiddenBlocks: getStoredHiddenBlocks(user),
      user,
    };

  }),

  ifCondition(({ postType }) => Object.keys(window.allPostBlocks).includes(`${postType}_blocks`)),

  withDispatch((dispatch) => ({
    hideBlockTypes: dispatch('core/edit-post').hideBlockTypes,
    showBlockTypes: dispatch('core/edit-post').showBlockTypes,
  })),

])(BlockAccessView);

registerPlugin('nlsn-block-access', { render: BlockAccess });
