<?php
/*
Plugin Name: Nielsen Block Access
Description: Limit the access of Gutenberg blocks based on user roles
Plugin URI: http://www.nielsen.com
Version: 1.0.0
Author: Nielsen Dev Team
Author URI: http://www.nielsen.com/
*/

// Don't call this file directly
if (!class_exists('WP')) {
	die();
}

class NLSN_Block_Access {

  static function init() {

    // Load the script
    wp_enqueue_script(
      'nlsn-block-access-js',
      plugin_dir_url(__FILE__) .'dist/app.js',
      array('wp-blocks', 'wp-dom-ready', 'wp-edit-post'),
      filemtime( plugin_dir_path( __FILE__ ) . '/dist/app.js'),
      true // Enqueue the script in the footer.,
    );

    // Get currently logged in user and store in
    // JavaScript via window.currentUser
    $user = wp_get_current_user();
    wp_localize_script(
      'nlsn-block-access-js',
      'currentUser',
      array(
        'id' => $user->ID,
        'roles' => $user->roles,
      )
    );

  }

}

// Initialize JavaScript in admin areas
add_action('enqueue_block_editor_assets', array('NLSN_Block_Access', 'init'));
