<?php
/*
Plugin Name: Nielsen Careers Media Cron 
Description: Cron function to create/update job openings 
Version: 2.0
*/

namespace Nielsen\Careers_Cron;




require_once __DIR__ . '/cron-function.php';
require_once __DIR__ . '/helpers/convert_state.php';
require_once __DIR__ . '/helpers/convert_country.php';
require_once __DIR__ . '/helpers/set_city.php';
require_once __DIR__ . '/helpers/set_job_schedule.php';
require_once __DIR__ . '/helpers/set_job_team.php';
require_once __DIR__ . '/helpers/set_job_type.php';
require_once __DIR__ . '/helpers/set_market.php';
require_once __DIR__ . '/helpers/set_region.php';
require_once __DIR__ . '/helpers/set_location.php';
require_once __DIR__ . '/helpers/set_post_date.php';



function careers_deactivate() {
    wp_clear_scheduled_hook( 'nlsn_careers_check_action' );
}
 
add_action('init', function() {
    add_action( 'nlsn_careers_check_action', 'Nielsen\Careers_Cron\nlsn_careers_check', 9 );

    register_deactivation_hook( __FILE__, 'careers_deactivate' );
 
    if (! wp_next_scheduled ( 'nlsn_careers_check_action' )) {
        wp_schedule_event( time(), 'hourly', 'nlsn_careers_check_action' );
    }
});