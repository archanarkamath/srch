<?php

namespace Nielsen\Careers_Cron;


function nlsn_careers_check_error( $careers_cron_error_message ) {
	//used to catch and log any errors from the cron job
	// phpcs:disable
	if ( extension_loaded( 'newrelic' ) ) {
		newrelic_notice_error( print_r( $careers_cron_error_message, true ) );
	} else {
		error_log( print_r( $careers_cron_error_message, true ), 0 );
	}
	// phpcs:enable
}

function nlsn_careers_check() {

	
	// xml feed
	$feed_url = 'https://jobs.nielsen.com/feed/232800';
	wp_set_current_user( null, 'nlsncronbot' );

	// Loop until we find less then 100 posts left, then do one final iteration.
	$page = 1;
	$post_meta_ids = array();
	do {
		$query           = new \WP_Query([
			'posts_per_page' => '100',
			'post_type'      => 'career_job',
			'post_status'    => 'publish',
			'paged'          => $page,
		]);
		$published_posts = $query->posts;
		foreach ( $published_posts as $job_post ) {
			$post_meta_id = get_field( 'job_post_id', $job_post );
			// push value to custom-post-type array for comparison
			array_push( $post_meta_ids, $post_meta_id );
		}
		// Move on to the next page.
		$page++;
		sleep( 2 ); // Take a breather.
	} while ( $query->have_posts() );

	// get feed from cron function call
	$get_data = wpcom_vip_file_get_contents( esc_url_raw( $feed_url ), 3 );
	if ( false === $get_data ) {
		nlsn_careers_check_error( $get_data );
		return false;
	}
	$job_feed = new \SimpleXMLElement( $get_data );


	// post ids to check if duplicate 
	$data_post_ids = array();

	// foreach, get needed values for post creation
	foreach ( $job_feed as $key => $job ) {
		$data_post_id      = (string) $job->ID;
		$job_req_number    = (string) explode( "-", $data_post_id )[0];  // is this neeeded?
		$post_date         = set_post_date( (string) $job->created );
		$job_region        = set_region( (string) $job->region );
		$job_country       = convert_country( (string) $job->country );
		$job_state         = (string) $job->state;
		$job_city          = set_city( (string) $job->city );
		
		$job_title         = (string) $job->title;
		$job_url           = (string) $job->url;
		$job_team          = set_job_team( (string) $job->team );
		$job_jobtype       = set_job_type( (string) $job->jobtype );
		$job_shift         = set_job_schedule( (string) $job->shift );
		$market            = set_market( $job_region, $job_country );
		$language          = 'en';
		$job_alt_location1 = (string) $job->alt_location1;
		$job_alt_location2 = (string) $job->alt_location2;
		$job_alt_location3 = (string) $job->alt_location3;
		$job_alt_location4 = (string) $job->alt_location4;
		$job_description   = (string) $job->description;

		$alt_locations   = array();
		$alt_locations[] = $job_alt_location1;
		$alt_locations[] = $job_alt_location2;
		$alt_locations[] = $job_alt_location3;
		$alt_locations[] = $job_alt_location4;

		$new_location     = set_location( $job_region, $job_country, $job_state, $job_city );
		
		$post_content = '<p>' . $job_region . " / " . $job_country . " / " . $job_state . " / " . $job_city  . '</p><p>' . $job_team . '</p><p>#: ' . $data_post_id . ' / ' . $job_req_number . '</p><p>' . $job_jobtype . '</p><p>' . $job_shift . '</p><p>' . $job_description  . '</p><p>' . '</p>';

		$job_alt_locations = ( ! empty( $job_alt_location1 ) ? $job_alt_location1 : '' ) . ( ! empty( $job_alt_location2 ) ? ', ' . $job_alt_location2 : '' ) . ( ! empty( $job_alt_location3 ) ? ', ' . $job_alt_location3 : '' ) . ( ! empty( $job_alt_location4 ) ? ', ' . $job_alt_location4 : '' );

		array_push( $data_post_ids, $data_post_id );
		// check if post id exists in our custom-post-type array. create new post if it doesn't
		if ( ! in_array( $data_post_id, $post_meta_ids, true ) ) {

			// our new post
			$new_post = array(
				'post_date'    => $post_date,
				'post_content' => $post_content,
				'post_title'   => $job_title,
				'post_status'  => 'publish',
				'post_type'    => 'career_job',
				'meta_input'   => array(
					'job_post_id'       => $data_post_id,
					'job_req_number'    => $job_req_number,
					'job_post_url'      => $job_url,
					'job_region'        => $job_region,
					'job_subregion'     => $new_location,
					'job_alt_locations' => $job_alt_locations,
				),
			);
			$post_id  = wp_insert_post( $new_post );

			// add corresponding taxonomy terms
			if ( ! is_wp_error( $post_id, true ) ) {

				$term_taxonomy_business = wp_set_object_terms( $post_id, 'media', 'business' );
				if ( is_wp_error( $term_taxonomy_business ) ) {
					nlsn_careers_check_error( $term_taxonomy_business );
				}

				$term_taxonomy_market = wp_set_object_terms( $post_id, $market, 'markets' );
				if ( is_wp_error( $term_taxonomy_market ) ) {
					nlsn_careers_check_error( $term_taxonomy_market );
				}

				$term_taxonomy_language = wp_set_object_terms( $post_id, $language, 'languages' );
				if ( is_wp_error( $term_taxonomy_language ) ) {
					nlsn_careers_check_error( $term_taxonomy_language );
				}

				$term_taxonomy_team = wp_set_object_terms( $post_id, $job_team, 'job_teams' );
				if ( is_wp_error( $term_taxonomy_team ) ) {
					nlsn_careers_check_error( $term_taxonomy_team );
				}

				$term_taxonomy_location = wp_set_object_terms( $post_id, $new_location, 'job_locations' );
				if ( is_wp_error( $term_taxonomy_location ) ) {
					nlsn_careers_check_error( $term_taxonomy_location );
				}

				$term_taxonomy_type = wp_set_object_terms( $post_id, $job_jobtype, 'job_types' );
				if ( is_wp_error( $term_taxonomy_type ) ) {
					nlsn_careers_check_error( $term_taxonomy_type );
				}
				$term_taxonomy_schedule = wp_set_object_terms( $post_id, $job_shift, 'job_schedules' );
				if ( is_wp_error( $term_taxonomy_schedule ) ) {
					nlsn_careers_check_error( $term_taxonomy_schedule );
				}
			} else {
				nlsn_careers_check_error( $data_post_id );
			}
		} else {
			// update existing post

			// get the latest existing post with this data_post_id, if any.
			$existing_args  = array(
				'post_status'      => 'publish',
				'post_type'        => 'career_job',
				'meta_key'         => 'job_post_id',
				'meta_value'       => $data_post_id,
				'posts_per_page'   => 1,
				'suppress_filters' => false,
			);
			$existing_posts = get_posts( $existing_args );

			// foreach, update the post. Will only update info if one of the values in the arguments below have changed
			foreach ( $existing_posts as $post_to_update ) {
				$query   = array(
					'ID'           => $post_to_update->ID,
					'post_date'    => $post_date,
					'post_content' => $post_content,
					'post_title'   => $job_title,
				);
				$post_id = wp_update_post( $query, true );
				if ( ! is_wp_error( $post_id ) ) {
					// update corresponding taxonomy terms
					$term_taxonomy_team = wp_set_object_terms( $post_id, $job_team, 'job_teams' );
					if ( is_wp_error( $term_taxonomy_team ) ) {
						nlsn_careers_check_error( $term_taxonomy_team );
					}

					$term_taxonomy_location = wp_set_object_terms( $post_id, $new_location, 'job_locations' );
					if ( is_wp_error( $term_taxonomy_location ) ) {
						nlsn_careers_check_error( $term_taxonomy_location );
					}

					$term_taxonomy_type = wp_set_object_terms( $post_id, $job_jobtype, 'job_types' );
					if ( is_wp_error( $term_taxonomy_type ) ) {
						nlsn_careers_check_error( $term_taxonomy_type );
					}
					$term_taxonomy_schedule = wp_set_object_terms( $post_id, $job_shift, 'job_schedules' );
					if ( is_wp_error( $term_taxonomy_schedule ) ) {
						nlsn_careers_check_error( $term_taxonomy_schedule );
					}
					update_post_meta( $post_to_update->ID, 'job_req_number', $job_req_number );
					update_post_meta( $post_to_update->ID, 'job_post_url', esc_url_raw( $job_url ) );
					update_post_meta( $post_to_update->ID, 'job_region', $job_region );
					update_post_meta( $post_to_update->ID, 'job_subregion', $new_location );
					update_post_meta( $post_to_update->ID, 'job_alt_locations', $job_alt_locations );
				} else {
					nlsn_careers_check_error( $data_post_id );
				}
				// update corresponding taxonomy terms
				// update corresponding meta info
			}
		}

		// get existing posts, except the latest one, with this data_post_id, if any.
		$duplicate_args  = array(
			'post_status'      => 'publish',
			'post_type'        => 'career_job',
			'meta_key'         => 'job_post_id',
			'meta_value'       => $data_post_id,
			'posts_per_page'   => 10,
			'offset'           => 1,
			'suppress_filters' => false,
		);
		$duplicate_posts = get_posts( $duplicate_args );

		// foreach duplicate, change status to trash
		foreach ( $duplicate_posts as $post_to_archive ) {
			$query = array(
				'ID'          => $post_to_archive->ID,
				'post_status' => 'trash',
			);
			wp_update_post( $query, true );
		}
	}

	foreach ( $post_meta_ids as $key ) {
		$this_meta_id = $key;
		if ( ! in_array( $this_meta_id, $data_post_ids, true ) ) {
			// get all existing posts with this post meta_value, if any.
			$meta_args  = array(
				'post_status'      => 'publish',
				'post_type'        => 'career_job',
				'meta_key'         => 'job_post_id',
				'meta_value'       => $this_meta_id,
				'posts_per_page'   => 10,
				'suppress_filters' => false,
				'tax_query' => array(
					array(
						'taxonomy' => 'business',
						'field'    => 'slug',
						'terms'    => 'media'
					)
				)
			);
			$meta_posts = get_posts( $meta_args );

			// foreach, change status to pending since these are not available in the json data anymore
			foreach ( $meta_posts as $post_to_archive ) {
				$query = array(
					'ID'          => $post_to_archive->ID,
					'post_status' => 'trash',
				);
				wp_update_post( $query, true );
			}
		}
	}
}

