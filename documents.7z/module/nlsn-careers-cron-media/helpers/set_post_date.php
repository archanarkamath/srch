<?php 

namespace Nielsen\Careers_Cron;

function set_post_date( $job_date ){
    return date( 'Y-m-d H:i:s', strtotime( str_replace( ' ', '-', substr( $job_date, 5, 10 ) ) ) );
}

