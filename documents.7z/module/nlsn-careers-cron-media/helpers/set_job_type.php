<?php 

namespace Nielsen\Careers_Cron;


function set_job_type( $job_type ) {
    if ( ! ($job_type === "Regular" || $job_type === "Internship" || $job_type === "Recent Graduate Job" || $job_type === "Temporary" )) {
      $job_type = "Regular";
    }
    return $job_type;
}
