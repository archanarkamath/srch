<?php

namespace Nielsen\Careers_Cron;


function set_region( $region ) {
    if ($region === "Africa and the Middle East") {
      $region = "Africa and Middle East";
    } else if ($region === "South East Asia, North Asia and Pacific") {
      $region = "Asia Pacific";
    }
    return $region;
}
