<?php
/* -----------------------------------
 * CONVERT STATE NAMES!
 * Goes both ways. e.g.
 * $return = 'United States' -> returns "US"
 * $return = 'US' -> returns "United States"
 * 
 * @param string $return 
 * @param boolean $return_region – returns region string instead of country abbr / name 
 * ----------------------------------- */

namespace Nielsen\Careers_Cron;


function convert_country( $return, $return_region = false ) {
    
    $countries = array(
        array('region' => 'Asia Pacific', 'abbr' => 'AF', 'name' => 'Afghanistan'),
        array('region' => 'Europe', 'abbr' => 'AL', 'name' => 'Albania'),
        array('region' => 'Africa and Middle East', 'abbr' => 'DZ', 'name' => 'Algeria'),
        array('region' => 'Europe', 'abbr' => 'AD', 'name' => 'Andorra'),
        array('region' => 'Africa and Middle East', 'abbr' => 'AO', 'name' => 'Angola'),
        array('region' => 'Latin America', 'abbr' => 'AR', 'name' => 'Argentina'),
        array('region' => 'Europe', 'abbr' => 'AM', 'name' => 'Armenia'),
        array('region' => 'Asia Pacific', 'abbr' => 'AU', 'name' => 'Australia'),
        array('region' => 'Europe', 'abbr' => 'AT', 'name' => 'Austria'),
        array('region' => 'Asia Pacific', 'abbr' => 'AZ', 'name' => 'Azerbaijan'),
        array('region' => 'Africa and Middle East', 'abbr' => 'BH', 'name' => 'Bahrain'),
        array('region' => 'Asia Pacific', 'abbr' => 'BD', 'name' => 'Bangladesh'),
        array('region' => 'Europe', 'abbr' => 'BY', 'name' => 'Belarus'),
        array('region' => 'Europe', 'abbr' => 'BE', 'name' => 'Belgium'),
        array('region' => 'Latin America', 'abbr' => 'BZ', 'name' => 'Belize'),
        array('region' => 'Africa and Middle East', 'abbr' => 'BJ', 'name' => 'Benin'),
        array('region' => 'Asia Pacific', 'abbr' => 'BT', 'name' => 'Bhutan'),
        array('region' => 'Latin America', 'abbr' => 'BO', 'name' => 'Bolivia'),
        array('region' => 'Europe', 'abbr' => 'BA', 'name' => 'Bosnia And Herzegovina'),
        array('region' => 'Africa and Middle East', 'abbr' => 'BW', 'name' => 'Botswana'),
        array('region' => 'Latin America', 'abbr' => 'BR', 'name' => 'Brazil'),
        array('region' => 'Asia Pacific', 'abbr' => 'BN', 'name' => 'Brunei Darussalam'),
        array('region' => 'Europe', 'abbr' => 'BG', 'name' => 'Bulgaria'),
        array('region' => 'Africa and Middle East', 'abbr' => 'BF', 'name' => 'Burkina Faso'),
        array('region' => 'Africa and Middle East', 'abbr' => 'BI', 'name' => 'Burundi'),
        array('region' => 'Asia Pacific', 'abbr' => 'KH', 'name' => 'Cambodia'),
        array('region' => 'Africa and Middle East', 'abbr' => 'CM', 'name' => 'Cameroon'),
        array('region' => 'North America', 'abbr' => 'CA', 'name' => 'Canada'),
        array('region' => 'Africa and Middle East', 'abbr' => 'CV', 'name' => 'Cape Verde'),
        array('region' => 'Africa and Middle East', 'abbr' => 'CF', 'name' => 'Central African Republic'),
        array('region' => 'Africa and Middle East', 'abbr' => 'TD', 'name' => 'Chad'),
        array('region' => 'Latin America', 'abbr' => 'CL', 'name' => 'Chile'),
        array('region' => 'Greater China', 'abbr' => 'CN', 'name' => 'China'),
        array('region' => 'Latin America', 'abbr' => 'CO', 'name' => 'Colombia'),
        array('region' => 'Africa and Middle East', 'abbr' => 'KM', 'name' => 'Comoros'),
        array('region' => 'Africa and Middle East', 'abbr' => 'CG', 'name' => 'Congo'),
        array('region' => 'Africa and Middle East', 'abbr' => 'CD', 'name' => 'Congo, Democratic Republic'),
        array('region' => 'Latin America', 'abbr' => 'CR', 'name' => 'Costa Rica'),
        array('region' => 'Africa and Middle East', 'abbr' => 'CI', 'name' => 'Cote D\'Ivoire'),
        array('region' => 'Europe', 'abbr' => 'HR', 'name' => 'Croatia'),
        array('region' => 'Latin America', 'abbr' => 'CU', 'name' => 'Cuba'),
        array('region' => 'Europe', 'abbr' => 'CY', 'name' => 'Cyprus'),
        array('region' => 'Europe', 'abbr' => 'CZ', 'name' => 'Czech Republic'),
        array('region' => 'Europe', 'abbr' => 'DK', 'name' => 'Denmark'),
        array('region' => 'Africa and Middle East', 'abbr' => 'DJ', 'name' => 'Djibouti'),
        array('region' => 'Latin America', 'abbr' => 'DM', 'name' => 'Dominica'),
        array('region' => 'Latin America', 'abbr' => 'DO', 'name' => 'Dominican Republic'),
        array('region' => 'Latin America', 'abbr' => 'EC', 'name' => 'Ecuador'),
        array('region' => 'Africa and Middle East', 'abbr' => 'EG', 'name' => 'Egypt'),
        array('region' => 'Latin America', 'abbr' => 'SV', 'name' => 'El Salvador'),
        array('region' => 'Africa and Middle East', 'abbr' => 'ER', 'name' => 'Eritrea'),
        array('region' => 'Africa and Middle East', 'abbr' => 'EE', 'name' => 'Estonia'),
        array('region' => 'Africa and Middle East', 'abbr' => 'ET', 'name' => 'Ethiopia'),
        array('region' => 'Asia Pacific', 'abbr' => 'FJ', 'name' => 'Fiji'),
        array('region' => 'Europe', 'abbr' => 'FI', 'name' => 'Finland'),
        array('region' => 'Europe', 'abbr' => 'FR', 'name' => 'France'),
        array('region' => 'Africa and Middle East', 'abbr' => 'GA', 'name' => 'Gabon'),
        array('region' => 'Africa and Middle East', 'abbr' => 'GM', 'name' => 'Gambia'),
        array('region' => 'Europe', 'abbr' => 'GE', 'name' => 'Georgia'),
        array('region' => 'Europe', 'abbr' => 'DE', 'name' => 'Germany'),
        array('region' => 'Africa and Middle East', 'abbr' => 'GH', 'name' => 'Ghana'),
        array('region' => 'Europe', 'abbr' => 'GR', 'name' => 'Greece'),
        array('region' => 'Europe', 'abbr' => 'GL', 'name' => 'Greenland'),
        array('region' => 'Latin America', 'abbr' => 'GT', 'name' => 'Guatemala'),
        array('region' => 'Africa and Middle East', 'abbr' => 'GN', 'name' => 'Guinea'),
        array('region' => 'Africa and Middle East', 'abbr' => 'GW', 'name' => 'Guinea-Bissau'),
        array('region' => 'Latin America', 'abbr' => 'HT', 'name' => 'Haiti'),
        array('region' => 'Latin America', 'abbr' => 'HN', 'name' => 'Honduras'),
        array('region' => 'Greater China', 'abbr' => 'HK', 'name' => 'Hong Kong'),
        array('region' => 'Europe', 'abbr' => 'HU', 'name' => 'Hungary'),
        array('region' => 'Europe', 'abbr' => 'IS', 'name' => 'Iceland'),
        array('region' => 'India', 'abbr' => 'IN', 'name' => 'India'),
        array('region' => 'Asia Pacific', 'abbr' => 'ID', 'name' => 'Indonesia'),
        array('region' => 'Africa and Middle East', 'abbr' => 'IR', 'name' => 'Iran, Islamic Republic Of'),
        array('region' => 'Africa and Middle East', 'abbr' => 'IQ', 'name' => 'Iraq'),
        array('region' => 'Europe', 'abbr' => 'IE', 'name' => 'Ireland'),
        array('region' => 'Europe', 'abbr' => 'IM', 'name' => 'Isle Of Man'),
        array('region' => 'Africa and Middle East', 'abbr' => 'IL', 'name' => 'Israel'),
        array('region' => 'Europe', 'abbr' => 'IT', 'name' => 'Italy'),
        array('region' => 'Latin America', 'abbr' => 'JM', 'name' => 'Jamaica'),
        array('region' => 'Asia Pacific', 'abbr' => 'JP', 'name' => 'Japan'),
        array('region' => 'Africa and Middle East', 'abbr' => 'JO', 'name' => 'Jordan'),
        array('region' => 'Asia Pacific', 'abbr' => 'KZ', 'name' => 'Kazakhstan'),
        array('region' => 'Africa and Middle East', 'abbr' => 'KE', 'name' => 'Kenya'),
        array('region' => 'Africa and Middle East', 'abbr' => 'KI', 'name' => 'Kiribati'),
        array('region' => 'Asia Pacific', 'abbr' => 'KR', 'name' => 'Korea'),
        array('region' => 'Africa and Middle East', 'abbr' => 'KW', 'name' => 'Kuwait'),
        array('region' => 'Asia Pacific', 'abbr' => 'KG', 'name' => 'Kyrgyzstan'),
        array('region' => 'Asia Pacific', 'abbr' => 'LA', 'name' => 'Lao People\'s Democratic Republic'),
        array('region' => 'Europe', 'abbr' => 'LV', 'name' => 'Latvia'),
        array('region' => 'Africa and Middle East', 'abbr' => 'LB', 'name' => 'Lebanon'),
        array('region' => 'Africa and Middle East', 'abbr' => 'LS', 'name' => 'Lesotho'),
        array('region' => 'Africa and Middle East', 'abbr' => 'LR', 'name' => 'Liberia'),
        array('region' => 'Africa and Middle East', 'abbr' => 'LY', 'name' => 'Libyan Arab Jamahiriya'),
        array('region' => 'Europe', 'abbr' => 'LI', 'name' => 'Liechtenstein'),
        array('region' => 'Europe', 'abbr' => 'LT', 'name' => 'Lithuania'),
        array('region' => 'Europe', 'abbr' => 'LU', 'name' => 'Luxembourg'),
        array('region' => 'Europe', 'abbr' => 'MO', 'name' => 'Macao'),
        array('region' => 'Europe', 'abbr' => 'MK', 'name' => 'Macedonia'),
        array('region' => 'Africa and Middle East', 'abbr' => 'MG', 'name' => 'Madagascar'),
        array('region' => 'Africa and Middle East', 'abbr' => 'MW', 'name' => 'Malawi'),
        array('region' => 'Asia Pacific', 'abbr' => 'MY', 'name' => 'Malaysia'),
        array('region' => 'Africa and Middle East', 'abbr' => 'MV', 'name' => 'Maldives'),
        array('region' => 'Africa and Middle East', 'abbr' => 'ML', 'name' => 'Mali'),
        array('region' => 'Europe', 'abbr' => 'MT', 'name' => 'Malta'),
        array('region' => 'Latin America', 'abbr' => 'MX', 'name' => 'Mexico'),
        array('region' => 'Europe', 'abbr' => 'MD', 'name' => 'Moldova'),
        array('region' => 'Europe', 'abbr' => 'MC', 'name' => 'Monaco'),
        array('region' => 'Asia Pacific', 'abbr' => 'MN', 'name' => 'Mongolia'),
        array('region' => 'Europe', 'abbr' => 'ME', 'name' => 'Montenegro'),
        array('region' => 'Africa and Middle East', 'abbr' => 'MA', 'name' => 'Morocco'),
        array('region' => 'Africa and Middle East', 'abbr' => 'MZ', 'name' => 'Mozambique'),
        array('region' => 'Asia Pacific', 'abbr' => 'MM', 'name' => 'Myanmar'),
        array('region' => 'Africa and Middle East', 'abbr' => 'NA', 'name' => 'Namibia'),
        array('region' => 'Asia Pacific', 'abbr' => 'NP', 'name' => 'Nepal'),
        array('region' => 'Europe', 'abbr' => 'NL', 'name' => 'Netherlands'),
        array('region' => 'Asia Pacific', 'abbr' => 'NZ', 'name' => 'New Zealand'),
        array('region' => 'Latin America', 'abbr' => 'NI', 'name' => 'Nicaragua'),
        array('region' => 'Africa and Middle East', 'abbr' => 'NE', 'name' => 'Niger'),
        array('region' => 'Africa and Middle East', 'abbr' => 'NG', 'name' => 'Nigeria'),
        array('region' => 'Europe', 'abbr' => 'NO', 'name' => 'Norway'),
        array('region' => 'Africa and Middle East', 'abbr' => 'OM', 'name' => 'Oman'),
        array('region' => 'Africa and Middle East', 'abbr' => 'PK', 'name' => 'Pakistan'),
        array('region' => 'Latin America', 'abbr' => 'PA', 'name' => 'Panama'),
        array('region' => 'Asia Pacific', 'abbr' => 'PG', 'name' => 'Papua New Guinea'),
        array('region' => 'Latin America', 'abbr' => 'PY', 'name' => 'Paraguay'),
        array('region' => 'Latin America', 'abbr' => 'PE', 'name' => 'Peru'),
        array('region' => 'Asia Pacific', 'abbr' => 'PH', 'name' => 'Philippines'),
        array('region' => 'Europe', 'abbr' => 'PL', 'name' => 'Poland'),
        array('region' => 'Europe', 'abbr' => 'PT', 'name' => 'Portugal'),
        array('region' => 'North America', 'abbr' => 'PR', 'name' => 'Puerto Rico'),
        array('region' => 'Africa and Middle East', 'abbr' => 'QA', 'name' => 'Qatar'),
        array('region' => 'Europe', 'abbr' => 'RO', 'name' => 'Romania'),
        array('region' => 'Europe', 'abbr' => 'RU', 'name' => 'Russian Federation'),
        array('region' => 'Europe', 'abbr' => 'RW', 'name' => 'Rwanda'),
        array('region' => 'Africa and Middle East', 'abbr' => 'ST', 'name' => 'Sao Tome And Principe'),
        array('region' => 'Africa and Middle East', 'abbr' => 'SA', 'name' => 'Saudi Arabia'),
        array('region' => 'Africa and Middle East', 'abbr' => 'SN', 'name' => 'Senegal'),
        array('region' => 'Europe', 'abbr' => 'RS', 'name' => 'Serbia'),
        array('region' => 'Africa and Middle', 'abbr' => 'SC', 'name' => 'Seychelles'),
        array('region' => 'Africa and Middle', 'abbr' => 'SL', 'name' => 'Sierra Leone'),
        array('region' => 'Asia Pacific', 'abbr' => 'SG', 'name' => 'Singapore'),
        array('region' => 'Europe', 'abbr' => 'SK', 'name' => 'Slovakia'),
        array('region' => 'Europe', 'abbr' => 'SI', 'name' => 'Slovenia'),
        array('region' => 'Asia Pacific', 'abbr' => 'SB', 'name' => 'Solomon Islands'),
        array('region' => 'Africa and Middle East', 'abbr' => 'SO', 'name' => 'Somalia'),
        array('region' => 'Africa and Middle East', 'abbr' => 'ZA', 'name' => 'South Africa'),
        array('region' => 'Europe', 'abbr' => 'ES', 'name' => 'Spain'),
        array('region' => 'Asia Pacific', 'abbr' => 'LK', 'name' => 'Sri Lanka'),
        array('region' => 'Africa and Middle East', 'abbr' => 'SD', 'name' => 'Sudan'),
        array('region' => 'Latin America', 'abbr' => 'SR', 'name' => 'Suriname'),
        array('region' => 'Africa and Middle East', 'abbr' => 'SZ', 'name' => 'Swaziland'),
        array('region' => 'Europe', 'abbr' => 'SE', 'name' => 'Sweden'),
        array('region' => 'Europe', 'abbr' => 'CH', 'name' => 'Switzerland'),
        array('region' => 'Africa and Middle East', 'abbr' => 'SY', 'name' => 'Syrian Arab Republic'),
        array('region' => 'Greater China', 'abbr' => 'TW', 'name' => 'Taiwan'),
        array('region' => 'Asia Pacific', 'abbr' => 'TJ', 'name' => 'Tajikistan'),
        array('region' => 'Africa and Middle East', 'abbr' => 'TZ', 'name' => 'Tanzania'),
        array('region' => 'Asia Pacific', 'abbr' => 'TH', 'name' => 'Thailand'),
        array('region' => 'Asia Pacific', 'abbr' => 'TL', 'name' => 'Timor-Leste'),
        array('region' => 'Africa and Middle East', 'abbr' => 'TG', 'name' => 'Togo'),
        array('region' => 'Latin America', 'abbr' => 'TT', 'name' => 'Trinidad And Tobago'),
        array('region' => 'Africa and Middle East', 'abbr' => 'TN', 'name' => 'Tunisia'),
        array('region' => 'Africa and Middle East', 'abbr' => 'TR', 'name' => 'Turkey'),
        array('region' => 'Asia Pacific', 'abbr' => 'TM', 'name' => 'Turkmenistan'),
        array('region' => 'Africa and Middle East', 'abbr' => 'UG', 'name' => 'Uganda'),
        array('region' => 'Europe', 'abbr' => 'UA', 'name' => 'Ukraine'),
        array('region' => 'Africa and Middle East', 'abbr' => 'AE', 'name' => 'United Arab Emirates'),
        array('region' => 'Europe', 'abbr' => 'GB', 'name' => 'United Kingdom'),
        array('region' => 'North America', 'abbr' => 'US', 'name' => 'United States'),
        array('region' => 'North America', 'abbr' => 'UM', 'name' => 'United States Outlying Islands'),
        array('region' => 'Africa and Middle East', 'abbr' => 'UY', 'name' => 'Uruguay'),
        array('region' => 'Asia Pacific', 'abbr' => 'UZ', 'name' => 'Uzbekistan'),
        array('region' => 'Latin America', 'abbr' => 'VE', 'name' => 'Venezuela'),
        array('region' => 'Asia Pacific', 'abbr' => 'VN', 'name' => 'Viet Nam'),
        array('region' => 'North America', 'abbr' => 'VG', 'name' => 'Virgin Islands, British'),
        array('region' => 'North America', 'abbr' => 'VI', 'name' => 'Virgin Islands, U.S.'),
        array('region' => 'Africa and Middle East', 'abbr' => 'EH', 'name' => 'Western Sahara'),
        array('region' => 'Africa and Middle East', 'abbr' => 'YE', 'name' => 'Yemen'),
        array('region' => 'Africa and Middle East', 'abbr' => 'ZM', 'name' => 'Zambia'),
        array('region' => 'Africa and Middle East', 'abbr' => 'ZW', 'name' => 'Zimbabwe')
    );

    $strlen = strlen($return);

    if( $return_region ){
        foreach ($countries as $country){
            if ($strlen < 2) {
                return false;
            } else if ($strlen === 2) {
                if (strtolower($country['abbr']) === strtolower($return)) {
                    $return = $country['region'];
                    break;
                }   
            } else {
                if (strtolower($country['name']) === strtolower($return)) {
                    $return = $country['region'];
                    break;
                }         
            }
        }
    }

    foreach ($countries as $country){
        if ($strlen < 2) {
            return false;
        } else if ($strlen === 2) {
            if (strtolower($country['abbr']) === strtolower($return)) {
            $return = $country['name'];
            break;
            }   
        } else {
            if (strtolower($country['name']) === strtolower($return)) {
                $return = strtoupper($country['abbr']);
                break;
            }       
        }
    }
   
   return $return;
}
