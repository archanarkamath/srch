<?php 

namespace Nielsen\Careers_Cron;


function set_job_team( $team ) {
    if ($team === "Client Services and Sales") { // There could potentially be other "Services"
        $team = "Client Service & Sales";
    } else if ($team === "0") {
        $team = "Client Service & Sales";
    }
    $team = str_replace( " and ", " & ", $team );
    return $team;
}
