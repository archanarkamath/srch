<?php

namespace Nielsen\Careers_Cron;

function set_city( $city ) {
  if ( $city === "Tampa Bay" || $city === "Oldsmar" || $city === "Tampa" ) {
    $city = "Tampa - Oldsmar";
  } else if ( $city === "New York" ) {
    $city = "New York City";
  } else if ( $city === "Atlanta" ) {
    $city = "Atlanta - Alpharetta";
  }
  return $city;
}
