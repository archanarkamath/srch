<?php
/**
 * Plugin Name: Nielsen Media Miscellaneous Modifications
 * Description: Makes certain specific changes to media workflows.
 * Text Domain: nlsn-media-misc
 * Author: Alley
 * Author URI: https://alley.co
 *
 */

namespace Nielsen_Media_Misc;

function remove_media_new_submenu_page() {
	if ( ! \Nielsen\Permissions\current_user_has_unrestricted_market_access() ) {
		remove_menu_page( 'upload.php' );
	}
}

add_action( 'admin_init', __NAMESPACE__ . '\remove_media_new_submenu_page' );

function restrict_upload_access( $screen ) {
	if ( 'upload' === $screen->id && ! \Nielsen\Permissions\current_user_has_unrestricted_market_access() ) {
		wp_die( esc_html__( 'You do not have access to this page.', 'nielsen-base' ) );
	}
}

add_action( 'current_screen', __NAMESPACE__ . '\restrict_upload_access' );
